# Task List: Native Neuronpedia Integration

**Feature:** Neuronpedia-Compatible Export with Native Dashboard Data Generation
**PRD Reference:** docs/Neuronpedia_Native_Integration_PRD.md
**Requirements Reference:** docs/neuronpedia_integration_requirements.md
**Mock UI Reference:** PRD Section 7 (UI Specifications)
**Status:** Ready for Implementation
**Created:** 2025-12-04
**Last Updated:** 2025-12-04

---

## Overview

This task list implements native Neuronpedia integration in miStudio, enabling users to:
1. Export trained SAEs with full feature dashboard data to Neuronpedia format
2. Generate Neuronpedia-compatible feature visualizations natively (without SAEDashboard dependency)
3. Produce community-standard outputs that integrate with the mechanistic interpretability ecosystem
4. Share SAEs and feature analyses with the broader research community

**Strategic Value:**
- Position miStudio as a first-class citizen in the interpretability ecosystem
- Enable cross-tool workflows: train in miStudio → explore in Neuronpedia → steer in miStudio
- Contribute SAEs and feature data to the public interpretability commons

---

## Architecture Summary

### Export Pipeline Flow
```
User clicks "Export to Neuronpedia" on SAE
    ↓
Export Configuration Dialog (format, features, data options)
    ↓
Background Celery job starts
    ↓
├─→ Phase 1: Load SAE weights and feature data from database
├─→ Phase 2: Compute missing dashboard data (logit lens, histograms)
├─→ Phase 3: Aggregate top tokens across examples
├─→ Phase 4: Generate Neuronpedia JSON files
├─→ Phase 5: Package into ZIP archive with README
    ↓
User downloads archive → Uploads to Neuronpedia via form
```

### Data Flow Diagram
```
┌─────────────────────────────────────────────────────────────────────────┐
│                        Neuronpedia Export Service                        │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                      Export Orchestrator                         │   │
│  │  • Manages export jobs                                           │   │
│  │  • Coordinates data computation                                  │   │
│  │  • Handles progress tracking                                     │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                              │                                           │
│           ┌──────────────────┼──────────────────┐                       │
│           ▼                  ▼                  ▼                        │
│  ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐           │
│  │  Logit Lens     │ │   Histogram     │ │    Token        │           │
│  │  Computer       │ │   Generator     │ │   Aggregator    │           │
│  └─────────────────┘ └─────────────────┘ └─────────────────┘           │
│           │                  │                  │                        │
│           └──────────────────┼──────────────────┘                       │
│                              ▼                                           │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                      Data Serializer                             │   │
│  │  • Neuronpedia JSON schema                                       │   │
│  │  • SAELens cfg.json format                                       │   │
│  │  • Schema validation                                             │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                              │                                           │
│                              ▼                                           │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                      Export Packager                             │   │
│  │  • File organization                                             │   │
│  │  • ZIP creation                                                  │   │
│  │  • README generation                                             │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Relevant Files

### Backend - New Files to Create
- `backend/src/services/neuronpedia_export_service.py` - Export orchestration, data computation, packaging
- `backend/src/services/logit_lens_service.py` - Logit lens computation for features
- `backend/src/services/histogram_service.py` - Activation histogram generation
- `backend/src/services/token_aggregator_service.py` - Cross-example token ranking
- `backend/src/schemas/neuronpedia.py` - Pydantic schemas for export config and responses
- `backend/src/api/v1/endpoints/neuronpedia.py` - Export API endpoints
- `backend/src/workers/neuronpedia_tasks.py` - Celery tasks for background export
- `backend/alembic/versions/xxx_create_neuronpedia_export_tables.py` - Migration for export tracking

### Backend - Files to Modify
- `backend/src/ml/community_format.py` - Add TransformerLens hook name mapping
- `backend/src/services/extraction_service.py` - Integrate optional dashboard data computation
- `backend/src/models/feature.py` - Add dashboard data fields (or use separate table)
- `backend/src/api/v1/router.py` - Register neuronpedia router

### Frontend - New Files to Create
- `frontend/src/components/saes/ExportToNeuronpedia.tsx` - Export dialog component
- `frontend/src/components/saes/ExportProgress.tsx` - Progress tracking component
- `frontend/src/components/saes/ExportComplete.tsx` - Completion dialog with download
- `frontend/src/types/neuronpedia.ts` - TypeScript types for export
- `frontend/src/api/neuronpedia.ts` - API client for export endpoints
- `frontend/src/stores/neuronpediaExportStore.ts` - Zustand store for export state

### Frontend - Files to Modify
- `frontend/src/components/saes/SAECard.tsx` - Add "Export to Neuronpedia" button
- `frontend/src/components/panels/SAEsPanel.tsx` - Integrate export modal

### Tests
- `backend/tests/test_neuronpedia_export_service.py` - Unit tests for export service
- `backend/tests/test_logit_lens_service.py` - Unit tests for logit lens computation
- `backend/tests/test_histogram_service.py` - Unit tests for histogram generation
- `backend/tests/test_neuronpedia_endpoints.py` - Integration tests for API endpoints
- `frontend/tests/ExportToNeuronpedia.test.tsx` - Component tests for export UI

---

## Phase 1: Database Schema Extensions

### 1.0 Export Job Tracking Table
- [ ] 1.1 Create migration `xxx_create_neuronpedia_export_tables.py`
- [ ] 1.2 Define `neuronpedia_export_jobs` table:
  ```sql
  id UUID PRIMARY KEY DEFAULT gen_random_uuid()
  sae_id VARCHAR(255) NOT NULL  -- Reference to external_saes or training
  source_type VARCHAR(50)  -- 'external_sae' or 'training'

  -- Job configuration
  config JSONB NOT NULL  -- Export options (format, feature selection, etc.)

  -- Status tracking
  status VARCHAR(50) DEFAULT 'pending'  -- pending, computing, packaging, completed, failed
  progress FLOAT DEFAULT 0.0  -- 0-100
  current_stage VARCHAR(100)  -- Current processing stage description

  -- Results
  output_path TEXT  -- Path to generated ZIP archive
  file_size_bytes BIGINT
  feature_count INTEGER

  -- Timing
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  started_at TIMESTAMP WITH TIME ZONE
  completed_at TIMESTAMP WITH TIME ZONE

  -- Error handling
  error_message TEXT
  error_details JSONB
  ```
- [ ] 1.3 Add indexes: `idx_export_jobs_sae`, `idx_export_jobs_status`, `idx_export_jobs_created_at`
- [ ] 1.4 Create SQLAlchemy model `NeuronpediaExportJob` in `backend/src/models/neuronpedia_export.py`

### 1.1 Feature Dashboard Data Table
- [ ] 1.1.1 Define `feature_dashboard_data` table:
  ```sql
  id BIGSERIAL PRIMARY KEY
  feature_id VARCHAR(255) NOT NULL REFERENCES features(id)

  -- Logit lens data
  logit_lens_data JSONB  -- {top_positive: [...], top_negative: [...]}

  -- Histogram data
  histogram_data JSONB  -- {bin_edges: [...], counts: [...], total_count, nonzero_count}

  -- Aggregated tokens
  top_tokens JSONB  -- [{token, total_activation, count, mean_activation, max_activation}]

  -- Computation metadata
  computed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
  computation_version VARCHAR(50)

  UNIQUE(feature_id)
  ```
- [ ] 1.1.2 Add indexes: `idx_feature_dashboard_feature_id`
- [ ] 1.1.3 Create SQLAlchemy model `FeatureDashboardData` in `backend/src/models/feature_dashboard.py`
- [ ] 1.1.4 Run migration and verify tables created

---

## Phase 2: TransformerLens Hook Name Mapping

### 2.0 Hook Name Generation
- [ ] 2.1 Create `backend/src/utils/transformerlens_mapping.py`
- [ ] 2.2 Implement `get_transformerlens_hook_name(layer: int, hook_type: str)`:
  ```python
  def get_transformerlens_hook_name(layer: int, hook_type: str = "resid_post") -> str:
      """
      Map miStudio layer index to TransformerLens hook name.

      hook_type: "resid_pre", "resid_post", "mlp_out", "attn_z"
      """
      hook_mapping = {
          "resid_pre": f"blocks.{layer}.hook_resid_pre",
          "resid_post": f"blocks.{layer}.hook_resid_post",
          "mlp_out": f"blocks.{layer}.hook_mlp_out",
          "attn_z": f"blocks.{layer}.attn.hook_z",
      }
      return hook_mapping.get(hook_type, f"blocks.{layer}.hook_resid_post")
  ```
- [ ] 2.3 Implement `get_transformerlens_model_id(hf_model_name: str)`:
  ```python
  MODEL_ID_MAPPING = {
      "openai-community/gpt2": "gpt2-small",
      "openai-community/gpt2-medium": "gpt2-medium",
      "google/gemma-2b": "gemma-2b",
      "google/gemma-2-2b": "gemma-2-2b",
      "google/gemma-2-2b-it": "gemma-2-2b-it",
      "meta-llama/Llama-3.1-8B": "llama-3.1-8b",
      "EleutherAI/pythia-70m": "pythia-70m",
      # ... more mappings
  }
  ```
- [ ] 2.4 Implement `infer_hook_type_from_sae_config(sae_config: dict)`:
  - Auto-detect hook type from training config if available
  - Default to "resid_post" for residual stream SAEs
- [ ] 2.5 Write unit tests for hook name generation

### 2.1 Update Community Format Export
- [ ] 2.1.1 Modify `backend/src/ml/community_format.py` to include hook_name in cfg.json
- [ ] 2.1.2 Add `hook_name` field to `CommunityStandardConfig` dataclass
- [ ] 2.1.3 Ensure `model_name` uses TransformerLens ID format
- [ ] 2.1.4 Add `prepend_bos`, `context_size`, `normalize_activations` fields

---

## Phase 3: Logit Lens Computation Service

### 3.0 Logit Lens Service
- [ ] 3.1 Create `backend/src/services/logit_lens_service.py`
- [ ] 3.2 Implement `LogitLensService` class with GPU-optimized batch computation
- [ ] 3.3 Implement `compute_logit_lens(sae_id: str, feature_indices: List[int], k: int = 20)`:
  ```python
  async def compute_logit_lens(
      self,
      sae_id: str,
      feature_indices: List[int],
      k: int = 20
  ) -> Dict[int, LogitLensData]:
      """
      Compute top positive and negative logits for each feature.

      Algorithm:
      1. Load SAE decoder vectors for all features at once
      2. Load model's unembedding matrix (W_U)
      3. Compute: feature_logits = W_dec[feature_indices] @ W_U
      4. For each feature, find top-k positive and negative tokens
      """
      # Load SAE and get decoder
      sae = await self._load_sae(sae_id)
      decoder_vectors = sae.W_dec[feature_indices]  # (n_features, d_model)

      # Load model unembedding
      model = await self._load_model(sae_id)
      W_U = model.lm_head.weight.T  # (d_model, vocab_size)

      # Batch compute logits
      feature_logits = decoder_vectors @ W_U  # (n_features, vocab_size)

      results = {}
      for i, feature_idx in enumerate(feature_indices):
          logits = feature_logits[i]

          # Top positive
          top_pos_values, top_pos_indices = torch.topk(logits, k)
          top_positive = [
              {"token": self.tokenizer.decode([idx]), "value": val.item()}
              for idx, val in zip(top_pos_indices, top_pos_values)
          ]

          # Top negative
          top_neg_values, top_neg_indices = torch.topk(-logits, k)
          top_negative = [
              {"token": self.tokenizer.decode([idx]), "value": -val.item()}
              for idx, val in zip(top_neg_indices, top_neg_values)
          ]

          results[feature_idx] = {
              "top_positive": top_positive,
              "top_negative": top_negative,
          }

      return results
  ```
- [ ] 3.4 Implement batching for large feature sets (process 512 features at a time)
- [ ] 3.5 Add progress callback for real-time updates
- [ ] 3.6 Implement caching: check `feature_dashboard_data` table before computing
- [ ] 3.7 Handle OOM gracefully: reduce batch size and retry
- [ ] 3.8 Write unit tests for logit lens computation

---

## Phase 4: Activation Histogram Service

### 4.0 Histogram Generation Service
- [ ] 4.1 Create `backend/src/services/histogram_service.py`
- [ ] 4.2 Implement `HistogramService` class
- [ ] 4.3 Implement `compute_histogram(feature_id: str, n_bins: int = 50, log_scale: bool = True)`:
  ```python
  def compute_histogram(
      self,
      feature_id: str,
      n_bins: int = 50,
      log_scale: bool = True
  ) -> HistogramData:
      """
      Compute histogram of feature activation values from stored examples.
      """
      # Load all activation examples for feature
      examples = await self._load_feature_activations(feature_id)

      # Flatten all activation values
      all_activations = []
      for example in examples:
          all_activations.extend(example.activations)

      activations = np.array(all_activations)
      nonzero_acts = activations[activations > 0]

      if len(nonzero_acts) == 0:
          return HistogramData(
              bin_edges=[0.0],
              counts=[0],
              total_count=len(activations),
              nonzero_count=0
          )

      if log_scale:
          log_min = np.log10(max(nonzero_acts.min(), 1e-10))
          log_max = np.log10(nonzero_acts.max())
          bin_edges = np.logspace(log_min, log_max, n_bins + 1)
      else:
          bin_edges = np.linspace(0, nonzero_acts.max(), n_bins + 1)

      counts, _ = np.histogram(nonzero_acts, bins=bin_edges)

      return HistogramData(
          bin_edges=bin_edges.tolist(),
          counts=counts.tolist(),
          total_count=len(activations),
          nonzero_count=len(nonzero_acts)
      )
  ```
- [ ] 4.4 Implement batch computation for multiple features
- [ ] 4.5 Add support for computing histograms during extraction (optional flag)
- [ ] 4.6 Write unit tests for histogram generation

---

## Phase 5: Token Aggregation Service

### 5.0 Token Aggregation Service
- [ ] 5.1 Create `backend/src/services/token_aggregator_service.py`
- [ ] 5.2 Implement `TokenAggregatorService` class
- [ ] 5.3 Implement `aggregate_top_tokens(feature_id: str, k: int = 50)`:
  ```python
  def aggregate_top_tokens(
      self,
      feature_id: str,
      k: int = 50
  ) -> List[TokenAggregation]:
      """
      Aggregate tokens across all activation examples to find
      tokens that consistently cause high activations.
      """
      examples = await self._load_feature_activations(feature_id)

      token_stats = defaultdict(lambda: {
          'total_activation': 0.0,
          'count': 0,
          'max_activation': 0.0
      })

      for example in examples:
          for token, activation in zip(example.tokens, example.activations):
              if activation > 0:
                  stats = token_stats[token]
                  stats['total_activation'] += activation
                  stats['count'] += 1
                  stats['max_activation'] = max(stats['max_activation'], activation)

      # Sort by total activation
      sorted_tokens = sorted(
          token_stats.items(),
          key=lambda x: x[1]['total_activation'],
          reverse=True
      )[:k]

      return [
          TokenAggregation(
              token=token,
              total_activation=stats['total_activation'],
              count=stats['count'],
              mean_activation=stats['total_activation'] / stats['count'],
              max_activation=stats['max_activation']
          )
          for token, stats in sorted_tokens
      ]
  ```
- [ ] 5.4 Support configurable ranking metrics (total_activation, count, mean)
- [ ] 5.5 Handle subword tokens appropriately (clean BPE markers)
- [ ] 5.6 Implement batch computation for multiple features
- [ ] 5.7 Write unit tests for token aggregation

---

## Phase 6: Neuronpedia Export Service

### 6.0 Export Service Core
- [ ] 6.1 Create `backend/src/services/neuronpedia_export_service.py`
- [ ] 6.2 Implement `NeuronpediaExportService` class
- [ ] 6.3 Implement `start_export(sae_id: str, config: ExportConfig)`:
  - Create `neuronpedia_export_jobs` record with status='pending'
  - Validate SAE exists and has features extracted
  - Enqueue Celery task for background processing
  - Return job_id for status polling

### 6.1 Export Orchestration
- [ ] 6.1.1 Implement `execute_export(job_id: str)` main orchestration:
  ```python
  async def execute_export(self, job_id: str):
      job = await self._get_job(job_id)
      sae = await self._load_sae(job.sae_id)
      features = await self._load_features(job.sae_id, job.config)

      try:
          # Stage 1: Compute missing dashboard data
          await self._update_stage(job_id, "Computing logit lens data", 0)
          await self._compute_logit_lens_batch(features, job_id)

          # Stage 2: Generate histograms
          await self._update_stage(job_id, "Generating histograms", 33)
          await self._compute_histograms_batch(features, job_id)

          # Stage 3: Aggregate tokens
          await self._update_stage(job_id, "Aggregating tokens", 50)
          await self._aggregate_tokens_batch(features, job_id)

          # Stage 4: Generate JSON files
          await self._update_stage(job_id, "Generating JSON files", 66)
          output_dir = await self._generate_json_files(sae, features, job.config)

          # Stage 5: Create archive
          await self._update_stage(job_id, "Creating archive", 90)
          archive_path = await self._create_archive(output_dir, job_id)

          # Complete
          await self._complete_job(job_id, archive_path)

      except Exception as e:
          await self._fail_job(job_id, str(e))
          raise
  ```
- [ ] 6.1.2 Implement progress tracking with WebSocket events
- [ ] 6.1.3 Implement job cancellation support
- [ ] 6.1.4 Implement partial export recovery on failure

### 6.2 JSON File Generation
- [ ] 6.2.1 Implement `_generate_metadata_json(sae, config)`:
  ```python
  def _generate_metadata_json(self, sae, config) -> dict:
      return {
          "model_id": get_transformerlens_model_id(sae.model_name),
          "sae_id": f"layer_{sae.layer}_res_{sae.n_features // 1000}k",
          "neuronpedia_id": f"{get_transformerlens_model_id(sae.model_name)}/{sae.layer}-mistudio-res-{sae.n_features // 1000}k",
          "hook_point": get_transformerlens_hook_name(sae.layer),
          "d_sae": sae.n_features,
          "d_model": sae.d_model,
          "architecture": sae.architecture or "standard",
          "training_dataset": sae.dataset_path,
          "n_training_tokens": sae.total_training_tokens,
          "l0": sae.l0_sparsity,
          "created_at": datetime.utcnow().isoformat() + "Z",
          "miStudio_version": "1.0.0",
          "export_version": "1.0"
      }
  ```
- [ ] 6.2.2 Implement `_generate_feature_json(feature, dashboard_data)`:
  ```python
  def _generate_feature_json(self, feature, dashboard_data) -> dict:
      return {
          "feature_index": feature.neuron_index,
          "activations": self._format_activations(feature.activations),
          "logits": dashboard_data.logit_lens_data,
          "histogram": dashboard_data.histogram_data,
          "statistics": {
              "activation_frequency": feature.activation_frequency,
              "max_activation": feature.max_activation,
              "mean_activation": feature.mean_activation,
              "std_activation": feature.std_activation,
          },
          "top_tokens": dashboard_data.top_tokens
      }
  ```
- [ ] 6.2.3 Implement `_generate_explanations_json(features)`:
  ```python
  def _generate_explanations_json(self, features) -> dict:
      return {
          "explanations": [
              {
                  "feature_index": f.neuron_index,
                  "explanations": [{
                      "description": f.name,
                      "method": f"miStudio_{f.label_source}",
                      "model": f.labeling_model or "auto",
                      "score": None,
                      "created_at": f.labeled_at.isoformat() + "Z" if f.labeled_at else None
                  }]
              }
              for f in features if f.name and f.name != f"feature_{f.neuron_index}"
          ]
      }
  ```
- [ ] 6.2.4 Implement file organization:
  ```
  export/
  ├── metadata.json
  ├── features/
  │   ├── 0.json
  │   ├── 1.json
  │   └── ...
  ├── explanations/
  │   └── explanations.json
  ├── saelens/
  │   ├── cfg.json
  │   └── sae_weights.safetensors
  └── README.md
  ```

### 6.3 SAELens Format Export
- [ ] 6.3.1 Implement `_generate_saelens_cfg(sae)` with all required fields
- [ ] 6.3.2 Copy/convert SAE weights to saelens/ directory
- [ ] 6.3.3 Generate `pretrained_saes.yaml` entry for SAELens registry

### 6.4 Archive Creation
- [ ] 6.4.1 Implement `_create_archive(output_dir, job_id)`:
  - Create ZIP archive with gzip compression
  - Include all generated files
  - Calculate file size
  - Return archive path
- [ ] 6.4.2 Implement `_generate_readme(sae, config)`:
  - Include upload instructions for Neuronpedia
  - Include HuggingFace upload command
  - Include metadata summary
  - Link to Neuronpedia upload form

---

## Phase 7: Pydantic Schemas

### 7.0 Export Configuration Schemas
- [ ] 7.1 Create `backend/src/schemas/neuronpedia.py`
- [ ] 7.2 Define `NeuronpediaExportConfig`:
  ```python
  class NeuronpediaExportConfig(BaseModel):
      # Output format
      format: Literal["neuronpedia_json", "saelens", "both"] = "both"

      # Feature selection
      feature_selection: Literal["all", "labeled", "custom", "frequency_range"] = "all"
      feature_indices: Optional[List[int]] = None  # For custom selection
      min_activation_frequency: Optional[float] = None
      max_activation_frequency: Optional[float] = None

      # Dashboard data options
      include_examples: bool = True
      examples_per_feature: int = Field(default=20, ge=10, le=100)
      include_logit_lens: bool = True
      logit_lens_k: int = Field(default=20, ge=10, le=50)
      include_histograms: bool = True
      histogram_bins: int = Field(default=50, ge=20, le=100)
      include_token_aggregations: bool = True
      include_explanations: bool = True

      # Compression
      compression: Literal["none", "gzip", "zip"] = "gzip"
  ```
- [ ] 7.3 Define `NeuronpediaExportJobResponse`:
  ```python
  class NeuronpediaExportJobResponse(BaseModel):
      id: str
      sae_id: str
      status: str
      progress: float
      current_stage: Optional[str]
      output_path: Optional[str]
      file_size_bytes: Optional[int]
      feature_count: Optional[int]
      created_at: datetime
      started_at: Optional[datetime]
      completed_at: Optional[datetime]
      error_message: Optional[str]
  ```
- [ ] 7.4 Define `NeuronpediaFeatureJson` schema for validation
- [ ] 7.5 Define `NeuronpediaMetadataJson` schema

### 7.1 Dashboard Data Schemas
- [ ] 7.1.1 Define `LogitLensData`:
  ```python
  class LogitLensToken(BaseModel):
      token: str
      value: float

  class LogitLensData(BaseModel):
      top_positive: List[LogitLensToken]
      top_negative: List[LogitLensToken]
  ```
- [ ] 7.1.2 Define `HistogramData`:
  ```python
  class HistogramData(BaseModel):
      bin_edges: List[float]
      counts: List[int]
      total_count: int
      nonzero_count: int
  ```
- [ ] 7.1.3 Define `TokenAggregation`:
  ```python
  class TokenAggregation(BaseModel):
      token: str
      total_activation: float
      count: int
      mean_activation: float
      max_activation: float
  ```

---

## Phase 8: FastAPI Endpoints

### 8.0 Export API Endpoints
- [ ] 8.1 Create `backend/src/api/v1/endpoints/neuronpedia.py`
- [ ] 8.2 Implement `POST /api/v1/saes/{sae_id}/export/neuronpedia`:
  - Accept `NeuronpediaExportConfig`
  - Validate SAE exists and has features
  - Create export job
  - Enqueue Celery task
  - Return 202 Accepted with job_id
- [ ] 8.3 Implement `GET /api/v1/saes/{sae_id}/export/neuronpedia/status/{job_id}`:
  - Return `NeuronpediaExportJobResponse` with current status
- [ ] 8.4 Implement `GET /api/v1/saes/{sae_id}/export/neuronpedia/download/{job_id}`:
  - Validate job completed successfully
  - Return file download response (StreamingResponse)
- [ ] 8.5 Implement `POST /api/v1/saes/{sae_id}/export/validate`:
  - Validate SAE data completeness
  - Check for missing required fields
  - Return validation report
- [ ] 8.6 Implement `DELETE /api/v1/saes/{sae_id}/export/neuronpedia/{job_id}`:
  - Cancel running job or delete completed job
  - Clean up generated files
- [ ] 8.7 Implement `GET /api/v1/saes/{sae_id}/features/{feature_id}/dashboard`:
  - Return precomputed dashboard data for single feature
  - Compute on-demand if not cached
- [ ] 8.8 Register router in `backend/src/api/v1/router.py`

---

## Phase 9: Celery Tasks

### 9.0 Export Background Tasks
- [ ] 9.1 Create `backend/src/workers/neuronpedia_tasks.py`
- [ ] 9.2 Implement `@celery_app.task neuronpedia_export_task(job_id: str)`:
  ```python
  @celery_app.task(bind=True, max_retries=3)
  def neuronpedia_export_task(self, job_id: str):
      try:
          service = NeuronpediaExportService()
          asyncio.run(service.execute_export(job_id))
      except Exception as e:
          # Update job status to failed
          asyncio.run(service.fail_job(job_id, str(e)))
          raise
  ```
- [ ] 9.3 Add progress tracking via WebSocket emitter
- [ ] 9.4 Implement task cancellation via revoke
- [ ] 9.5 Add retry logic with exponential backoff
- [ ] 9.6 Add to Celery autodiscovery

### 9.1 WebSocket Events
- [ ] 9.1.1 Emit `neuronpedia_export:progress` events:
  ```python
  emit_neuronpedia_export_progress(
      job_id=job_id,
      progress=progress,
      stage=current_stage,
      features_processed=count,
      total_features=total
  )
  ```
- [ ] 9.1.2 Emit `neuronpedia_export:completed` on success
- [ ] 9.1.3 Emit `neuronpedia_export:failed` on error

---

## Phase 10: Frontend Types and API Client

### 10.0 TypeScript Types
- [ ] 10.1 Create `frontend/src/types/neuronpedia.ts`:
  ```typescript
  interface NeuronpediaExportConfig {
    format: 'neuronpedia_json' | 'saelens' | 'both';
    featureSelection: 'all' | 'labeled' | 'custom' | 'frequency_range';
    featureIndices?: number[];
    minActivationFrequency?: number;
    maxActivationFrequency?: number;
    includeExamples: boolean;
    examplesPerFeature: number;
    includeLogitLens: boolean;
    logitLensK: number;
    includeHistograms: boolean;
    histogramBins: number;
    includeTokenAggregations: boolean;
    includeExplanations: boolean;
    compression: 'none' | 'gzip' | 'zip';
  }

  interface NeuronpediaExportJob {
    id: string;
    saeId: string;
    status: 'pending' | 'computing' | 'packaging' | 'completed' | 'failed';
    progress: number;
    currentStage?: string;
    outputPath?: string;
    fileSizeBytes?: number;
    featureCount?: number;
    createdAt: string;
    startedAt?: string;
    completedAt?: string;
    errorMessage?: string;
  }
  ```

### 10.1 API Client
- [ ] 10.1.1 Create `frontend/src/api/neuronpedia.ts`:
  ```typescript
  export async function startExport(
    saeId: string,
    config: NeuronpediaExportConfig
  ): Promise<{ jobId: string }> {
    return fetchAPI(`/saes/${saeId}/export/neuronpedia`, {
      method: 'POST',
      body: JSON.stringify(config),
    });
  }

  export async function getExportStatus(
    saeId: string,
    jobId: string
  ): Promise<NeuronpediaExportJob> {
    return fetchAPI(`/saes/${saeId}/export/neuronpedia/status/${jobId}`);
  }

  export async function downloadExport(
    saeId: string,
    jobId: string
  ): Promise<Blob> {
    return fetchAPIBlob(`/saes/${saeId}/export/neuronpedia/download/${jobId}`);
  }

  export async function validateExport(
    saeId: string
  ): Promise<ValidationReport> {
    return fetchAPI(`/saes/${saeId}/export/validate`, { method: 'POST' });
  }
  ```

---

## Phase 11: Zustand Store

### 11.0 Export Store
- [ ] 11.1 Create `frontend/src/stores/neuronpediaExportStore.ts`:
  ```typescript
  interface NeuronpediaExportState {
    // Current export job
    currentJob: NeuronpediaExportJob | null;

    // Export configuration
    config: NeuronpediaExportConfig;

    // UI state
    isExportDialogOpen: boolean;
    isExporting: boolean;
    error: string | null;

    // Actions
    openExportDialog: (saeId: string) => void;
    closeExportDialog: () => void;
    setConfig: (config: Partial<NeuronpediaExportConfig>) => void;
    startExport: (saeId: string) => Promise<void>;
    pollExportStatus: (saeId: string, jobId: string) => void;
    downloadExport: (saeId: string, jobId: string) => Promise<void>;
    resetExport: () => void;
  }
  ```
- [ ] 11.2 Implement `startExport` action with API call
- [ ] 11.3 Implement `pollExportStatus` with 2-second interval
- [ ] 11.4 Implement WebSocket subscription for real-time updates
- [ ] 11.5 Implement `downloadExport` with file save dialog

---

## Phase 12: Export Dialog UI

### 12.0 Export Configuration Dialog
- [ ] 12.1 Create `frontend/src/components/saes/ExportToNeuronpedia.tsx`
- [ ] 12.2 Implement modal structure (matches PRD Section 7.1):
  ```
  ┌─────────────────────────────────────────────────────────────────┐
  │  Export to Neuronpedia                                      [X] │
  ├─────────────────────────────────────────────────────────────────┤
  │                                                                 │
  │  SAE: gemma-2-2b-layer12-res-16k                               │
  │  Features: 16,384 | Labeled: 12,847 (78%)                      │
  │                                                                 │
  │  [Export Format Section]                                        │
  │  [Feature Selection Section]                                    │
  │  [Dashboard Data Section]                                       │
  │  [Advanced Options Section]                                     │
  │                                                                 │
  │  Estimated size: ~350 MB | Time: ~25 minutes                   │
  │                                                                 │
  │                              [Cancel]  [Validate]  [Export]    │
  └─────────────────────────────────────────────────────────────────┘
  ```
- [ ] 12.3 Implement Export Format section:
  - Radio buttons: Neuronpedia JSON only, Both (recommended), SAELens only
- [ ] 12.4 Implement Feature Selection section:
  - Radio buttons: All features, Labeled only, Custom selection, By frequency
  - Conditional inputs for custom ranges
- [ ] 12.5 Implement Dashboard Data section:
  - Checkboxes for each data type with count indicators
  - Number inputs for configurable values (examples count, logit k, etc.)
- [ ] 12.6 Implement Advanced Options collapsible section:
  - Examples per feature slider (20-100)
  - Logit lens K slider (10-50)
  - Histogram bins slider (20-100)
  - Compression dropdown
- [ ] 12.7 Implement size/time estimation display
- [ ] 12.8 Implement missing data warning banner
- [ ] 12.9 Add "Validate" button with validation report
- [ ] 12.10 Add "Export" button (disabled if validation fails)

### 12.1 Export Progress Dialog
- [ ] 12.1.1 Create `frontend/src/components/saes/ExportProgress.tsx`
- [ ] 12.1.2 Implement progress display (matches PRD Section 7.2):
  ```
  Overall Progress
  [████████████████░░░░░░░░░░░░░░░░░░░░░░░░░░░] 42%

  Current Stage: Computing logit lens data
  [████████████████████████░░░░░░░░░░░░░░░░░░░] 58%
  Features: 9,503 / 16,384

  Stage breakdown table with status icons

  Elapsed: 10:20 | Remaining: ~11:00

  [Cancel Export]  [Run in Background]
  ```
- [ ] 12.1.3 Implement stage breakdown table with status indicators
- [ ] 12.1.4 Implement time elapsed and remaining estimates
- [ ] 12.1.5 Add "Cancel Export" button
- [ ] 12.1.6 Add "Run in Background" button

### 12.2 Export Complete Dialog
- [ ] 12.2.1 Create `frontend/src/components/saes/ExportComplete.tsx`
- [ ] 12.2.2 Implement completion display (matches PRD Section 7.3):
  ```
  ✓ Export Complete

  Export Summary
  • Features exported: 16,384
  • Archive size: 347 MB
  • Export time: 21:45
  • Format: Neuronpedia JSON + SAELens

  Files included list

  Next Steps:
  1. Download the export archive
  2. Fill out Neuronpedia upload form
  3. Coordinate with Neuronpedia team

  [Download Archive]  [Copy HuggingFace Upload Command]
  [Open Neuronpedia Upload Form]  [View Upload Instructions]
  ```
- [ ] 12.2.3 Implement "Download Archive" button with file save
- [ ] 12.2.4 Implement "Copy HuggingFace Upload Command" button
- [ ] 12.2.5 Implement "Open Neuronpedia Upload Form" external link
- [ ] 12.2.6 Implement "View Upload Instructions" modal

---

## Phase 13: SAE Card Integration

### 13.0 Add Export Button to SAE Card
- [ ] 13.1 Modify `frontend/src/components/saes/SAECard.tsx`:
  - Add "Export to Neuronpedia" button in actions area
  - Button style: bg-slate-700 hover:bg-slate-600 with upload icon
  - Only show for SAEs with status='ready' and has features
- [ ] 13.2 Add click handler to open export dialog
- [ ] 13.3 Add tooltip: "Export SAE and features to Neuronpedia format"

### 13.1 Integrate Export Modal in SAEsPanel
- [ ] 13.1.1 Modify `frontend/src/components/panels/SAEsPanel.tsx`:
  - Add `exportingSAE` state
  - Add `handleExport` callback
  - Render `ExportToNeuronpedia` modal when `exportingSAE` is set
- [ ] 13.1.2 Pass `onExport` callback to SAECard components

---

## Phase 14: Validation and Error Handling

### 14.0 Export Validation
- [ ] 14.1 Implement `validate_export_data(sae_id: str)` in export service:
  - Check SAE exists and is ready
  - Check features exist
  - Check required fields present
  - Check for NaN/Inf values
  - Check token encoding issues
  - Return validation report
- [ ] 14.2 Implement validation report schema:
  ```python
  class ValidationReport(BaseModel):
      is_valid: bool
      errors: List[ValidationError]
      warnings: List[ValidationWarning]
      missing_data: MissingDataSummary
      auto_fix_available: bool
  ```
- [ ] 14.3 Implement auto-fix for common issues:
  - Fill missing mean_activation with computed value
  - Clean token encoding issues
  - Remove features with NaN statistics

### 14.1 Error Recovery
- [ ] 14.1.1 Implement partial export recovery:
  - Save progress checkpoints during export
  - Resume from last checkpoint on retry
- [ ] 14.1.2 Implement cleanup on failure:
  - Delete partial output files
  - Update job status with error details

---

## Phase 15: Performance Optimization

### 15.0 Batch Processing Optimization
- [ ] 15.1 Optimize logit lens computation:
  - Process 512 features per batch
  - Use FP16 for intermediate computations
  - Clear CUDA cache between batches
- [ ] 15.2 Optimize histogram computation:
  - Vectorized NumPy operations
  - Process all features in memory if possible
- [ ] 15.3 Optimize JSON generation:
  - Stream write large files
  - Use orjson for faster serialization

### 15.1 Memory Management
- [ ] 15.1.1 Implement streaming export for large SAEs (>100k features)
- [ ] 15.1.2 Add memory monitoring and automatic batch size reduction
- [ ] 15.1.3 Release GPU memory promptly after computation phases

### 15.2 Caching
- [ ] 15.2.1 Cache computed dashboard data in `feature_dashboard_data` table
- [ ] 15.2.2 Skip recomputation for features with valid cached data
- [ ] 15.2.3 Add cache invalidation on feature update

---

## Phase 16: Testing

### 16.0 Backend Unit Tests
- [ ] 16.1 Test TransformerLens hook name mapping
- [ ] 16.2 Test model ID mapping
- [ ] 16.3 Test logit lens computation (mock model weights)
- [ ] 16.4 Test histogram generation with various distributions
- [ ] 16.5 Test token aggregation with edge cases
- [ ] 16.6 Test JSON schema validation
- [ ] 16.7 Test archive creation and structure

### 16.1 Backend Integration Tests
- [ ] 16.1.1 Test full export workflow: start → progress → complete → download
- [ ] 16.1.2 Test export cancellation
- [ ] 16.1.3 Test export with various configurations
- [ ] 16.1.4 Test validation endpoint
- [ ] 16.1.5 Test error handling and recovery

### 16.2 Frontend Tests
- [ ] 16.2.1 Test ExportToNeuronpedia component rendering
- [ ] 16.2.2 Test configuration form validation
- [ ] 16.2.3 Test progress tracking updates
- [ ] 16.2.4 Test download functionality
- [ ] 16.2.5 Test store actions with mocked API

### 16.3 E2E Tests
- [ ] 16.3.1 Test complete export flow: configure → export → download
- [ ] 16.3.2 Verify exported JSON validates against Neuronpedia schema
- [ ] 16.3.3 Test export with real SAE data

---

## Phase 17: Documentation

### 17.0 User Documentation
- [ ] 17.1 Write export user guide: step-by-step instructions
- [ ] 17.2 Write Neuronpedia upload guide: how to submit exported SAEs
- [ ] 17.3 Write configuration options reference
- [ ] 17.4 Write troubleshooting guide: common errors and solutions

### 17.1 API Documentation
- [ ] 17.1.1 Document export endpoints in OpenAPI
- [ ] 17.1.2 Add example requests/responses
- [ ] 17.1.3 Document WebSocket events

### 17.2 Developer Documentation
- [ ] 17.2.1 Document export service architecture
- [ ] 17.2.2 Document JSON schema specifications
- [ ] 17.2.3 Document extension points for custom formats

---

## Implementation Priority

### Critical Path (P0) - Must Have
1. Phase 2: TransformerLens Hook Mapping (foundation)
2. Phase 3: Logit Lens Service (core feature)
3. Phase 4: Histogram Service (core feature)
4. Phase 5: Token Aggregation Service (core feature)
5. Phase 6: Export Service Core (orchestration)
6. Phase 7: Pydantic Schemas (validation)
7. Phase 8: API Endpoints (interface)
8. Phase 12: Export Dialog UI (user interface)

### Secondary (P1) - Important
1. Phase 1: Database Schema (tracking)
2. Phase 9: Celery Tasks (background processing)
3. Phase 10-11: Frontend Types and Store (state management)
4. Phase 13: SAE Card Integration (discoverability)
5. Phase 14: Validation and Error Handling (reliability)

### Polish (P2) - Nice to Have
1. Phase 15: Performance Optimization
2. Phase 16: Testing
3. Phase 17: Documentation

---

## Estimated Effort

| Phase | Tasks | Estimated Hours |
|-------|-------|-----------------|
| Phase 1: Database Schema | 8 | 2h |
| Phase 2: Hook Mapping | 6 | 2h |
| Phase 3: Logit Lens Service | 9 | 6h |
| Phase 4: Histogram Service | 7 | 3h |
| Phase 5: Token Aggregation | 8 | 3h |
| Phase 6: Export Service | 15 | 8h |
| Phase 7: Pydantic Schemas | 7 | 2h |
| Phase 8: API Endpoints | 9 | 4h |
| Phase 9: Celery Tasks | 7 | 3h |
| Phase 10: Frontend Types | 4 | 1h |
| Phase 11: Zustand Store | 6 | 2h |
| Phase 12: Export Dialog UI | 18 | 8h |
| Phase 13: SAE Card Integration | 4 | 1h |
| Phase 14: Validation | 7 | 3h |
| Phase 15: Performance | 8 | 4h |
| Phase 16: Testing | 18 | 8h |
| Phase 17: Documentation | 9 | 4h |
| **Total** | **~150** | **~64h** |

---

## Success Metrics

### Technical Metrics
| Metric | Target | Measurement |
|--------|--------|-------------|
| Export speed (16k features, GPU) | < 30 min | Automated benchmark |
| Export success rate | > 99% | Export job completion rate |
| Data validation pass rate | 100% | Schema validation results |
| Memory usage (16k features) | < 16 GB | Peak memory monitoring |

### Quality Metrics
| Metric | Target | Measurement |
|--------|--------|-------------|
| Neuronpedia import success | 100% | Manual verification |
| Feature dashboard completeness | 100% | Required field coverage |
| Explanation preservation | 100% | Label export accuracy |

---

## Notes

- **Native Implementation**: No SAEDashboard dependency - all computation done natively in miStudio
- **Dual Format**: Export both Neuronpedia JSON and SAELens format in single operation
- **Incremental Export**: Support exporting only new/changed features
- **Neuronpedia Coordination**: Manual upload process via form (no direct API yet)
- **Cache Strategy**: Compute dashboard data on first export, cache for future exports
- **TransformerLens Compatibility**: Hook names and model IDs must match exactly
- **Schema Versioning**: Track export_version for forward compatibility
- **File Size**: Aim for < 500MB for 16k features with compression

---

## Dependencies

### Internal Dependencies
- SAE training module (complete)
- Feature extraction pipeline (complete)
- Labeling service (complete)
- HuggingFace upload (complete)
- Community format export (complete)

### External Dependencies
- Neuronpedia schema documentation (available)
- TransformerLens model support (available)
- Neuronpedia upload process (manual, documented)
- Community SAELens format (stable)

### New Dependencies
```python
# No new major dependencies required
# Existing dependencies sufficient:
# - torch (GPU computation)
# - safetensors (weight serialization)
# - numpy (numerical operations)
# - gzip/zipfile (compression - standard library)
# - orjson (optional, faster JSON - already in requirements)
```

---

**Last Updated:** 2025-12-04
**Status:** Ready for Implementation
**Estimated Total Effort:** ~64 hours (8-10 working days)
