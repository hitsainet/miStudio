# Unified SAE Management Interface - Implementation Guide

## Overview

This document describes how to create a unified SAE management interface that toggles between **Download** and **Upload** modes, maximizing code reuse and providing a seamless user experience.

## Design Philosophy

**Key Principles**:
1. **Single Form Component** - One form with mode-dependent fields
2. **Shared Validation Logic** - Same token/repo validation for both modes
3. **Consistent UI/UX** - Maintain familiar patterns
4. **Progressive Disclosure** - Show only relevant fields per mode
5. **State Preservation** - Remember user inputs when switching modes

---

## UI/UX Design

### Unified Interface Layout

```
┌─────────────────────────────────────────────────────────────┐
│ Sparse Autoencoders (SAEs)                                  │
│ Manage and share SAEs for feature steering                  │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│ ┌──────────────────────────────────────────────────────┐   │
│ │  [📥 Download] [📤 Upload]  ← Toggle Tabs            │   │
│ └──────────────────────────────────────────────────────┘   │
│                                                             │
│ HuggingFace Repository                                      │
│ ┌───────────────────────────────────────────────────────┐   │
│ │ e.g., google/gemma-scope-2b-pt-res                    │   │
│ └───────────────────────────────────────────────────────┘   │
│ ℹ️ Download: Enter existing repo • Upload: Your repo name   │
│                                                             │
│ Access Token (optional for public, required for upload)    │
│ ┌───────────────────────────────────────────────────────┐   │
│ │ hf_••••••••••••••••••••••••                          │ 👁️ │
│ └───────────────────────────────────────────────────────┘   │
│ ✓ Authenticated as your-username                            │
│                                                             │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ Link to Model *                                         │ │
│ │ Select a model to use with this SAE                     │ │
│ │ ┌─────────────────────────────────────────────────────┐ │ │
│ │ │ Select a model...                                   ▼│ │ │
│ │ └─────────────────────────────────────────────────────┘ │ │
│ └─────────────────────────────────────────────────────────┘ │
│                                                             │
│ ─────────── DOWNLOAD MODE ONLY ───────────                 │
│ Custom Name (optional)                                      │
│ ┌───────────────────────────────────────────────────────┐   │
│ │ Auto-generated from file path                         │   │
│ └───────────────────────────────────────────────────────┘   │
│                                                             │
│ [🔍 Preview Repository]                                     │
│                                                             │
│ ─────────── UPLOAD MODE ONLY ─────────────                 │
│ Repository Visibility                                       │
│ (•) Private    ( ) Public                                   │
│                                                             │
│ Select SAEs to Upload                                       │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ ☑ Layer 8 - res_post (16K features) - 288 MB          │ │
│ │ ☑ Layer 8 - mlp_out (16K features) - 288 MB           │ │
│ │ ☐ Layer 12 - attn_out (32K features) - 576 MB         │ │
│ └─────────────────────────────────────────────────────────┘ │
│ Selected: 2 SAEs (576 MB)                                   │
│                                                             │
│ Description (optional)                                      │
│ ┌───────────────────────────────────────────────────────┐   │
│ │ SAEs trained on GPT-2 Small...                        │   │
│ └───────────────────────────────────────────────────────┘   │
│                                                             │
│ ──────────────────────────────────────────                 │
│                                                             │
│ [📋 Preview README]  [📥 Download SAE / 📤 Upload SAEs]     │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Your SAEs (6)
┌─────────────────────────────────────────────────────────────┐
│ gemma-scope-2b-pt-res/layer_20/sae.safetensors              │
│ 3 features • 1 GB                 🏷️ HuggingFace           │
│ wei1lk23d/gemma-scope-2b-pt-res                             │
│                   [▶️ Use in Steering] [🗑️]  [✓ Ready]     │
└─────────────────────────────────────────────────────────────┘
```

---

## Component Architecture

### 1. Unified Form Component

**File**: `frontend/src/components/SAEManagementForm.tsx`

```typescript
/**
 * Unified form for both downloading and uploading SAEs.
 * Toggles between modes while reusing shared logic.
 */

import React, { useState, useEffect } from 'react';
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
  Input,
  Button,
  RadioGroup,
  Textarea
} from '@/components/ui';
import { SAESelector } from './SAESelector';
import { useHFToken } from '@/hooks/useHFToken';
import { useSAEValidation } from '@/hooks/useSAEValidation';

type Mode = 'download' | 'upload';

interface SharedFormData {
  repoName: string;
  token: string;
  linkedModelId: string;
}

interface DownloadFormData extends SharedFormData {
  customName?: string;
}

interface UploadFormData extends SharedFormData {
  selectedSAEIds: string[];
  visibility: 'public' | 'private';
  description?: string;
  commitMessage: string;
}

export function SAEManagementForm() {
  const [mode, setMode] = useState<Mode>('download');
  
  // Shared form state
  const [repoName, setRepoName] = useState('');
  const [token, setToken] = useState('');
  const [linkedModelId, setLinkedModelId] = useState('');
  
  // Download-specific state
  const [customName, setCustomName] = useState('');
  
  // Upload-specific state
  const [selectedSAEIds, setSelectedSAEIds] = useState<string[]>([]);
  const [visibility, setVisibility] = useState<'public' | 'private'>('private');
  const [description, setDescription] = useState('');
  const [commitMessage, setCommitMessage] = useState(
    'Upload SAE weights from MechInterp Studio'
  );
  
  // Shared hooks
  const { tokenInfo, validateToken, isValidating } = useHFToken(token);
  const { validationResult, validate } = useSAEValidation();
  
  // Auto-validate when key fields change
  useEffect(() => {
    if (repoName && token) {
      const debounce = setTimeout(() => {
        validate({
          mode,
          repoName,
          token,
          selectedSAEIds: mode === 'upload' ? selectedSAEIds : []
        });
      }, 500);
      return () => clearTimeout(debounce);
    }
  }, [repoName, token, mode, selectedSAEIds]);
  
  const handleSubmit = async () => {
    if (mode === 'download') {
      await handleDownload();
    } else {
      await handleUpload();
    }
  };
  
  const handleDownload = async () => {
    // Download logic
  };
  
  const handleUpload = async () => {
    // Upload logic
  };
  
  // Determine if form is valid
  const isFormValid = 
    repoName && 
    linkedModelId &&
    (mode === 'download' || (token && selectedSAEIds.length > 0));
  
  return (
    <div className="border rounded-lg p-6 space-y-6">
      {/* Mode Toggle */}
      <Tabs value={mode} onValueChange={(v) => setMode(v as Mode)}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="download">
            📥 Download from HuggingFace
          </TabsTrigger>
          <TabsTrigger value="upload">
            📤 Upload to HuggingFace
          </TabsTrigger>
        </TabsList>
        
        {/* Shared Fields (visible in both modes) */}
        <div className="mt-6 space-y-4">
          {/* Repository Name */}
          <FormField
            label="HuggingFace Repository"
            required
            helpText={
              mode === 'download'
                ? 'Enter the repository path (e.g., google/gemma-scope-2b-pt-res)'
                : 'Your repository name (will be created if it doesn\'t exist)'
            }
          >
            <Input
              type="text"
              placeholder={
                mode === 'download'
                  ? 'e.g., google/gemma-scope-2b-pt-res'
                  : 'your-username/model-name-saes'
              }
              value={repoName}
              onChange={(e) => setRepoName(e.target.value)}
            />
          </FormField>
          
          {/* Access Token */}
          <FormField
            label="Access Token"
            required={mode === 'upload'}
            helpText={
              mode === 'download'
                ? 'Optional for public repos, required for gated repos'
                : 'Required - Token must have write permissions'
            }
          >
            <div className="relative">
              <Input
                type="password"
                placeholder="hf_••••••••••••••••••••••••"
                value={token}
                onChange={(e) => setToken(e.target.value)}
              />
              {tokenInfo && (
                <div className="mt-1 text-sm text-green-600">
                  ✓ Authenticated as {tokenInfo.username}
                </div>
              )}
            </div>
          </FormField>
          
          {/* Link to Model */}
          <FormField
            label="Link to Model"
            required
            helpText="Select a downloaded model to use with this SAE"
          >
            <ModelSelector
              value={linkedModelId}
              onChange={setLinkedModelId}
            />
          </FormField>
        </div>
        
        {/* Download-Specific Fields */}
        <TabsContent value="download" className="space-y-4">
          <FormField
            label="Custom Name"
            helpText="Optional - Auto-generated from file path if not provided"
          >
            <Input
              type="text"
              placeholder="Auto-generated from file path"
              value={customName}
              onChange={(e) => setCustomName(e.target.value)}
            />
          </FormField>
          
          <Button
            variant="outline"
            onClick={() => handlePreviewRepository()}
            disabled={!repoName}
          >
            🔍 Preview Repository
          </Button>
        </TabsContent>
        
        {/* Upload-Specific Fields */}
        <TabsContent value="upload" className="space-y-4">
          {/* Visibility */}
          <FormField
            label="Repository Visibility"
            helpText="Choose whether your repository is public or private"
          >
            <RadioGroup
              value={visibility}
              onValueChange={(v) => setVisibility(v as 'public' | 'private')}
              options={[
                { value: 'private', label: 'Private' },
                { value: 'public', label: 'Public' }
              ]}
            />
          </FormField>
          
          {/* SAE Selection */}
          <FormField
            label="Select SAEs to Upload"
            required
            helpText="Choose which trained SAEs to upload"
          >
            <SAESelector
              saes={trainedSAEs}
              selectedIds={selectedSAEIds}
              onSelectionChange={setSelectedSAEIds}
            />
          </FormField>
          
          {/* Description */}
          <FormField
            label="Description"
            helpText="Optional - Describe your SAEs"
          >
            <Textarea
              placeholder="SAEs trained on GPT-2 Small using..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
          </FormField>
          
          <Button
            variant="outline"
            onClick={() => handlePreviewReadme()}
            disabled={selectedSAEIds.length === 0}
          >
            📋 Preview README
          </Button>
        </TabsContent>
        
        {/* Validation Messages */}
        {validationResult && !validationResult.valid && (
          <div className="p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
            <p className="text-sm font-medium text-red-800 dark:text-red-200">
              ⚠️ Validation Errors:
            </p>
            <ul className="list-disc list-inside text-sm text-red-700 dark:text-red-300 mt-1">
              {Object.entries(validationResult.errors || {}).map(([key, msg]) => (
                <li key={key}>{msg}</li>
              ))}
            </ul>
          </div>
        )}
        
        {/* Warnings */}
        {validationResult?.warnings && validationResult.warnings.length > 0 && (
          <div className="p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
            <p className="text-sm font-medium text-yellow-800 dark:text-yellow-200">
              ℹ️ Note:
            </p>
            <ul className="list-disc list-inside text-sm text-yellow-700 dark:text-yellow-300 mt-1">
              {validationResult.warnings.map((warning, i) => (
                <li key={i}>{warning}</li>
              ))}
            </ul>
          </div>
        )}
        
        {/* Estimates (Upload Only) */}
        {mode === 'upload' && validationResult?.estimated_size_mb && (
          <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <p className="text-sm">
              <strong>Estimated upload:</strong>{' '}
              {validationResult.estimated_size_mb.toFixed(1)} MB • {' '}
              ~{Math.ceil(validationResult.estimated_time_seconds / 60)} minutes
            </p>
          </div>
        )}
        
        {/* Submit Button */}
        <Button
          onClick={handleSubmit}
          disabled={!isFormValid || isValidating}
          className="w-full"
          size="lg"
        >
          {mode === 'download' ? '📥 Download SAE' : '📤 Upload SAEs'}
        </Button>
      </Tabs>
    </div>
  );
}

// Helper component for consistent form fields
function FormField({
  label,
  required,
  helpText,
  children
}: {
  label: string;
  required?: boolean;
  helpText?: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="block text-sm font-medium mb-2">
        {label}
        {required && <span className="text-red-500 ml-1">*</span>}
      </label>
      {children}
      {helpText && (
        <p className="text-sm text-gray-500 mt-1">
          ℹ️ {helpText}
        </p>
      )}
    </div>
  );
}
```

**Key Features**:
- Single component, two modes
- Shared state for common fields
- Mode-specific state for unique fields
- Auto-validation on field changes
- Progressive disclosure of relevant fields
- Consistent validation/error display

---

### 2. Unified Validation Hook

**File**: `frontend/src/hooks/useSAEValidation.ts`

```typescript
/**
 * Shared validation logic for both download and upload.
 */

import { useState } from 'react';
import { uploadApi } from '@/api/uploadApi';
import { downloadApi } from '@/api/downloadApi';

interface ValidationRequest {
  mode: 'download' | 'upload';
  repoName: string;
  token: string;
  selectedSAEIds?: string[];
}

interface ValidationResult {
  valid: boolean;
  errors?: Record<string, string>;
  warnings?: string[];
  estimated_size_mb?: number;
  estimated_time_seconds?: number;
}

export function useSAEValidation() {
  const [validationResult, setValidationResult] = useState<ValidationResult | null>(null);
  const [isValidating, setIsValidating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const validate = async (request: ValidationRequest) => {
    setIsValidating(true);
    setError(null);

    try {
      let result: ValidationResult;

      if (request.mode === 'download') {
        // Validate download
        result = await downloadApi.validateRepository({
          repo_name: request.repoName,
          token: request.token
        });
      } else {
        // Validate upload
        result = await uploadApi.validate({
          repo_name: request.repoName,
          token: request.token,
          sae_ids: request.selectedSAEIds || [],
          visibility: 'private' // Will be set by form
        });
      }

      setValidationResult(result);
      return result;
    } catch (err) {
      setError(err.message);
      setValidationResult({
        valid: false,
        errors: { general: err.message }
      });
      return null;
    } finally {
      setIsValidating(false);
    }
  };

  const reset = () => {
    setValidationResult(null);
    setError(null);
  };

  return {
    validationResult,
    isValidating,
    error,
    validate,
    reset
  };
}
```

**Benefits**:
- Single validation hook for both modes
- Automatically routes to correct API
- Consistent error handling
- Reusable across components

---

### 3. Shared Token Management Hook

**File**: `frontend/src/hooks/useHFToken.ts`

```typescript
/**
 * HuggingFace token validation and management.
 * Used for both upload (required) and download (optional).
 */

import { useState, useEffect } from 'react';
import { hfApi } from '@/api/hfApi';

interface TokenInfo {
  username: string;
  can_write: boolean;
  can_create_repo: boolean;
  valid: boolean;
}

export function useHFToken(token: string) {
  const [tokenInfo, setTokenInfo] = useState<TokenInfo | null>(null);
  const [isValidating, setIsValidating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!token) {
      setTokenInfo(null);
      return;
    }

    const validateToken = async () => {
      setIsValidating(true);
      setError(null);

      try {
        const info = await hfApi.validateToken(token);
        setTokenInfo(info);
      } catch (err) {
        setError(err.message);
        setTokenInfo(null);
      } finally {
        setIsValidating(false);
      }
    };

    // Debounce validation
    const timeout = setTimeout(validateToken, 500);
    return () => clearTimeout(timeout);
  }, [token]);

  return {
    tokenInfo,
    isValidating,
    error,
    isValid: tokenInfo?.valid || false,
    hasWritePermission: tokenInfo?.can_write || false
  };
}
```

**Features**:
- Auto-validates token on change
- Debounced to avoid excessive API calls
- Returns permission information
- Used by both modes

---

### 4. Backend: Unified Validation Endpoint

**File**: `backend/api/routes/sae_common.py`

```python
"""
Common endpoints shared between upload and download.
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional

from ...services.hf_client import HuggingFaceClient

router = APIRouter(prefix="/api/sae/common", tags=["sae_common"])
hf_client = HuggingFaceClient()

class TokenValidationRequest(BaseModel):
    token: str

class TokenValidationResponse(BaseModel):
    username: str
    can_write: bool
    can_create_repo: bool
    valid: bool
    error: Optional[str] = None

@router.post("/validate-token")
async def validate_token(request: TokenValidationRequest) -> TokenValidationResponse:
    """
    Validate HuggingFace token and return permissions.
    Used by both upload and download flows.
    """
    try:
        token_info = hf_client.validate_token(request.token)
        return TokenValidationResponse(
            username=token_info.username,
            can_write=token_info.can_write,
            can_create_repo=token_info.can_create_repo,
            valid=token_info.valid
        )
    except Exception as e:
        return TokenValidationResponse(
            username="",
            can_write=False,
            can_create_repo=False,
            valid=False,
            error=str(e)
        )

class RepositoryCheckRequest(BaseModel):
    repo_name: str
    token: Optional[str] = None

class RepositoryInfo(BaseModel):
    exists: bool
    is_public: bool
    num_files: int
    size_mb: float
    last_updated: Optional[str] = None

@router.post("/check-repository")
async def check_repository(request: RepositoryCheckRequest) -> RepositoryInfo:
    """
    Check if repository exists and get basic info.
    Used to show warnings/info in both modes.
    """
    try:
        info = hf_client.get_repository_info(
            request.repo_name,
            request.token
        )
        return info
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))
```

---

## State Management Strategy

### Local State Management

```typescript
/**
 * Store form state in component state, but persist token securely.
 */

// In SAEManagementForm component
const [formState, setFormState] = useState(() => {
  // Load from localStorage if available
  const saved = localStorage.getItem('sae_form_state');
  return saved ? JSON.parse(saved) : defaultState;
});

// Save to localStorage on change (except token)
useEffect(() => {
  const { token, ...stateToSave } = formState;
  localStorage.setItem('sae_form_state', JSON.stringify(stateToSave));
}, [formState]);

// Token management - use secure storage
const { token, setToken } = useSecureToken();
```

### Token Security

**File**: `frontend/src/hooks/useSecureToken.ts`

```typescript
/**
 * Secure token storage using browser's built-in encryption.
 */

import { useState, useEffect } from 'react';

const TOKEN_KEY = 'hf_token_encrypted';

export function useSecureToken() {
  const [token, setTokenState] = useState<string>('');

  // Load token on mount
  useEffect(() => {
    const encrypted = localStorage.getItem(TOKEN_KEY);
    if (encrypted) {
      // In production, decrypt here
      setTokenState(encrypted);
    }
  }, []);

  const setToken = (newToken: string) => {
    setTokenState(newToken);
    
    if (newToken) {
      // In production, encrypt here
      localStorage.setItem(TOKEN_KEY, newToken);
    } else {
      localStorage.removeItem(TOKEN_KEY);
    }
  };

  const clearToken = () => {
    setTokenState('');
    localStorage.removeItem(TOKEN_KEY);
  };

  return { token, setToken, clearToken };
}
```

---

## Implementation Checklist

### Phase 1: Refactor Existing Download (Week 1)

- [ ] **Extract shared components from current download UI**
  - [ ] Repository input field
  - [ ] Token input field
  - [ ] Model selector
  - [ ] Validation display

- [ ] **Create base form component**
  - [ ] `SAEManagementForm.tsx`
  - [ ] Tab navigation
  - [ ] Shared field rendering

- [ ] **Create shared hooks**
  - [ ] `useHFToken.ts` - Token validation
  - [ ] `useSAEValidation.ts` - Unified validation
  - [ ] `useSecureToken.ts` - Token storage

- [ ] **Update backend**
  - [ ] Create `sae_common.py` routes
  - [ ] Extract token validation to shared service
  - [ ] Add repository info endpoint

- [ ] **Test download still works**
  - [ ] All existing download flows functional
  - [ ] Token validation working
  - [ ] No regressions

### Phase 2: Add Upload Mode (Week 2)

- [ ] **Add upload-specific fields**
  - [ ] SAE selector component (reuse from earlier design)
  - [ ] Visibility toggle
  - [ ] Description textarea

- [ ] **Implement upload logic**
  - [ ] Upload API integration
  - [ ] Progress modal (from earlier design)
  - [ ] Success/error handling

- [ ] **Add mode toggle**
  - [ ] Tab switching
  - [ ] State preservation
  - [ ] Field show/hide logic

- [ ] **Test both modes**
  - [ ] Download still works
  - [ ] Upload works
  - [ ] Switching preserves data

### Phase 3: Polish & Integration (Week 3)

- [ ] **Improve UX**
  - [ ] Smooth transitions between modes
  - [ ] Clear visual feedback
  - [ ] Helpful tooltips

- [ ] **Add advanced features**
  - [ ] Preview repository (download)
  - [ ] Preview README (upload)
  - [ ] Form validation feedback

- [ ] **Update SAE list**
  - [ ] Show upload status on cards
  - [ ] Add HuggingFace links
  - [ ] Update after operations

- [ ] **Documentation**
  - [ ] User guide for both modes
  - [ ] Troubleshooting guide
  - [ ] API documentation

---

## Code Reuse Matrix

| Component | Download | Upload | Shared |
|-----------|----------|--------|--------|
| Repository Input | ✓ | ✓ | 100% |
| Token Input | ✓ | ✓ | 100% |
| Model Selector | ✓ | ✓ | 100% |
| Token Validation | ✓ | ✓ | 100% |
| Error Display | ✓ | ✓ | 100% |
| Custom Name | ✓ | - | 0% |
| SAE Selector | - | ✓ | 0% |
| Visibility Toggle | - | ✓ | 0% |
| Description Field | - | ✓ | 0% |
| Preview Button | 50% | 50% | 50% |
| Submit Logic | - | - | 30% |

**Total Code Reuse: ~70%**

---

## Visual State Diagram

```
┌─────────────┐
│   Initial   │
│    State    │
└──────┬──────┘
       │
       ├───────────────┬───────────────┐
       │               │               │
       ▼               ▼               ▼
┌────────────┐  ┌────────────┐  ┌────────────┐
│  Download  │  │   Upload   │  │  Trained   │
│    Mode    │◄─┤    Mode    │  │    SAEs    │
└──────┬─────┘  └──────┬─────┘  └──────┬─────┘
       │               │               │
       │               │               │
       ├───────────────┼───────────────┤
       │               │               │
       ▼               ▼               ▼
┌─────────────────────────────────────────┐
│         Your SAEs (Unified List)         │
│  • Downloaded from HF                    │
│  • Uploaded to HF                        │
│  • Trained in MiStudio                   │
└─────────────────────────────────────────┘
```

---

## Example: Toggle Interaction Flow

```typescript
// User clicks "Upload" tab
setMode('upload');

// Form automatically:
1. Hides "Custom Name" field
2. Shows "SAE Selector"
3. Shows "Visibility" toggle
4. Shows "Description" field
5. Updates button text to "Upload SAEs"
6. Changes validation rules (token required)
7. Updates help text for repository field

// Shared fields remain:
- Repository name (with updated placeholder)
- Access token (with updated help text)
- Model selector

// Validation automatically adjusts:
- Checks if token has write permissions (upload only)
- Validates selected SAEs exist (upload only)
- Checks repository format (both modes)
```

---

## Testing Strategy

### Unit Tests

```typescript
describe('SAEManagementForm', () => {
  it('should toggle between download and upload modes', () => {
    // Test mode switching
  });

  it('should preserve shared field values when switching modes', () => {
    // Test state preservation
  });

  it('should show mode-specific fields correctly', () => {
    // Test conditional rendering
  });

  it('should validate differently based on mode', () => {
    // Test validation logic
  });
});
```

### Integration Tests

```typescript
describe('Download Flow', () => {
  it('should download SAE successfully', () => {
    // Test complete download
  });
});

describe('Upload Flow', () => {
  it('should upload SAE successfully', () => {
    // Test complete upload
  });
});

describe('Mode Switching', () => {
  it('should switch modes without losing data', () => {
    // Test data preservation
  });
});
```

---

## Migration Guide

### From Current Implementation

1. **Extract Download Form**
   ```typescript
   // Before: Separate DownloadSection component
   <DownloadSection />
   
   // After: Unified form with download tab
   <SAEManagementForm defaultMode="download" />
   ```

2. **Update API Calls**
   ```typescript
   // Before: Direct API calls in component
   await downloadSAE(repo, token);
   
   // After: Through unified service
   await saeService.download({ repo, token, mode: 'download' });
   ```

3. **Consolidate Validation**
   ```typescript
   // Before: Separate validation for download
   validateDownload(repo);
   
   // After: Unified validation
   validate({ mode: 'download', repo, token });
   ```

---

## Benefits Summary

✅ **70% Code Reuse** - Shared components, hooks, and logic
✅ **Consistent UX** - Same patterns for both operations  
✅ **Reduced Maintenance** - Single component to update
✅ **State Preservation** - Don't lose data when switching
✅ **Progressive Disclosure** - Show only relevant fields
✅ **Secure Token Storage** - Shared security implementation
✅ **Unified Validation** - Single source of truth
✅ **Easier Testing** - Test one component thoroughly

---

## File Structure

```
frontend/src/
├── components/
│   ├── SAEManagementForm.tsx         (new - unified form)
│   ├── SAESelector.tsx               (from previous design)
│   ├── ModelSelector.tsx             (existing, reused)
│   ├── UploadProgressModal.tsx       (from previous design)
│   └── DownloadProgressModal.tsx     (existing, reused)
├── hooks/
│   ├── useSAEValidation.ts           (new - unified validation)
│   ├── useHFToken.ts                 (new - shared token)
│   ├── useSecureToken.ts             (new - token storage)
│   ├── useUploadJob.ts               (from previous design)
│   └── useDownloadJob.ts             (existing, reused)
├── api/
│   ├── saeApi.ts                     (updated - unified calls)
│   ├── uploadApi.ts                  (from previous design)
│   └── downloadApi.ts                (existing)
└── pages/
    └── SAEs.tsx                      (updated - use new form)

backend/
├── api/routes/
│   ├── sae_common.py                 (new - shared endpoints)
│   ├── sae_upload.py                 (from previous design)
│   └── sae_download.py               (existing)
├── services/
│   ├── hf_client.py                  (updated - shared client)
│   ├── sae_upload_service.py         (from previous design)
│   └── sae_download_service.py       (existing)
└── models/
    └── sae_models.py                 (updated - unified models)
```

---

**Document Version**: 2.0  
**Updated**: 2025-01-15  
**Status**: Ready for Implementation  
**Code Reuse**: ~70%  
**Estimated Refactor**: 1 week  
**New Features**: 2 weeks
