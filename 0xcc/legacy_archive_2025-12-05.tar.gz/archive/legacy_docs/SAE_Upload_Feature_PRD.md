# Product Requirements Document: SAE Upload to HuggingFace

## 1. Executive Summary

### 1.1 Overview
This PRD defines requirements for adding SAE upload capabilities to the existing SAE management page in MechInterp Studio. Users can already download SAEs from HuggingFace; this feature enables them to upload their trained SAEs back to HuggingFace, completing the bidirectional workflow.

### 1.2 Value Proposition
- **For Researchers**: Share trained SAEs with the community
- **For Organizations**: Publish proprietary SAEs to private repos
- **For the Ecosystem**: Contribute to the growing library of interpretability tools
- **For Users**: Seamless round-trip workflow (train → upload → share → download)

### 1.3 Success Metrics
- Upload completion rate: >95%
- Time to upload SAE: <2 minutes
- User satisfaction with upload UX: >4/5
- Successful uploads per week: >10

---

## 2. Current State Analysis

### 2.1 Existing SAE Page Capabilities
Based on the screenshots provided:

**Download Functionality**:
- HuggingFace Repository input field
- Access Token input (optional, for gated repos)
- "Link to Model" dropdown
- "Preview Repository" button
- SAE list showing downloaded SAEs with metadata

**SAE Display**:
- Name/path display
- Size and feature count
- Source indicator (HuggingFace badge or "Trained" badge)
- Status indicator (Ready checkmark)
- "Use in Steering" action button
- Delete action button

### 2.2 Architecture Context
- Frontend: React-based UI
- Backend: FastAPI (Python)
- SAE Format: SAELens compatible (.safetensors)
- Storage: Local filesystem with database tracking
- External Integration: HuggingFace Hub API

---

## 3. Functional Requirements

### 3.1 Unified Interface Design

**FR-1.1: Toggle Interface**
- MUST use tabbed interface to toggle between "Download" and "Upload" modes
- MUST share common form fields between modes (Repository, Token, Model)
- MUST show/hide mode-specific fields based on active tab
- MUST preserve form state when switching between modes
- SHOULD maximize code reuse (~70%) between modes

**FR-1.2: Shared Form Fields (Both Modes)**
- MUST include:
  1. **Repository Name** field
     - Download: "Enter existing repository (e.g., google/gemma-scope-2b-pt-res)"
     - Upload: "Your repository name (will be created if needed)"
  2. **Access Token** field
     - Download: Optional for public repos, required for gated
     - Upload: Required with write permissions
  3. **Link to Model** dropdown
     - Select model to use with SAE(s)
     - Same for both modes

**FR-1.3: Download-Specific Fields**
- MUST include:
  1. **Custom Name** field (optional)
     - Auto-generated from file path if not provided
  2. **Preview Repository** button
     - Shows repository contents before downloading

**FR-1.4: Upload-Specific Fields**
- MUST include:
  1. **SAE Selection** (checklist/multi-select)
     - Show all locally trained SAEs (filtered by "Trained" badge)
     - Display: name, size, feature count, layer info
     - Allow selecting multiple SAEs for batch upload
  2. **Repository Visibility** (radio buttons)
     - Options: Public / Private
     - Default: Private
  3. **Description** (textarea, optional)
     - Placeholder: "Describe your SAEs..."
     - Max length: 500 characters
  4. **Preview README** button
     - Generate and show README before upload

**FR-1.5: Mode Toggle Behavior**
- MUST preserve shared field values when switching modes
- MUST show appropriate help text based on mode
- MUST update validation rules based on mode
- MUST update submit button text ("Download SAE" vs "Upload SAEs")
- MUST clear mode-specific errors when switching

**FR-1.6: Unified Validation**
- MUST validate repository name format (both modes)
- MUST validate token permissions (write required for upload only)
- MUST validate model selection (both modes)
- MUST validate SAE selection (upload only)
- MUST show consistent error/warning display for both modes
- MUST provide "Upload to HuggingFace" button
- MUST be disabled when no SAEs selected or token missing
- MUST show loading state during upload
- MUST display progress for multi-SAE uploads

### 3.2 SAE Organization & Structure

**FR-2.1: Automatic Organization**
- MUST organize uploaded SAEs by:
  - Layer number
  - Hook type (res_post, mlp_out, attn_out, etc.)
  - Width (feature count)
- MUST follow Gemma-Scope directory structure:
  ```
  layer_{n}/{hook_type}/width_{d_sae}/
  ├── params.json
  └── sae_weights.safetensors
  ```

**FR-2.2: Metadata Generation**
- MUST generate `params.json` for each SAE containing:
  - d_model, d_sae
  - hook_point, hook_layer
  - activation_fn
  - normalize_activations
  - model_name
  - training configuration (steps, l1_coefficient, etc.)
- MUST extract metadata from SAE object or training records

**FR-2.3: README Generation**
- MUST auto-generate comprehensive README.md including:
  - Model information
  - SAE coverage (layers, components)
  - Usage examples (SAELens and TransformerLens)
  - Training details
  - Citation information
- SHOULD allow user to preview/edit before upload

### 3.3 Upload Process

**FR-3.1: Validation**
- MUST validate before upload:
  - Token has write permissions
  - Repository name is valid
  - Selected SAEs are complete
  - No conflicting files in target repo
- MUST show clear validation errors

**FR-3.2: Upload Execution**
- MUST create repository if it doesn't exist
- MUST upload files in organized structure
- MUST handle large files (>1GB) properly
- MUST support resuming failed uploads
- SHOULD batch upload multiple SAEs efficiently

**FR-3.3: Progress Tracking**
- MUST show:
  - Overall progress (X of Y SAEs uploaded)
  - Per-SAE progress
  - Current operation (organizing, uploading weights, etc.)
  - Estimated time remaining
- MUST allow cancellation

**FR-3.4: Completion & Feedback**
- MUST show success message with:
  - Repository URL
  - Number of SAEs uploaded
  - "View on HuggingFace" link
- MUST update SAE list to show HuggingFace badge
- MUST log upload in activity/history
- SHOULD offer to share on social media

### 3.4 Error Handling

**FR-4.1: Common Error Scenarios**
- MUST handle gracefully:
  - Invalid or expired token
  - Network failures
  - Repository already exists with conflicts
  - Insufficient permissions
  - Rate limiting
  - Out of storage quota
- MUST provide actionable error messages

**FR-4.2: Partial Failures**
- MUST track which SAEs succeeded/failed in batch
- MUST allow retrying failed uploads
- MUST not corrupt repository on partial failure

### 3.5 Integration with Existing Features

**FR-5.1: SAE List Updates**
- MUST add upload status indicator to SAE cards:
  - "Uploaded to [repo-name]" badge
  - Link to HuggingFace repository
- MUST update immediately after successful upload

**FR-5.2: Token Management**
- SHOULD remember token securely (encrypted)
- SHOULD validate token on paste
- SHOULD indicate token permissions level

**FR-5.3: Link to Model**
- SHOULD use existing model linkage to auto-fill model_name
- SHOULD validate SAE-model compatibility before upload

---

## 4. Non-Functional Requirements

### 4.1 Performance
- Upload preparation: <5 seconds
- Large SAE upload (1GB): <3 minutes on typical connection
- UI responsiveness during upload: <100ms

### 4.2 Usability
- Upload workflow completion time: <2 minutes
- Error message clarity: >90% user comprehension
- Mobile-responsive design

### 4.3 Security
- Token storage: Encrypted at rest
- HTTPS-only communication
- No token logging
- Clear security warnings

### 4.4 Reliability
- Upload success rate: >95%
- Automatic retry on transient failures
- Data integrity verification

---

## 5. User Interface Specifications

### 5.1 Unified SAE Management Interface

**Overview**: Single interface with tab toggle between Download and Upload modes

```
┌─────────────────────────────────────────────────────────────┐
│ Sparse Autoencoders (SAEs)                                  │
│ Manage and share SAEs for feature steering                  │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│ ┌──────────────────────────────────────────────────────┐   │
│ │  [📥 Download] [📤 Upload]  ← Toggle Tabs            │   │
│ └──────────────────────────────────────────────────────┘   │
│                                                             │
│ ═══════════════ SHARED FIELDS ═══════════════              │
│                                                             │
│ HuggingFace Repository *                                    │
│ ┌───────────────────────────────────────────────────────┐   │
│ │ google/gemma-scope-2b-pt-res                          │   │
│ └───────────────────────────────────────────────────────┘   │
│ ℹ️ Download: Enter existing repo • Upload: Your repo name   │
│                                                             │
│ Access Token (optional for download, required for upload)  │
│ ┌───────────────────────────────────────────────────────┐   │
│ │ hf_••••••••••••••••••••••••                          │ 👁️ │
│ └───────────────────────────────────────────────────────┘   │
│ ✓ Authenticated as your-username                            │
│                                                             │
│ Link to Model *                                             │
│ ┌───────────────────────────────────────────────────────┐   │
│ │ Select a model...                                     ▼│   │
│ └───────────────────────────────────────────────────────┘   │
│                                                             │
│ ─────────── DOWNLOAD MODE ONLY ───────────                 │
│ Custom Name (optional)                                      │
│ ┌───────────────────────────────────────────────────────┐   │
│ │ Auto-generated from file path                         │   │
│ └───────────────────────────────────────────────────────┘   │
│                                                             │
│ [🔍 Preview Repository]                                     │
│                                                             │
│ ─────────── UPLOAD MODE ONLY ─────────────                 │
│ Repository Visibility                                       │
│ (•) Private    ( ) Public                                   │
│                                                             │
│ Select SAEs to Upload *                                     │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ ☑ Layer 8 - res_post (16K features) - 288 MB          │ │
│ │   Trained on gpt2-small                                │ │
│ │                                                        │ │
│ │ ☑ Layer 8 - mlp_out (16K features) - 288 MB           │ │
│ │   Trained on gpt2-small                                │ │
│ │                                                        │ │
│ │ ☐ Layer 12 - attn_out (32K features) - 576 MB         │ │
│ │   Trained on gpt2-small                                │ │
│ └─────────────────────────────────────────────────────────┘ │
│ Selected: 2 SAEs (576 MB)                                   │
│                                                             │
│ Description (optional)                                      │
│ ┌───────────────────────────────────────────────────────┐   │
│ │ SAEs trained on GPT-2 Small residual stream and MLP  │   │
│ │ outputs using the standard SAELens training pipeline.│   │
│ └───────────────────────────────────────────────────────┘   │
│                                                             │
│ [📋 Preview README]                                         │
│                                                             │
│ ──────────────────────────────────────────                 │
│                                                             │
│ [📥 Download SAE] or [📤 Upload SAEs]  ← Dynamic           │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Your SAEs (6)
┌─────────────────────────────────────────────────────────────┐
│ gemma-scope-2b-pt-res/layer_20/sae.safetensors              │
│ 3 features • 1 GB                 🏷️ HuggingFace           │
│ wei1lk23d/gemma-scope-2b-pt-res                             │
│ 📤 Uploaded to your-username/gpt2-small-saes                │
│    [🔗 View on HuggingFace]                                 │
│                   [▶️ Use in Steering] [🗑️]  [✓ Ready]     │
└─────────────────────────────────────────────────────────────┘
```

**Key Design Principles**:
1. **Tab Toggle**: Clean switch between modes at the top
2. **Shared Fields**: Repository, Token, Model appear in both modes
3. **Progressive Disclosure**: Mode-specific fields show/hide automatically
4. **Dynamic Help Text**: Same field, context-aware hints based on mode
5. **State Preservation**: Switching modes keeps shared field values
6. **Code Reuse**: ~70% of form logic shared between modes

### 5.2 Upload Progress Modal

```
┌─────────────────────────────────────────────────────────────┐
│ Uploading to HuggingFace                          [Cancel] │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│ Repository: your-username/gpt2-small-saes                   │
│                                                             │
│ Overall Progress: 1 of 2 SAEs uploaded                      │
│ [████████████████████████░░░░░░░░░] 75%                     │
│                                                             │
│ Current: Uploading layer_8/mlp_out/width_16k                │
│ [████████████████░░░░░░░░░░░░░░░░░] 60% (172 MB / 288 MB)  │
│                                                             │
│ Completed:                                                  │
│ ✓ layer_8/res_post/width_16k                                │
│                                                             │
│ Remaining:                                                  │
│ • layer_8/mlp_out/width_16k (uploading...)                  │
│                                                             │
│ Estimated time remaining: 45 seconds                        │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### 5.3 Success State

```
┌─────────────────────────────────────────────────────────────┐
│ ✓ Upload Successful                                   [✕]  │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│ Successfully uploaded 2 SAEs to:                            │
│ your-username/gpt2-small-saes                               │
│                                                             │
│ Uploaded SAEs:                                              │
│ ✓ layer_8/res_post/width_16k                                │
│ ✓ layer_8/mlp_out/width_16k                                 │
│                                                             │
│ [🔗 View on HuggingFace]  [📋 Copy Repository URL]          │
│                                                             │
│ Your SAEs are now available for the community to use!       │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### 5.4 Updated SAE Card (Post-Upload)

```
┌─────────────────────────────────────────────────────────────┐
│ gemma-scope-2b-pt-res/layer_20/width_16k   🏷️ HuggingFace  │
│ 16K Features • Layer 20 • 288 MB                            │
│ google/gemma-scope-2b-pt-res                                │
│                                                             │
│ 📤 Uploaded to your-username/gpt2-small-saes                │
│    [🔗 View on HuggingFace]                                 │
│                                                             │
│                    [▶️ Use in Steering]  [🗑️]  [✓ Ready]   │
└─────────────────────────────────────────────────────────────┘
```

---

## 6. Technical Architecture

### 6.1 Backend Components

**New API Endpoints**:
```python
POST   /api/sae/upload/validate         # Validate upload configuration
POST   /api/sae/upload/prepare          # Organize and prepare upload
POST   /api/sae/upload/execute          # Execute upload to HuggingFace
GET    /api/sae/upload/status/{job_id}  # Get upload progress
DELETE /api/sae/upload/cancel/{job_id}  # Cancel upload
GET    /api/sae/{sae_id}/metadata       # Get SAE metadata for params.json
POST   /api/sae/upload/preview-readme   # Generate and preview README
```

**New Services**:
```python
class SAEUploadService:
    def organize_sae_for_upload(sae_id: str) -> UploadPackage
    def generate_params_json(sae: SAE) -> dict
    def generate_readme(saes: List[SAE], metadata: dict) -> str
    def validate_hf_token(token: str) -> TokenPermissions
    def upload_to_huggingface(package: UploadPackage, config: UploadConfig) -> UploadResult

class HuggingFaceClient:
    def create_repo(repo_id: str, private: bool, token: str)
    def upload_file(repo_id: str, file_path: str, repo_path: str, token: str)
    def upload_folder(repo_id: str, folder_path: str, token: str)
    def check_repo_exists(repo_id: str, token: str) -> bool
    def validate_token(token: str) -> TokenInfo
```

### 6.2 Data Models

```python
@dataclass
class UploadConfig:
    repo_name: str
    token: str
    sae_ids: List[str]
    visibility: str  # "public" or "private"
    description: Optional[str]
    commit_message: str

@dataclass
class UploadPackage:
    sae_id: str
    layer: int
    hook_type: str
    width: int
    params: dict
    weights_path: str
    target_path: str  # e.g., "layer_8/res_post/width_16k"

@dataclass
class UploadJob:
    job_id: str
    config: UploadConfig
    status: str  # "preparing", "uploading", "complete", "failed"
    progress: float
    current_sae: Optional[str]
    completed_saes: List[str]
    failed_saes: List[Tuple[str, str]]  # [(sae_id, error)]
    created_at: datetime
    updated_at: datetime

@dataclass
class SAEMetadata:
    # Extracted from SAE for params.json
    d_model: int
    d_sae: int
    hook_point: str
    hook_layer: int
    activation_fn: str
    normalize_activations: bool
    model_name: str
    context_size: int
    training_steps: int
    l1_coefficient: float
    # Additional optional fields
    learning_rate: Optional[float]
    batch_size: Optional[int]
    dead_feature_threshold: Optional[float]
```

### 6.3 Frontend Components

**New React Components**:
```typescript
// Main upload section
<SAEUploadSection />
  ├── <UploadForm />
  │   ├── <RepositoryNameInput />
  │   ├── <AccessTokenInput />
  │   ├── <VisibilityToggle />
  │   ├── <SAESelector />
  │   ├── <DescriptionInput />
  │   └── <UploadButton />
  ├── <READMEPreviewModal />
  └── <UploadProgressModal />

// Updates to existing components
<SAECard />  // Add upload status badge and HF link

// New hooks
useUploadJob(jobId)
useHFTokenValidation(token)
useSAESelection(filter)
```

### 6.4 State Management

```typescript
// Upload state slice
interface UploadState {
  currentJob: UploadJob | null;
  recentUploads: UploadJob[];
  isUploading: boolean;
  validationErrors: Record<string, string>;
  selectedSAEs: string[];
  uploadConfig: Partial<UploadConfig>;
}

// Actions
uploadActions = {
  validateConfig,
  startUpload,
  cancelUpload,
  updateProgress,
  completeUpload,
  setValidationError,
  selectSAE,
  deselectSAE,
  setConfig,
}
```

---

## 7. Implementation Phases

### Phase 1: Core Upload (Week 1-2)
**Goal**: Basic single SAE upload functionality

**Tasks**:
- [ ] Backend: HuggingFaceClient with token validation
- [ ] Backend: SAE organization logic (directory structure)
- [ ] Backend: params.json generation
- [ ] Backend: Basic upload endpoint
- [ ] Frontend: Upload form UI
- [ ] Frontend: SAE selection component
- [ ] Frontend: Basic upload flow
- [ ] Testing: Upload one SAE successfully

**Success Criteria**:
- Can upload a single SAE to HuggingFace
- Correct directory structure
- Valid params.json generated

### Phase 2: Multi-SAE & Progress (Week 3)
**Goal**: Batch upload with progress tracking

**Tasks**:
- [ ] Backend: Batch upload orchestration
- [ ] Backend: Progress tracking via WebSocket
- [ ] Backend: Job management system
- [ ] Frontend: Progress modal
- [ ] Frontend: Multi-SAE selection
- [ ] Frontend: Cancel functionality
- [ ] Testing: Upload multiple SAEs

**Success Criteria**:
- Can upload 3+ SAEs in one operation
- Progress accurately tracked
- Can cancel mid-upload

### Phase 3: README & Metadata (Week 4)
**Goal**: Professional repository presentation

**Tasks**:
- [ ] Backend: README generation logic
- [ ] Backend: Metadata extraction from SAE training logs
- [ ] Frontend: README preview modal
- [ ] Frontend: Description/commit message inputs
- [ ] Testing: Generated READMEs are comprehensive

**Success Criteria**:
- Auto-generated README includes all sections
- README preview works
- Uploaded repos look professional

### Phase 4: Error Handling & Polish (Week 5)
**Goal**: Production-ready reliability

**Tasks**:
- [ ] Backend: Comprehensive error handling
- [ ] Backend: Retry logic for failures
- [ ] Backend: Validation improvements
- [ ] Frontend: Error message display
- [ ] Frontend: Validation feedback
- [ ] Frontend: Success state UI
- [ ] Testing: Handle all error scenarios

**Success Criteria**:
- All common errors handled gracefully
- Clear actionable error messages
- >95% upload success rate

### Phase 5: Integration & UX (Week 6)
**Goal**: Seamless user experience

**Tasks**:
- [ ] Update SAE cards with upload status
- [ ] Add HuggingFace links to uploaded SAEs
- [ ] Implement token persistence (encrypted)
- [ ] Add upload history/log
- [ ] Mobile responsive design
- [ ] Tutorial/documentation
- [ ] Analytics integration

**Success Criteria**:
- Upload fits naturally in existing workflow
- Users can track upload history
- Mobile experience is good

---

## 8. API Specifications

### 8.1 Upload Validation

```
POST /api/sae/upload/validate

Request:
{
  "repo_name": "username/repo-name",
  "token": "hf_xxx",
  "sae_ids": ["sae_123", "sae_456"],
  "visibility": "private"
}

Response:
{
  "valid": true,
  "warnings": [
    "Repository already exists - will update"
  ],
  "token_permissions": {
    "can_write": true,
    "can_create_repo": true,
    "username": "your-username"
  },
  "estimated_size": "576 MB",
  "estimated_time": 120  // seconds
}

Error Response:
{
  "valid": false,
  "errors": {
    "token": "Invalid or expired token",
    "repo_name": "Invalid repository name format",
    "sae_ids": "SAE sae_789 not found"
  }
}
```

### 8.2 Execute Upload

```
POST /api/sae/upload/execute

Request:
{
  "repo_name": "username/model-saes",
  "token": "hf_xxx",
  "sae_ids": ["sae_123", "sae_456"],
  "visibility": "private",
  "description": "SAEs trained on...",
  "commit_message": "Upload SAE weights"
}

Response:
{
  "job_id": "upload_job_abc123",
  "status": "preparing",
  "created_at": "2025-01-15T10:30:00Z"
}
```

### 8.3 Upload Status

```
GET /api/sae/upload/status/upload_job_abc123

Response:
{
  "job_id": "upload_job_abc123",
  "status": "uploading",
  "progress": 0.45,
  "current_sae": "layer_8/mlp_out/width_16k",
  "current_progress": 0.60,
  "completed_saes": [
    "layer_8/res_post/width_16k"
  ],
  "failed_saes": [],
  "total_saes": 2,
  "estimated_time_remaining": 45,
  "repo_url": "https://huggingface.co/username/model-saes"
}

Complete Response:
{
  "job_id": "upload_job_abc123",
  "status": "complete",
  "progress": 1.0,
  "completed_saes": [
    "layer_8/res_post/width_16k",
    "layer_8/mlp_out/width_16k"
  ],
  "failed_saes": [],
  "repo_url": "https://huggingface.co/username/model-saes",
  "completed_at": "2025-01-15T10:32:30Z"
}
```

---

## 9. Testing Strategy

### 9.1 Unit Tests
- Token validation logic
- Directory structure generation
- params.json generation
- README generation
- Error handling

### 9.2 Integration Tests
- Complete upload flow (mock HF API)
- Multi-SAE batch upload
- Progress tracking
- Cancellation
- Error recovery

### 9.3 E2E Tests
- Upload to test HF repository
- Verify uploaded structure
- Download uploaded SAE back
- Verify integrity

### 9.4 Manual Testing
- Upload various SAE types
- Test with different models
- Test error scenarios
- Test on different networks
- Mobile testing

---

## 10. Security & Privacy

### 10.1 Token Security
- Store tokens encrypted at rest (AES-256)
- Never log tokens in plain text
- Clear tokens from memory after use
- Support token expiration checking
- Warn users about token permissions

### 10.2 Data Privacy
- Don't upload user prompts/activations
- Only upload SAE weights and metadata
- Allow users to review before upload
- Support private repositories
- Clear data retention policy

### 10.3 Rate Limiting
- Respect HuggingFace rate limits
- Implement backoff strategy
- Queue uploads if needed
- Warn users of quota limits

---

## 11. Monitoring & Analytics

### 11.1 Metrics to Track
- Upload success rate
- Upload completion time
- Error types and frequency
- SAE size distribution
- Most common models
- Public vs private ratio

### 11.2 Logging
- Upload start/completion events
- Errors with context (no tokens)
- User actions (anonymous)
- Performance metrics

---

## 12. Documentation

### 12.1 User Documentation
- How to get HuggingFace token
- How to select SAEs for upload
- Understanding repository structure
- Troubleshooting guide
- Best practices

### 12.2 Developer Documentation
- API documentation
- Architecture overview
- Testing guide
- Deployment guide

---

## 13. Success Criteria

### 13.1 Launch Criteria
- ✅ All Phase 1-4 tasks complete
- ✅ >95% upload success rate in testing
- ✅ <2 minute average upload time
- ✅ Zero critical bugs
- ✅ Documentation complete
- ✅ User testing positive feedback

### 13.2 Post-Launch Metrics (30 days)
- >50 successful uploads
- >80% user satisfaction
- <5% error rate
- >20% of trained SAEs uploaded

---

## 14. Future Enhancements

### 14.1 V2 Features
- Auto-upload on training completion (opt-in)
- Scheduled uploads
- Version management (update existing SAEs)
- Bulk operations (upload all SAEs for a model)
- Upload templates (pre-configured settings)

### 14.2 Advanced Features
- Team collaboration (shared repositories)
- Upload to multiple destinations
- Automated testing of uploaded SAEs
- Integration with Neuronpedia
- Upload statistics dashboard

---

## 15. Risks & Mitigations

### Risk 1: HuggingFace API Changes
**Impact**: High  
**Mitigation**: 
- Use official HF Python library
- Monitor HF changelog
- Version pin dependencies
- Graceful degradation

### Risk 2: Large File Upload Failures
**Impact**: Medium  
**Mitigation**:
- Implement chunked uploads
- Resume capability
- Retry logic
- Progress persistence

### Risk 3: User Token Compromise
**Impact**: High  
**Mitigation**:
- Encrypted storage
- Security best practices doc
- Token scope validation
- Clear security warnings

### Risk 4: Repository Conflicts
**Impact**: Medium  
**Mitigation**:
- Check before upload
- Smart merge strategies
- Clear conflict resolution UI
- Backup before overwrite

---

## 16. Open Questions

1. **Token Storage**: Should we store HF tokens permanently or require re-entry each session?
   - **Recommendation**: Store encrypted with user opt-in

2. **Batch Size**: What's the maximum number of SAEs to upload at once?
   - **Recommendation**: Start with 10, increase based on testing

3. **Overwrite Strategy**: How to handle uploading to existing repos with files?
   - **Recommendation**: Warn and allow merge or cancel

4. **Validation Strictness**: Should we block uploads with incomplete metadata?
   - **Recommendation**: Warn but allow with defaults

5. **Mobile Experience**: Should upload be available on mobile?
   - **Recommendation**: Yes, but with warnings about large uploads

---

## Appendix A: File Structure Example

### Generated Repository Structure
```
username/gpt2-small-saes/
├── README.md
├── .gitattributes
├── config.json (optional)
└── layer_0/
    ├── res_post/
    │   └── width_16k/
    │       ├── params.json
    │       └── sae_weights.safetensors
    ├── mlp_out/
    │   └── width_16k/
    │       ├── params.json
    │       └── sae_weights.safetensors
    └── attn_out/
        └── width_16k/
            ├── params.json
            └── sae_weights.safetensors
```

### Example params.json
```json
{
  "d_model": 768,
  "d_sae": 16384,
  "hook_point": "blocks.8.hook_resid_post",
  "hook_layer": 8,
  "hook_type": "res_post",
  "activation_fn": "relu",
  "normalize_activations": true,
  "model_name": "gpt2-small",
  "model_from_pretrained_path": "gpt2-small",
  "context_size": 1024,
  "prepend_bos": true,
  "training_tokens": 100000000,
  "l1_coefficient": 0.0008,
  "learning_rate": 0.0004,
  "lr_scheduler_name": "constant",
  "train_batch_size_tokens": 4096,
  "dead_feature_threshold": 1e-08,
  "dead_feature_window": 1000,
  "feature_sampling_window": 2000,
  "created_at": "2025-01-15T10:30:00Z",
  "trained_with": "MechInterp Studio v1.0",
  "saelens_version": "3.0.0"
}
```

### Example README.md (Generated)
```markdown
---
tags:
- sparse-autoencoder
- interpretability
- gpt2-small
- saelens
license: mit
---

# Sparse Autoencoders for GPT-2 Small

This repository contains Sparse Autoencoders (SAEs) trained on multiple layers and components of GPT-2 Small using MechInterp Studio.

## 📊 Coverage

- **Model**: GPT-2 Small (124M parameters)
- **Layers**: 3 layers (0, 8, 12)
- **Components**: Residual stream (post), MLP output, Attention output
- **Total SAEs**: 9
- **Feature Width**: 16,384 features per SAE

## 📂 Structure

```
gpt2-small-saes/
├── layer_0/
│   ├── res_post/width_16k/
│   ├── mlp_out/width_16k/
│   └── attn_out/width_16k/
├── layer_8/
│   └── ...
└── layer_12/
    └── ...
```

## 🚀 Usage

### With SAELens

```python
from sae_lens import SAE

# Load a specific SAE
sae = SAE.from_pretrained(
    release="username/gpt2-small-saes",
    sae_id="layer_8/res_post/width_16k"
)

# Use for analysis
features = sae.encode(activations)
reconstructed = sae.decode(features)
```

### With TransformerLens

```python
from transformer_lens import HookedTransformer
from huggingface_hub import hf_hub_download
from safetensors.torch import load_file

# Load model
model = HookedTransformer.from_pretrained("gpt2-small")

# Download SAE weights
weights_path = hf_hub_download(
    repo_id="username/gpt2-small-saes",
    filename="layer_8/res_post/width_16k/sae_weights.safetensors"
)

# Load weights
sae_weights = load_file(weights_path)
```

## 🔬 Training Details

- **Training Tokens**: 100M tokens per SAE
- **Context Size**: 1024 tokens
- **L1 Coefficient**: 0.0008
- **Learning Rate**: 0.0004
- **Batch Size**: 4096 tokens
- **Framework**: SAELens 3.0.0
- **Trained with**: MechInterp Studio

## 📈 Quality Metrics

| Layer | Component | L0 Sparsity | Reconstruction Loss | Dead Features |
|-------|-----------|-------------|---------------------|---------------|
| 0     | res_post  | 42.3        | 0.012              | 3.2%          |
| 8     | res_post  | 38.7        | 0.015              | 2.1%          |
| 12    | res_post  | 45.1        | 0.011              | 4.5%          |

## 🎯 Use Cases

These SAEs can be used for:
- Feature steering and behavior modification
- Interpretability research
- Debugging model behaviors
- Analyzing learned representations

## 📚 Citation

If you use these SAEs in your research, please cite:

```bibtex
@misc{gpt2_small_saes,
  author = {Your Name},
  title = {Sparse Autoencoders for GPT-2 Small},
  year = {2025},
  publisher = {HuggingFace},
  url = {https://huggingface.co/username/gpt2-small-saes}
}
```

## 📄 License

MIT License - See LICENSE file for details

## 🤝 Contributing

Found an issue? Have suggestions? Open an issue or reach out!

---

*Generated with MechInterp Studio - [https://mistudio.mcslab.io](https://mistudio.mcslab.io)*
```

---

**Document Version**: 1.0  
**Created**: 2025-01-15  
**Status**: Ready for Implementation  
**Estimated Effort**: 6 weeks  
**Priority**: High
