# SAE Upload Implementation Tasks for Claude Code

# SAE Upload Implementation Tasks for Claude Code

## ⚠️ IMPORTANT: Unified Interface Approach

**This implementation uses a UNIFIED interface with toggle between Download/Upload modes.**

### Key Changes from Original Design:
1. **Single Form Component** - NOT separate upload and download sections
2. **Tab Toggle** - User switches between "📥 Download" and "📤 Upload" tabs
3. **Shared Fields** - Repository, Token, and Model selector used by BOTH modes
4. **~70% Code Reuse** - Validation, token handling, and UI components shared
5. **Progressive Disclosure** - Fields show/hide based on active mode

### Why This Approach:
- User already has download interface - we're enhancing it, not duplicating
- Trained SAEs from MiStudio appear in same list as downloaded SAEs
- Token validation and repository input work identically for both
- Cleaner UX - one interface instead of two separate sections
- Less code to maintain - shared components and logic

### What This Means for Implementation:
- **Phase 1**: Build shared backend services (HF client, validation)
- **Phase 2**: Create unified form with toggle (reuse existing download components)
- **Phase 3**: Add upload-specific features (SAE selector, progress modal)
- **Phase 4**: Integration and polish

**Reference Documents**:
- Full PRD: `/mnt/user-data/outputs/SAE_Upload_Feature_PRD.md`
- Unified Interface Design: `/mnt/user-data/outputs/Unified_SAE_Interface_Implementation.md`

---

## Project Context
- **Application**: MechInterp Studio - Edge AI Feature Discovery Platform
- **Feature**: Add SAE upload capability with unified toggle interface (Download/Upload modes)
- **Tech Stack**: React (Frontend), FastAPI (Backend), Python, TypeScript
- **Existing Page**: `/SAEs` - Already has download functionality from HuggingFace
- **Design Approach**: Unified form component with tab toggle, ~70% code reuse between modes

## Architecture Overview

```
Backend (FastAPI)
├── /api/sae/common/          - NEW: Shared endpoints
│   ├── validate-token        - Token validation (both modes)
│   └── check-repository      - Repo info (both modes)
├── /api/sae/upload/
│   ├── validate              - Validate upload config
│   ├── prepare               - Organize SAE data
│   ├── execute               - Upload to HuggingFace
│   ├── status/{id}           - Get progress
│   └── cancel/{id}           - Cancel upload
├── services/
│   ├── sae_upload_service.py     - Upload orchestration
│   ├── hf_client.py              - HuggingFace API (shared)
│   └── readme_generator.py       - README generation
└── models/
    └── upload_models.py          - Data models

Frontend (React)
├── components/
│   ├── SAEManagementForm.tsx     - NEW: Unified form with toggle
│   ├── SAESelector.tsx           - Multi-select SAEs
│   ├── UploadProgressModal.tsx   - Progress display
│   └── ModelSelector.tsx         - REUSED from download
├── hooks/
│   ├── useSAEValidation.ts       - NEW: Unified validation
│   ├── useHFToken.ts             - NEW: Shared token handling
│   ├── useSecureToken.ts         - NEW: Token storage
│   └── useUploadJob.ts           - Upload job state
└── api/
    └── saeApi.ts                 - UPDATED: Unified API calls
```

**Key Design Principle**: Maximize code reuse by sharing:
- Repository input field
- Token validation logic
- Model selector
- Error/warning display
- Form field components

---

## Phase 1: Shared Infrastructure & Backend (Week 1)

**Goal**: Create shared services and backend infrastructure used by both modes

### Task 1.0: Create Shared API Endpoints
**File**: `backend/api/routes/sae_common.py`

```python
"""
Common endpoints shared between upload and download operations.
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional

from ...services.hf_client import HuggingFaceClient

router = APIRouter(prefix="/api/sae/common", tags=["sae_common"])
hf_client = HuggingFaceClient()

class TokenValidationRequest(BaseModel):
    token: str

class TokenValidationResponse(BaseModel):
    username: str
    can_write: bool
    can_create_repo: bool
    valid: bool
    error: Optional[str] = None

@router.post("/validate-token")
async def validate_token(request: TokenValidationRequest) -> TokenValidationResponse:
    """
    Validate HuggingFace token and return permissions.
    Used by both upload and download flows.
    """
    try:
        token_info = hf_client.validate_token(request.token)
        return TokenValidationResponse(
            username=token_info.username,
            can_write=token_info.can_write,
            can_create_repo=token_info.can_create_repo,
            valid=token_info.valid
        )
    except Exception as e:
        return TokenValidationResponse(
            username="",
            can_write=False,
            can_create_repo=False,
            valid=False,
            error=str(e)
        )

class RepositoryCheckRequest(BaseModel):
    repo_name: str
    token: Optional[str] = None

class RepositoryInfo(BaseModel):
    exists: bool
    is_public: bool
    num_files: Optional[int] = None
    size_mb: Optional[float] = None
    last_updated: Optional[str] = None

@router.post("/check-repository")
async def check_repository(request: RepositoryCheckRequest) -> RepositoryInfo:
    """
    Check if repository exists and get basic info.
    Used to show warnings/info in both modes.
    """
    try:
        info = hf_client.get_repository_info(
            request.repo_name,
            request.token
        )
        return info
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))
```

**Acceptance Criteria**:
- [ ] Token validation works for all token types
- [ ] Returns correct permission levels
- [ ] Repository check works for public/private repos
- [ ] Error handling is comprehensive

---
### Task 1.1: Update HuggingFace Client Service
**File**: `backend/services/hf_client.py`

```python
"""
HuggingFace API client for SAE uploads.

Dependencies:
- huggingface_hub
- requests

Key methods:
- validate_token(token: str) -> TokenInfo
- create_repo(repo_id: str, private: bool, token: str) -> bool
- check_repo_exists(repo_id: str, token: str) -> bool
- upload_file(repo_id, file_path, repo_path, token, progress_callback)
- upload_folder(repo_id, folder_path, token, progress_callback)
"""

from huggingface_hub import HfApi, HfFolder, Repository
from typing import Optional, Callable
from dataclasses import dataclass
import requests

@dataclass
class TokenInfo:
    username: str
    can_write: bool
    can_create_repo: bool
    valid: bool
    error: Optional[str] = None

class HuggingFaceClient:
    def __init__(self):
        self.api = HfApi()
    
    def validate_token(self, token: str) -> TokenInfo:
        """Validate HF token and check permissions."""
        # Implementation details:
        # 1. Try to get user info with token
        # 2. Check if token has write permissions
        # 3. Return TokenInfo with results
        pass
    
    def create_repo(self, repo_id: str, private: bool, token: str) -> bool:
        """Create repository if it doesn't exist."""
        # Implementation details:
        # 1. Check if repo exists
        # 2. Create if not (with exist_ok=True)
        # 3. Return success status
        pass
    
    def upload_file(
        self,
        repo_id: str,
        file_path: str,
        repo_path: str,
        token: str,
        progress_callback: Optional[Callable[[int, int], None]] = None
    ) -> bool:
        """Upload single file with progress tracking."""
        # Implementation details:
        # 1. Use HfApi.upload_file with commit_message
        # 2. Track progress and call callback
        # 3. Handle errors gracefully
        pass
    
    def upload_folder(
        self,
        repo_id: str,
        folder_path: str,
        token: str,
        progress_callback: Optional[Callable[[str, float], None]] = None
    ) -> bool:
        """Upload entire folder structure."""
        # Implementation details:
        # 1. Use HfApi.upload_folder
        # 2. Track overall progress
        # 3. Return success status
        pass
```

**Acceptance Criteria**:
- [ ] Token validation returns correct permissions
- [ ] Repo creation works for new and existing repos
- [ ] File upload tracks progress correctly
- [ ] Handles network errors gracefully

---

### Task 1.2: Create Data Models
**File**: `backend/models/upload_models.py`

```python
"""
Data models for SAE upload functionality.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Tuple
from datetime import datetime
from enum import Enum

class UploadStatus(str, Enum):
    VALIDATING = "validating"
    PREPARING = "preparing"
    UPLOADING = "uploading"
    COMPLETE = "complete"
    FAILED = "failed"
    CANCELLED = "cancelled"

@dataclass
class UploadConfig:
    """Configuration for SAE upload."""
    repo_name: str
    token: str
    sae_ids: List[str]
    visibility: str = "private"  # "public" or "private"
    description: Optional[str] = None
    commit_message: str = "Upload SAE weights from MechInterp Studio"

@dataclass
class SAEUploadPackage:
    """Organized SAE data ready for upload."""
    sae_id: str
    layer: int
    hook_type: str  # res_post, mlp_out, attn_out
    width: int      # d_sae
    params: dict    # params.json content
    weights_path: str  # path to .safetensors file
    target_path: str   # e.g., "layer_8/res_post/width_16k"

@dataclass
class UploadJob:
    """Upload job tracking."""
    job_id: str
    config: UploadConfig
    status: UploadStatus
    progress: float = 0.0
    current_sae: Optional[str] = None
    current_sae_progress: float = 0.0
    completed_saes: List[str] = field(default_factory=list)
    failed_saes: List[Tuple[str, str]] = field(default_factory=list)  # (sae_id, error)
    repo_url: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    estimated_time_remaining: Optional[int] = None  # seconds
    
    def to_dict(self) -> dict:
        """Convert to dict for API response."""
        return {
            "job_id": self.job_id,
            "status": self.status.value,
            "progress": self.progress,
            "current_sae": self.current_sae,
            "current_sae_progress": self.current_sae_progress,
            "completed_saes": self.completed_saes,
            "failed_saes": self.failed_saes,
            "repo_url": self.repo_url,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "estimated_time_remaining": self.estimated_time_remaining
        }

@dataclass
class ValidationResult:
    """Result of upload validation."""
    valid: bool
    errors: dict = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)
    token_permissions: Optional[dict] = None
    estimated_size_mb: Optional[float] = None
    estimated_time_seconds: Optional[int] = None
```

**Acceptance Criteria**:
- [ ] All models properly typed
- [ ] JSON serialization works
- [ ] Enums for status values
- [ ] Proper datetime handling

---

### Task 1.3: Create SAE Metadata Extractor
**File**: `backend/services/sae_metadata_extractor.py`

```python
"""
Extract metadata from SAE for params.json generation.
"""

from typing import Dict, Any, Optional
import torch
from safetensors.torch import load_file
import json
import os

class SAEMetadataExtractor:
    """Extract and format SAE metadata for HuggingFace upload."""
    
    def extract_from_sae(self, sae_path: str, sae_config: dict) -> dict:
        """
        Extract metadata from SAE file and configuration.
        
        Args:
            sae_path: Path to SAE .safetensors file
            sae_config: SAE configuration dict
            
        Returns:
            params.json content
        """
        # Implementation details:
        # 1. Load SAE weights to get dimensions
        # 2. Extract training config from sae_config
        # 3. Parse hook_point to get layer and type
        # 4. Format according to Gemma-Scope standard
        
        params = {
            # Model architecture
            "d_model": None,  # from weights or config
            "d_sae": None,    # from weights
            
            # Hook information
            "hook_point": None,  # e.g., "blocks.8.hook_resid_post"
            "hook_layer": None,  # extracted from hook_point
            "hook_type": None,   # res_post, mlp_out, etc.
            
            # Training configuration
            "activation_fn": "relu",
            "normalize_activations": True,
            "model_name": None,
            "model_from_pretrained_path": None,
            "context_size": 1024,
            "prepend_bos": True,
            
            # Training details
            "training_tokens": None,
            "l1_coefficient": None,
            "learning_rate": None,
            "lr_scheduler_name": "constant",
            "train_batch_size_tokens": 4096,
            
            # Feature statistics
            "dead_feature_threshold": 1e-08,
            "dead_feature_window": 1000,
            "feature_sampling_window": 2000,
            
            # Metadata
            "created_at": None,  # ISO format
            "trained_with": "MechInterp Studio",
            "saelens_version": None
        }
        
        return self._populate_params(params, sae_path, sae_config)
    
    def _populate_params(self, params: dict, sae_path: str, config: dict) -> dict:
        """Populate params dict from SAE and config."""
        pass
    
    def _parse_hook_point(self, hook_point: str) -> tuple:
        """
        Parse hook_point string to extract layer and type.
        
        Examples:
            "blocks.8.hook_resid_post" -> (8, "res_post")
            "blocks.12.mlp.hook_post" -> (12, "mlp_out")
            "blocks.5.attn.hook_result" -> (5, "attn_out")
        """
        pass
    
    def _get_dimensions_from_weights(self, weights_path: str) -> tuple:
        """Extract d_model and d_sae from weights file."""
        pass
```

**Acceptance Criteria**:
- [ ] Correctly parses all hook_point formats
- [ ] Extracts dimensions from weights
- [ ] Generates valid params.json
- [ ] Handles missing config gracefully

---

### Task 1.4: Create README Generator
**File**: `backend/services/readme_generator.py`

```python
"""
Generate comprehensive README for HuggingFace SAE repository.
"""

from typing import List, Dict, Any
from datetime import datetime

class READMEGenerator:
    """Generate professional README for SAE repository."""
    
    def generate(
        self,
        repo_id: str,
        model_name: str,
        sae_packages: List[Dict[str, Any]],
        description: str = "",
        training_details: Dict[str, Any] = None
    ) -> str:
        """
        Generate complete README content.
        
        Args:
            repo_id: HuggingFace repo identifier (username/repo-name)
            model_name: Base model name (e.g., "gpt2-small")
            sae_packages: List of SAE package dicts with metadata
            description: Optional user-provided description
            training_details: Optional training configuration details
            
        Returns:
            Complete README markdown string
        """
        sections = [
            self._generate_header(repo_id, model_name),
            self._generate_coverage(sae_packages),
            self._generate_structure(repo_id, sae_packages),
            self._generate_usage_examples(repo_id),
            self._generate_training_details(training_details),
            self._generate_quality_metrics(sae_packages),
            self._generate_use_cases(),
            self._generate_citation(repo_id),
            self._generate_footer()
        ]
        
        if description:
            sections.insert(1, f"\n{description}\n")
        
        return "\n\n".join(sections)
    
    def _generate_header(self, repo_id: str, model_name: str) -> str:
        """Generate frontmatter and title."""
        return f"""---
tags:
- sparse-autoencoder
- interpretability
- {model_name}
- saelens
license: mit
---

# Sparse Autoencoders for {model_name}

This repository contains Sparse Autoencoders (SAEs) trained on multiple layers and components of {model_name} using MechInterp Studio."""
    
    def _generate_coverage(self, sae_packages: List[Dict]) -> str:
        """Generate coverage section with statistics."""
        pass
    
    def _generate_structure(self, repo_id: str, packages: List[Dict]) -> str:
        """Generate directory structure visualization."""
        pass
    
    def _generate_usage_examples(self, repo_id: str) -> str:
        """Generate code examples for SAELens and TransformerLens."""
        pass
    
    def _generate_training_details(self, details: Dict) -> str:
        """Generate training configuration table."""
        pass
    
    def _generate_quality_metrics(self, packages: List[Dict]) -> str:
        """Generate quality metrics table if available."""
        pass
    
    def _generate_use_cases(self) -> str:
        """Generate common use cases section."""
        pass
    
    def _generate_citation(self, repo_id: str) -> str:
        """Generate BibTeX citation."""
        pass
    
    def _generate_footer(self) -> str:
        """Generate footer with attribution."""
        return "\n---\n\n*Generated with MechInterp Studio - [https://mistudio.mcslab.io](https://mistudio.mcslab.io)*"
```

**Acceptance Criteria**:
- [ ] README includes all required sections
- [ ] Valid markdown formatting
- [ ] Working code examples
- [ ] Professional appearance

---

### Task 1.5: Create Upload Service
**File**: `backend/services/sae_upload_service.py`

```python
"""
Main service orchestrating SAE uploads to HuggingFace.
"""

from typing import List, Optional, Callable
import tempfile
import os
import json
import uuid
from pathlib import Path
from safetensors.torch import load_file, save_file
import shutil

from .hf_client import HuggingFaceClient, TokenInfo
from .sae_metadata_extractor import SAEMetadataExtractor
from .readme_generator import READMEGenerator
from ..models.upload_models import (
    UploadConfig, UploadJob, SAEUploadPackage, 
    UploadStatus, ValidationResult
)

class SAEUploadService:
    """Orchestrate SAE uploads to HuggingFace."""
    
    def __init__(self):
        self.hf_client = HuggingFaceClient()
        self.metadata_extractor = SAEMetadataExtractor()
        self.readme_generator = READMEGenerator()
        self.active_jobs = {}  # job_id -> UploadJob
    
    async def validate_upload(self, config: UploadConfig) -> ValidationResult:
        """
        Validate upload configuration before execution.
        
        Checks:
        - Token validity and permissions
        - SAE existence and accessibility
        - Repository name format
        - Estimated size and time
        """
        result = ValidationResult(valid=True)
        
        # Validate token
        token_info = self.hf_client.validate_token(config.token)
        if not token_info.valid:
            result.valid = False
            result.errors["token"] = token_info.error
            return result
        
        result.token_permissions = {
            "username": token_info.username,
            "can_write": token_info.can_write,
            "can_create_repo": token_info.can_create_repo
        }
        
        # Validate repo name
        if not self._is_valid_repo_name(config.repo_name):
            result.valid = False
            result.errors["repo_name"] = "Invalid repository name format"
        
        # Validate SAEs exist
        missing_saes = []
        total_size = 0
        for sae_id in config.sae_ids:
            if not self._sae_exists(sae_id):
                missing_saes.append(sae_id)
            else:
                total_size += self._get_sae_size(sae_id)
        
        if missing_saes:
            result.valid = False
            result.errors["sae_ids"] = f"SAEs not found: {', '.join(missing_saes)}"
        
        # Check if repo exists
        if self.hf_client.check_repo_exists(config.repo_name, config.token):
            result.warnings.append(
                "Repository already exists - will add/update files"
            )
        
        # Estimates
        result.estimated_size_mb = total_size / (1024 * 1024)
        result.estimated_time_seconds = self._estimate_upload_time(total_size)
        
        return result
    
    async def prepare_upload(self, config: UploadConfig) -> UploadJob:
        """
        Prepare SAE packages for upload.
        
        Steps:
        1. Create job with unique ID
        2. Organize each SAE into upload package
        3. Generate metadata (params.json)
        4. Create temporary directory structure
        5. Generate README
        """
        job_id = str(uuid.uuid4())
        job = UploadJob(
            job_id=job_id,
            config=config,
            status=UploadStatus.PREPARING
        )
        self.active_jobs[job_id] = job
        
        # Create temp directory
        temp_dir = tempfile.mkdtemp(prefix=f"sae_upload_{job_id}_")
        packages = []
        
        for sae_id in config.sae_ids:
            package = self._prepare_sae_package(sae_id, temp_dir)
            packages.append(package)
        
        # Generate README
        readme_content = self.readme_generator.generate(
            repo_id=config.repo_name,
            model_name=self._get_model_name_from_saes(packages),
            sae_packages=[p.__dict__ for p in packages],
            description=config.description or ""
        )
        
        readme_path = os.path.join(temp_dir, "README.md")
        with open(readme_path, 'w') as f:
            f.write(readme_content)
        
        job.temp_dir = temp_dir
        job.packages = packages
        job.status = UploadStatus.UPLOADING
        
        return job
    
    async def execute_upload(
        self, 
        job_id: str,
        progress_callback: Optional[Callable] = None
    ) -> UploadJob:
        """
        Execute the upload to HuggingFace.
        
        Steps:
        1. Create repository if needed
        2. Upload folder structure
        3. Track progress
        4. Update job status
        """
        job = self.active_jobs.get(job_id)
        if not job:
            raise ValueError(f"Job {job_id} not found")
        
        try:
            # Create repo
            self.hf_client.create_repo(
                repo_id=job.config.repo_name,
                private=job.config.visibility == "private",
                token=job.config.token
            )
            
            # Upload folder
            def on_progress(file_path: str, progress: float):
                if progress_callback:
                    progress_callback(job_id, file_path, progress)
                job.progress = progress
                job.updated_at = datetime.now()
            
            success = self.hf_client.upload_folder(
                repo_id=job.config.repo_name,
                folder_path=job.temp_dir,
                token=job.config.token,
                progress_callback=on_progress
            )
            
            if success:
                job.status = UploadStatus.COMPLETE
                job.progress = 1.0
                job.repo_url = f"https://huggingface.co/{job.config.repo_name}"
            else:
                job.status = UploadStatus.FAILED
        
        except Exception as e:
            job.status = UploadStatus.FAILED
            job.failed_saes.append(("all", str(e)))
        
        finally:
            # Cleanup temp directory
            if hasattr(job, 'temp_dir'):
                shutil.rmtree(job.temp_dir, ignore_errors=True)
        
        return job
    
    def get_job_status(self, job_id: str) -> Optional[UploadJob]:
        """Get current status of upload job."""
        return self.active_jobs.get(job_id)
    
    def cancel_upload(self, job_id: str) -> bool:
        """Cancel an in-progress upload."""
        job = self.active_jobs.get(job_id)
        if job and job.status == UploadStatus.UPLOADING:
            job.status = UploadStatus.CANCELLED
            return True
        return False
    
    # Helper methods
    def _prepare_sae_package(self, sae_id: str, base_dir: str) -> SAEUploadPackage:
        """Prepare single SAE for upload."""
        pass
    
    def _is_valid_repo_name(self, repo_name: str) -> bool:
        """Validate HuggingFace repo name format."""
        pass
    
    def _sae_exists(self, sae_id: str) -> bool:
        """Check if SAE exists in database."""
        pass
    
    def _get_sae_size(self, sae_id: str) -> int:
        """Get SAE file size in bytes."""
        pass
    
    def _estimate_upload_time(self, size_bytes: int) -> int:
        """Estimate upload time based on size (assumes 10 Mbps)."""
        pass
    
    def _get_model_name_from_saes(self, packages: List[SAEUploadPackage]) -> str:
        """Extract model name from SAE packages."""
        pass
```

**Acceptance Criteria**:
- [ ] Validation catches all error cases
- [ ] Upload preparation creates correct structure
- [ ] Upload execution works end-to-end
- [ ] Progress tracking updates correctly
- [ ] Cleanup happens on success and failure

---

### Task 1.6: Create API Endpoints
**File**: `backend/api/routes/sae_upload.py`

```python
"""
FastAPI endpoints for SAE upload functionality.
"""

from fastapi import APIRouter, HTTPException, BackgroundTasks
from typing import Optional
from pydantic import BaseModel

from ...services.sae_upload_service import SAEUploadService
from ...models.upload_models import UploadConfig, UploadJob, ValidationResult

router = APIRouter(prefix="/api/sae/upload", tags=["sae_upload"])
upload_service = SAEUploadService()

# Request/Response models
class ValidateRequest(BaseModel):
    repo_name: str
    token: str
    sae_ids: list[str]
    visibility: str = "private"

class UploadRequest(BaseModel):
    repo_name: str
    token: str
    sae_ids: list[str]
    visibility: str = "private"
    description: Optional[str] = None
    commit_message: str = "Upload SAE weights from MechInterp Studio"

@router.post("/validate")
async def validate_upload(request: ValidateRequest) -> ValidationResult:
    """
    Validate upload configuration.
    
    Checks token permissions, SAE existence, and estimates.
    """
    config = UploadConfig(
        repo_name=request.repo_name,
        token=request.token,
        sae_ids=request.sae_ids,
        visibility=request.visibility
    )
    
    result = await upload_service.validate_upload(config)
    return result

@router.post("/execute")
async def execute_upload(
    request: UploadRequest,
    background_tasks: BackgroundTasks
) -> dict:
    """
    Start upload job.
    
    Returns job_id immediately, upload continues in background.
    """
    config = UploadConfig(
        repo_name=request.repo_name,
        token=request.token,
        sae_ids=request.sae_ids,
        visibility=request.visibility,
        description=request.description,
        commit_message=request.commit_message
    )
    
    # Validate first
    validation = await upload_service.validate_upload(config)
    if not validation.valid:
        raise HTTPException(status_code=400, detail=validation.errors)
    
    # Prepare upload
    job = await upload_service.prepare_upload(config)
    
    # Execute in background
    background_tasks.add_task(
        upload_service.execute_upload,
        job.job_id
    )
    
    return {
        "job_id": job.job_id,
        "status": job.status.value,
        "created_at": job.created_at.isoformat()
    }

@router.get("/status/{job_id}")
async def get_upload_status(job_id: str) -> dict:
    """Get current status of upload job."""
    job = upload_service.get_job_status(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    
    return job.to_dict()

@router.delete("/cancel/{job_id}")
async def cancel_upload(job_id: str) -> dict:
    """Cancel an in-progress upload."""
    success = upload_service.cancel_upload(job_id)
    if not success:
        raise HTTPException(
            status_code=400, 
            detail="Job not found or cannot be cancelled"
        )
    
    return {"status": "cancelled"}

@router.post("/preview-readme")
async def preview_readme(request: UploadRequest) -> dict:
    """Generate and return README preview."""
    # TODO: Implement README preview
    pass
```

**Acceptance Criteria**:
- [ ] All endpoints work with correct inputs
- [ ] Proper error handling and status codes
- [ ] Background task execution works
- [ ] Request/response models validated

---

## Phase 2: Unified Frontend Interface (Week 2)

**Goal**: Create unified toggle interface that reuses components between modes

### Task 2.1: Create Shared Validation Hook
**File**: `frontend/src/hooks/useSAEValidation.ts`

```typescript
/**
 * Unified validation logic for both download and upload modes.
 * Routes to appropriate API based on mode.
 */

import { useState } from 'react';
import { uploadApi } from '@/api/uploadApi';
import { downloadApi } from '@/api/downloadApi';

interface ValidationRequest {
  mode: 'download' | 'upload';
  repoName: string;
  token: string;
  selectedSAEIds?: string[];
  visibility?: 'public' | 'private';
}

interface ValidationResult {
  valid: boolean;
  errors?: Record<string, string>;
  warnings?: string[];
  token_permissions?: {
    username: string;
    can_write: boolean;
    can_create_repo: boolean;
  };
  estimated_size_mb?: number;
  estimated_time_seconds?: number;
}

export function useSAEValidation() {
  const [validationResult, setValidationResult] = useState<ValidationResult | null>(null);
  const [isValidating, setIsValidating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const validate = async (request: ValidationRequest) => {
    setIsValidating(true);
    setError(null);

    try {
      let result: ValidationResult;

      if (request.mode === 'download') {
        // Validate download - check if repo exists and is accessible
        result = await downloadApi.validateRepository({
          repo_name: request.repoName,
          token: request.token
        });
      } else {
        // Validate upload - check token permissions and SAEs
        result = await uploadApi.validate({
          repo_name: request.repoName,
          token: request.token,
          sae_ids: request.selectedSAEIds || [],
          visibility: request.visibility || 'private'
        });
      }

      setValidationResult(result);
      return result;
    } catch (err) {
      setError(err.message);
      setValidationResult({
        valid: false,
        errors: { general: err.message }
      });
      return null;
    } finally {
      setIsValidating(false);
    }
  };

  const reset = () => {
    setValidationResult(null);
    setError(null);
  };

  return {
    validationResult,
    isValidating,
    error,
    validate,
    reset
  };
}
```

**Acceptance Criteria**:
- [ ] Routes correctly based on mode
- [ ] Returns unified validation result
- [ ] Handles errors gracefully
- [ ] Can be used in both modes

---

### Task 2.2: Create Token Management Hook
**File**: `frontend/src/hooks/useHFToken.ts`

```typescript
/**
 * HuggingFace token validation and management.
 * Shared between upload (required) and download (optional).
 */

import { useState, useEffect } from 'react';
import { saeApi } from '@/api/saeApi';

interface TokenInfo {
  username: string;
  can_write: boolean;
  can_create_repo: boolean;
  valid: boolean;
}

export function useHFToken(token: string) {
  const [tokenInfo, setTokenInfo] = useState<TokenInfo | null>(null);
  const [isValidating, setIsValidating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!token || token.length < 10) {
      setTokenInfo(null);
      return;
    }

    const validateToken = async () => {
      setIsValidating(true);
      setError(null);

      try {
        const info = await saeApi.validateToken(token);
        setTokenInfo(info);
      } catch (err) {
        setError(err.message);
        setTokenInfo(null);
      } finally {
        setIsValidating(false);
      }
    };

    // Debounce validation
    const timeout = setTimeout(validateToken, 500);
    return () => clearTimeout(timeout);
  }, [token]);

  return {
    tokenInfo,
    isValidating,
    error,
    isValid: tokenInfo?.valid || false,
    hasWritePermission: tokenInfo?.can_write || false,
    username: tokenInfo?.username
  };
}
```

**Acceptance Criteria**:
- [ ] Auto-validates on token change
- [ ] Debounced properly
- [ ] Shows permission level
- [ ] Works for both modes

---

### Task 2.3: Create Secure Token Storage Hook
**File**: `frontend/src/hooks/useSecureToken.ts`

```typescript
/**
 * Secure token storage using encrypted localStorage.
 */

import { useState, useEffect } from 'react';

const TOKEN_KEY = 'hf_token_encrypted';

export function useSecureToken() {
  const [token, setTokenState] = useState<string>('');
  const [rememberToken, setRememberToken] = useState(false);

  // Load token on mount
  useEffect(() => {
    const stored = localStorage.getItem(TOKEN_KEY);
    if (stored) {
      // TODO: Decrypt in production
      setTokenState(stored);
      setRememberToken(true);
    }
  }, []);

  const setToken = (newToken: string, remember: boolean = false) => {
    setTokenState(newToken);
    setRememberToken(remember);
    
    if (remember && newToken) {
      // TODO: Encrypt in production
      localStorage.setItem(TOKEN_KEY, newToken);
    } else {
      localStorage.removeItem(TOKEN_KEY);
    }
  };

  const clearToken = () => {
    setTokenState('');
    setRememberToken(false);
    localStorage.removeItem(TOKEN_KEY);
  };

  return { 
    token, 
    setToken, 
    clearToken,
    rememberToken,
    setRememberToken
  };
}
```

**Acceptance Criteria**:
- [ ] Token persists if user opts in
- [ ] Clears properly on logout
- [ ] Secure (encrypted in production)
- [ ] Works across page reloads

---

### Task 2.4: Create Unified Form Component
**File**: `frontend/src/components/SAEManagementForm.tsx`

This is the **main component** - see the detailed code in `/mnt/user-data/outputs/Unified_SAE_Interface_Implementation.md` section on "Unified Form Component".

**Key Features**:
- Tab toggle between Download/Upload
- Shared fields (repo, token, model)
- Mode-specific fields (progressive disclosure)
- State preservation on mode switch
- Unified validation display
- Dynamic help text based on mode

**Acceptance Criteria**:
- [ ] Tabs switch smoothly
- [ ] Shared fields preserve values
- [ ] Mode-specific fields show/hide correctly
- [ ] Validation works for both modes
- [ ] Submit button text updates dynamically
- [ ] Help text changes based on mode

---
**File**: `frontend/src/api/uploadApi.ts`

```typescript
/**
 * API client for SAE upload operations.
 */

import axios from 'axios';

const API_BASE = '/api/sae/upload';

export interface ValidationRequest {
  repo_name: string;
  token: string;
  sae_ids: string[];
  visibility: 'public' | 'private';
}

export interface ValidationResult {
  valid: boolean;
  errors?: Record<string, string>;
  warnings?: string[];
  token_permissions?: {
    username: string;
    can_write: boolean;
    can_create_repo: boolean;
  };
  estimated_size_mb?: number;
  estimated_time_seconds?: number;
}

export interface UploadRequest extends ValidationRequest {
  description?: string;
  commit_message?: string;
}

export interface UploadJob {
  job_id: string;
  status: 'validating' | 'preparing' | 'uploading' | 'complete' | 'failed' | 'cancelled';
  progress: number;
  current_sae?: string;
  current_sae_progress?: number;
  completed_saes: string[];
  failed_saes: Array<[string, string]>;
  repo_url?: string;
  created_at: string;
  updated_at: string;
  estimated_time_remaining?: number;
}

export const uploadApi = {
  /**
   * Validate upload configuration.
   */
  async validate(request: ValidationRequest): Promise<ValidationResult> {
    const response = await axios.post(`${API_BASE}/validate`, request);
    return response.data;
  },

  /**
   * Execute upload and return job ID.
   */
  async execute(request: UploadRequest): Promise<{ job_id: string; status: string }> {
    const response = await axios.post(`${API_BASE}/execute`, request);
    return response.data;
  },

  /**
   * Get upload job status.
   */
  async getStatus(jobId: string): Promise<UploadJob> {
    const response = await axios.get(`${API_BASE}/status/${jobId}`);
    return response.data;
  },

  /**
   * Cancel upload job.
   */
  async cancel(jobId: string): Promise<void> {
    await axios.delete(`${API_BASE}/cancel/${jobId}`);
  },

  /**
   * Preview generated README.
   */
  async previewReadme(request: UploadRequest): Promise<string> {
    const response = await axios.post(`${API_BASE}/preview-readme`, request);
    return response.data.readme;
  }
};
```

**Acceptance Criteria**:
- [ ] All API methods properly typed
- [ ] Error handling included
- [ ] Request/response interfaces match backend

---

### Task 2.2: Create Upload Hook
**File**: `frontend/src/hooks/useUploadJob.ts`

```typescript
/**
 * Hook for managing upload job state and polling.
 */

import { useState, useEffect, useCallback } from 'react';
import { uploadApi, UploadJob } from '../api/uploadApi';

export function useUploadJob(jobId: string | null) {
  const [job, setJob] = useState<UploadJob | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Poll for job status
  useEffect(() => {
    if (!jobId) return;

    const pollInterval = setInterval(async () => {
      try {
        const status = await uploadApi.getStatus(jobId);
        setJob(status);

        // Stop polling if complete, failed, or cancelled
        if (['complete', 'failed', 'cancelled'].includes(status.status)) {
          clearInterval(pollInterval);
        }
      } catch (err) {
        setError(err.message);
        clearInterval(pollInterval);
      }
    }, 2000); // Poll every 2 seconds

    return () => clearInterval(pollInterval);
  }, [jobId]);

  const cancel = useCallback(async () => {
    if (!jobId) return;

    setIsLoading(true);
    try {
      await uploadApi.cancel(jobId);
      setJob(prev => prev ? { ...prev, status: 'cancelled' } : null);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, [jobId]);

  return {
    job,
    error,
    isLoading,
    cancel,
    isComplete: job?.status === 'complete',
    isFailed: job?.status === 'failed',
    isCancelled: job?.status === 'cancelled',
    isActive: job && ['validating', 'preparing', 'uploading'].includes(job.status)
  };
}
```

**Acceptance Criteria**:
- [ ] Polls for status correctly
- [ ] Stops polling when complete
- [ ] Cancel function works
- [ ] Proper error handling

---

### Task 2.3: Create SAE Selector Component
**File**: `frontend/src/components/SAESelector.tsx`

```typescript
/**
 * Multi-select component for choosing SAEs to upload.
 */

import React, { useState, useMemo } from 'react';
import { Checkbox, Input, Badge, Text } from '@/components/ui';

interface SAE {
  id: string;
  name: string;
  layer: number;
  hook_type: string;
  feature_count: number;
  size_mb: number;
  model_name: string;
  is_trained: boolean;
}

interface SAESelectorProps {
  saes: SAE[];
  selectedIds: string[];
  onSelectionChange: (ids: string[]) => void;
  maxSelection?: number;
}

export function SAESelector({
  saes,
  selectedIds,
  onSelectionChange,
  maxSelection
}: SAESelectorProps) {
  const [searchQuery, setSearchQuery] = useState('');

  // Filter to only trained SAEs
  const trainedSAEs = useMemo(
    () => saes.filter(sae => sae.is_trained),
    [saes]
  );

  // Filter by search
  const filteredSAEs = useMemo(() => {
    if (!searchQuery) return trainedSAEs;
    
    const query = searchQuery.toLowerCase();
    return trainedSAEs.filter(sae =>
      sae.name.toLowerCase().includes(query) ||
      sae.model_name.toLowerCase().includes(query) ||
      sae.hook_type.toLowerCase().includes(query)
    );
  }, [trainedSAEs, searchQuery]);

  // Calculate totals
  const selectedSAEs = useMemo(
    () => trainedSAEs.filter(sae => selectedIds.includes(sae.id)),
    [trainedSAEs, selectedIds]
  );

  const totalSize = selectedSAEs.reduce((sum, sae) => sum + sae.size_mb, 0);
  const totalFeatures = selectedSAEs.reduce((sum, sae) => sum + sae.feature_count, 0);

  const handleToggle = (saeId: string) => {
    const isSelected = selectedIds.includes(saeId);
    
    if (isSelected) {
      onSelectionChange(selectedIds.filter(id => id !== saeId));
    } else {
      if (maxSelection && selectedIds.length >= maxSelection) {
        // Show warning
        return;
      }
      onSelectionChange([...selectedIds, saeId]);
    }
  };

  const handleSelectAll = () => {
    if (selectedIds.length === filteredSAEs.length) {
      onSelectionChange([]);
    } else {
      const toSelect = maxSelection
        ? filteredSAEs.slice(0, maxSelection).map(s => s.id)
        : filteredSAEs.map(s => s.id);
      onSelectionChange(toSelect);
    }
  };

  if (trainedSAEs.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        <p>No trained SAEs available for upload.</p>
        <p className="text-sm mt-2">
          Train SAEs in the Training page first.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Search */}
      <Input
        type="text"
        placeholder="Search SAEs..."
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        className="w-full"
      />

      {/* Select All */}
      <div className="flex items-center justify-between">
        <Checkbox
          checked={selectedIds.length === filteredSAEs.length && filteredSAEs.length > 0}
          onCheckedChange={handleSelectAll}
          label={`Select All (${filteredSAEs.length})`}
        />
        
        {maxSelection && (
          <Text variant="muted" size="sm">
            Max {maxSelection} SAEs
          </Text>
        )}
      </div>

      {/* SAE List */}
      <div className="max-h-96 overflow-y-auto space-y-2 border rounded-lg p-4">
        {filteredSAEs.map(sae => (
          <div
            key={sae.id}
            className={`
              flex items-start gap-3 p-3 rounded-lg border-2 cursor-pointer
              transition-colors
              ${selectedIds.includes(sae.id)
                ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                : 'border-gray-200 hover:border-gray-300 dark:border-gray-700'
              }
            `}
            onClick={() => handleToggle(sae.id)}
          >
            <Checkbox
              checked={selectedIds.includes(sae.id)}
              onCheckedChange={() => handleToggle(sae.id)}
            />
            
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <Text weight="semibold">{sae.name}</Text>
                <Badge variant="secondary">Trained</Badge>
              </div>
              
              <Text variant="muted" size="sm" className="mt-1">
                Layer {sae.layer} • {sae.hook_type} • {sae.feature_count.toLocaleString()} features
              </Text>
              
              <Text variant="muted" size="sm">
                {sae.model_name} • {sae.size_mb.toFixed(1)} MB
              </Text>
            </div>
          </div>
        ))}
      </div>

      {/* Selection Summary */}
      {selectedIds.length > 0 && (
        <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
          <Text size="sm">
            <strong>Selected:</strong> {selectedIds.length} SAEs • {' '}
            {totalFeatures.toLocaleString()} total features • {' '}
            {totalSize.toFixed(1)} MB
          </Text>
        </div>
      )}
    </div>
  );
}
```

**Acceptance Criteria**:
- [ ] Shows only trained SAEs
- [ ] Search filters correctly
- [ ] Selection state managed properly
- [ ] Shows selection summary
- [ ] Respects max selection limit

---

### Task 2.4: Create Upload Form Component
**File**: `frontend/src/components/SAEUploadSection.tsx`

```typescript
/**
 * Main upload form section.
 */

import React, { useState } from 'react';
import {
  Button,
  Input,
  Textarea,
  RadioGroup,
  Collapsible
} from '@/components/ui';
import { SAESelector } from './SAESelector';
import { UploadProgressModal } from './UploadProgressModal';
import { uploadApi, ValidationResult } from '../api/uploadApi';
import { useToast } from '@/hooks/useToast';

interface SAEUploadSectionProps {
  saes: SAE[];
  onUploadComplete?: (repoUrl: string) => void;
}

export function SAEUploadSection({ saes, onUploadComplete }: SAEUploadSectionProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [repoName, setRepoName] = useState('');
  const [token, setToken] = useState('');
  const [visibility, setVisibility] = useState<'public' | 'private'>('private');
  const [description, setDescription] = useState('');
  const [selectedSAEIds, setSelectedSAEIds] = useState<string[]>([]);
  const [validationResult, setValidationResult] = useState<ValidationResult | null>(null);
  const [isValidating, setIsValidating] = useState(false);
  const [currentJobId, setCurrentJobId] = useState<string | null>(null);
  
  const { toast } = useToast();

  // Validate as user types
  const handleValidate = async () => {
    if (!repoName || !token || selectedSAEIds.length === 0) return;

    setIsValidating(true);
    try {
      const result = await uploadApi.validate({
        repo_name: repoName,
        token: token,
        sae_ids: selectedSAEIds,
        visibility
      });
      
      setValidationResult(result);
      
      if (!result.valid) {
        toast({
          title: 'Validation Failed',
          description: Object.values(result.errors || {}).join(', '),
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Validation Error',
        description: error.message,
        variant: 'destructive'
      });
    } finally {
      setIsValidating(false);
    }
  };

  const handleUpload = async () => {
    if (!validationResult?.valid) {
      await handleValidate();
      if (!validationResult?.valid) return;
    }

    try {
      const response = await uploadApi.execute({
        repo_name: repoName,
        token: token,
        sae_ids: selectedSAEIds,
        visibility,
        description: description || undefined,
        commit_message: 'Upload SAE weights from MechInterp Studio'
      });

      setCurrentJobId(response.job_id);
      
      toast({
        title: 'Upload Started',
        description: 'Your SAEs are being uploaded to HuggingFace'
      });
    } catch (error) {
      toast({
        title: 'Upload Failed',
        description: error.message,
        variant: 'destructive'
      });
    }
  };

  const canUpload = 
    repoName && 
    token && 
    selectedSAEIds.length > 0 &&
    validationResult?.valid;

  return (
    <>
      <Collapsible
        open={isOpen}
        onOpenChange={setIsOpen}
        className="border rounded-lg p-4"
      >
        <Collapsible.Trigger className="flex items-center justify-between w-full">
          <div className="flex items-center gap-2">
            <span className="text-2xl">📤</span>
            <h3 className="text-lg font-semibold">Upload to HuggingFace</h3>
          </div>
          <Button variant="ghost" size="sm">
            {isOpen ? 'Collapse' : 'Expand'}
          </Button>
        </Collapsible.Trigger>

        <Collapsible.Content className="mt-4 space-y-6">
          {/* Repository Name */}
          <div>
            <label className="block text-sm font-medium mb-2">
              Repository Name
            </label>
            <Input
              type="text"
              placeholder="your-username/model-name-saes"
              value={repoName}
              onChange={(e) => setRepoName(e.target.value)}
              onBlur={handleValidate}
            />
            {validationResult?.errors?.repo_name && (
              <p className="text-sm text-red-500 mt-1">
                {validationResult.errors.repo_name}
              </p>
            )}
            <p className="text-sm text-gray-500 mt-1">
              ℹ️ Will create repository if it doesn't exist
            </p>
          </div>

          {/* Access Token */}
          <div>
            <label className="block text-sm font-medium mb-2">
              Access Token (required)
            </label>
            <Input
              type="password"
              placeholder="hf_••••••••••••••••••••••••"
              value={token}
              onChange={(e) => setToken(e.target.value)}
              onBlur={handleValidate}
            />
            {validationResult?.errors?.token && (
              <p className="text-sm text-red-500 mt-1">
                {validationResult.errors.token}
              </p>
            )}
            {validationResult?.token_permissions && (
              <p className="text-sm text-green-600 mt-1">
                ✓ Authenticated as {validationResult.token_permissions.username}
              </p>
            )}
            <p className="text-sm text-gray-500 mt-1">
              ℹ️ Token must have write permissions
            </p>
          </div>

          {/* Visibility */}
          <div>
            <label className="block text-sm font-medium mb-2">
              Repository Visibility
            </label>
            <RadioGroup
              value={visibility}
              onValueChange={(v) => setVisibility(v as 'public' | 'private')}
              options={[
                { value: 'public', label: 'Public' },
                { value: 'private', label: 'Private' }
              ]}
            />
          </div>

          {/* SAE Selection */}
          <div>
            <label className="block text-sm font-medium mb-2">
              Select SAEs to Upload
            </label>
            <SAESelector
              saes={saes}
              selectedIds={selectedSAEIds}
              onSelectionChange={setSelectedSAEIds}
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-medium mb-2">
              Description (optional)
            </label>
            <Textarea
              placeholder="Describe your SAEs..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
          </div>

          {/* Validation Warnings */}
          {validationResult?.warnings && validationResult.warnings.length > 0 && (
            <div className="p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
              <p className="text-sm font-medium text-yellow-800 dark:text-yellow-200">
                ⚠️ Warnings:
              </p>
              <ul className="list-disc list-inside text-sm text-yellow-700 dark:text-yellow-300 mt-1">
                {validationResult.warnings.map((warning, i) => (
                  <li key={i}>{warning}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Estimates */}
          {validationResult?.estimated_size_mb && (
            <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <p className="text-sm">
                <strong>Estimated upload:</strong>{' '}
                {validationResult.estimated_size_mb.toFixed(1)} MB • {' '}
                ~{Math.ceil(validationResult.estimated_time_seconds / 60)} minutes
              </p>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-3">
            <Button
              onClick={handleUpload}
              disabled={!canUpload || isValidating}
              className="flex-1"
            >
              📤 Upload to HuggingFace
            </Button>
            
            <Button
              variant="outline"
              onClick={handleValidate}
              disabled={isValidating}
            >
              {isValidating ? 'Validating...' : 'Validate'}
            </Button>
          </div>
        </Collapsible.Content>
      </Collapsible>

      {/* Progress Modal */}
      {currentJobId && (
        <UploadProgressModal
          jobId={currentJobId}
          onClose={() => setCurrentJobId(null)}
          onComplete={onUploadComplete}
        />
      )}
    </>
  );
}
```

**Acceptance Criteria**:
- [ ] Form validation works
- [ ] All fields properly controlled
- [ ] Validation on blur
- [ ] Shows errors and warnings
- [ ] Upload initiates correctly

---

### Task 2.5: Create Upload Progress Modal
**File**: `frontend/src/components/UploadProgressModal.tsx`

```typescript
/**
 * Modal showing upload progress with ability to cancel.
 */

import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  Progress,
  Button,
  Badge
} from '@/components/ui';
import { useUploadJob } from '../hooks/useUploadJob';

interface UploadProgressModalProps {
  jobId: string;
  onClose: () => void;
  onComplete?: (repoUrl: string) => void;
}

export function UploadProgressModal({
  jobId,
  onClose,
  onComplete
}: UploadProgressModalProps) {
  const { job, error, cancel, isComplete, isFailed } = useUploadJob(jobId);

  // Auto-close on complete after showing success
  React.useEffect(() => {
    if (isComplete && job?.repo_url) {
      setTimeout(() => {
        onComplete?.(job.repo_url);
        onClose();
      }, 3000);
    }
  }, [isComplete, job, onComplete, onClose]);

  if (!job) {
    return (
      <Dialog open onOpenChange={onClose}>
        <DialogContent>
          <div className="text-center py-8">
            <p>Loading upload status...</p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>
            {isComplete && '✓ '}
            {isFailed && '✗ '}
            Uploading to HuggingFace
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Repository Info */}
          <div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Repository: <strong>{job.config.repo_name}</strong>
            </p>
          </div>

          {/* Overall Progress */}
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span>Overall Progress: {job.completed_saes.length} of {job.config.sae_ids.length} SAEs</span>
              <span>{Math.round(job.progress * 100)}%</span>
            </div>
            <Progress value={job.progress * 100} />
          </div>

          {/* Current SAE */}
          {job.current_sae && !isComplete && (
            <div>
              <p className="text-sm font-medium mb-2">
                Current: {job.current_sae}
              </p>
              <Progress value={job.current_sae_progress * 100} />
            </div>
          )}

          {/* Completed SAEs */}
          {job.completed_saes.length > 0 && (
            <div>
              <p className="text-sm font-medium mb-2">Completed:</p>
              <div className="space-y-1">
                {job.completed_saes.map(sae => (
                  <div key={sae} className="flex items-center gap-2 text-sm">
                    <span className="text-green-500">✓</span>
                    <span>{sae}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Failed SAEs */}
          {job.failed_saes.length > 0 && (
            <div>
              <p className="text-sm font-medium mb-2 text-red-600">Failed:</p>
              <div className="space-y-1">
                {job.failed_saes.map(([sae, error]) => (
                  <div key={sae} className="text-sm">
                    <div className="flex items-center gap-2">
                      <span className="text-red-500">✗</span>
                      <span>{sae}</span>
                    </div>
                    <p className="text-xs text-red-600 ml-6">{error}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Time Estimate */}
          {job.estimated_time_remaining && !isComplete && (
            <div className="text-sm text-gray-600 dark:text-gray-400">
              Estimated time remaining: {Math.ceil(job.estimated_time_remaining / 60)} minutes
            </div>
          )}

          {/* Success State */}
          {isComplete && job.repo_url && (
            <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <p className="font-medium text-green-800 dark:text-green-200 mb-2">
                ✓ Upload Successful
              </p>
              <p className="text-sm text-green-700 dark:text-green-300 mb-3">
                Successfully uploaded {job.completed_saes.length} SAEs
              </p>
              <Button
                variant="outline"
                size="sm"
                onClick={() => window.open(job.repo_url, '_blank')}
              >
                🔗 View on HuggingFace
              </Button>
            </div>
          )}

          {/* Error State */}
          {error && (
            <div className="p-4 bg-red-50 dark:bg-red-900/20 rounded-lg">
              <p className="text-sm text-red-800 dark:text-red-200">
                Error: {error}
              </p>
            </div>
          )}

          {/* Actions */}
          <div className="flex justify-end gap-2">
            {!isComplete && !isFailed && (
              <Button variant="outline" onClick={cancel}>
                Cancel Upload
              </Button>
            )}
            
            <Button onClick={onClose}>
              {isComplete || isFailed ? 'Close' : 'Close'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
```

**Acceptance Criteria**:
- [ ] Shows real-time progress
- [ ] Updates every 2 seconds
- [ ] Cancel button works
- [ ] Auto-closes on success
- [ ] Shows errors clearly

---

## Phase 3: Integration & Testing (Week 3)

### Task 3.1: Integrate with Existing SAE Page
**File**: `frontend/src/pages/SAEs.tsx`

```typescript
/**
 * Update existing SAE page to include upload section.
 */

// Add import
import { SAEUploadSection } from '../components/SAEUploadSection';

// In component:
function SAEsPage() {
  // ... existing state and logic ...

  const handleUploadComplete = (repoUrl: string) => {
    // Show success toast
    toast({
      title: 'Upload Complete',
      description: `SAEs uploaded to ${repoUrl}`,
      action: (
        <Button
          variant="outline"
          size="sm"
          onClick={() => window.open(repoUrl, '_blank')}
        >
          View
        </Button>
      )
    });

    // Refresh SAE list to show updated status
    refreshSAEList();
  };

  return (
    <div className="container mx-auto p-6 space-y-8">
      {/* Existing download section */}
      <section>
        <h2>Download from HuggingFace</h2>
        {/* ... existing download UI ... */}
      </section>

      {/* NEW: Upload section */}
      <section>
        <SAEUploadSection
          saes={saes}
          onUploadComplete={handleUploadComplete}
        />
      </section>

      {/* Existing SAE list */}
      <section>
        <h2>Your SAEs ({saes.length})</h2>
        {/* ... existing SAE list ... */}
      </section>
    </div>
  );
}
```

**Acceptance Criteria**:
- [ ] Upload section appears below download
- [ ] Both sections work independently
- [ ] Upload completion refreshes list
- [ ] UI layout remains clean

---

### Task 3.2: Update SAE Card Component
**File**: `frontend/src/components/SAECard.tsx`

```typescript
/**
 * Update SAE card to show upload status.
 */

interface SAECardProps {
  sae: SAE & {
    uploaded_to?: string;  // HF repo URL if uploaded
    upload_date?: string;
  };
  // ... other props
}

export function SAECard({ sae, ...props }: SAECardProps) {
  return (
    <div className="border rounded-lg p-4">
      {/* Existing content */}
      <div className="flex items-center justify-between">
        <h3>{sae.name}</h3>
        <div className="flex gap-2">
          {sae.source === 'huggingface' && (
            <Badge variant="secondary">🏷️ HuggingFace</Badge>
          )}
          {sae.is_trained && (
            <Badge variant="secondary">🎓 Trained</Badge>
          )}
        </div>
      </div>

      {/* NEW: Upload status */}
      {sae.uploaded_to && (
        <div className="mt-2 p-2 bg-green-50 dark:bg-green-900/20 rounded">
          <p className="text-sm text-green-800 dark:text-green-200">
            📤 Uploaded to {sae.uploaded_to}
          </p>
          <Button
            variant="link"
            size="sm"
            onClick={() => window.open(`https://huggingface.co/${sae.uploaded_to}`, '_blank')}
            className="h-auto p-0 text-green-600"
          >
            View on HuggingFace →
          </Button>
        </div>
      )}

      {/* Rest of card content */}
    </div>
  );
}
```

**Acceptance Criteria**:
- [ ] Shows upload status when uploaded
- [ ] Link to HF repo works
- [ ] Styling matches existing design
- [ ] Status persists after refresh

---

### Task 3.3: Add Upload History/Log
**File**: `frontend/src/components/UploadHistory.tsx`

```typescript
/**
 * Component showing recent upload history.
 */

export function UploadHistory() {
  const [uploads, setUploads] = useState([]);

  useEffect(() => {
    // Load from local storage or API
    const history = JSON.parse(localStorage.getItem('upload_history') || '[]');
    setUploads(history);
  }, []);

  if (uploads.length === 0) return null;

  return (
    <div className="border rounded-lg p-4">
      <h3 className="font-semibold mb-4">Recent Uploads</h3>
      <div className="space-y-2">
        {uploads.slice(0, 5).map(upload => (
          <div key={upload.job_id} className="flex items-center justify-between text-sm">
            <div>
              <p className="font-medium">{upload.repo_name}</p>
              <p className="text-gray-500">
                {upload.sae_count} SAEs • {new Date(upload.completed_at).toLocaleDateString()}
              </p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => window.open(`https://huggingface.co/${upload.repo_name}`, '_blank')}
            >
              View →
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
}
```

**Acceptance Criteria**:
- [ ] Shows last 5 uploads
- [ ] Persists across sessions
- [ ] Links work correctly
- [ ] Shows when uploads happened

---

### Task 3.4: End-to-End Testing
**File**: `tests/e2e/sae_upload.test.ts`

```typescript
/**
 * E2E tests for SAE upload flow.
 */

describe('SAE Upload Flow', () => {
  it('should complete full upload successfully', async () => {
    // 1. Navigate to SAE page
    // 2. Expand upload section
    // 3. Fill in repo name
    // 4. Enter token
    // 5. Select SAEs
    // 6. Click upload
    // 7. Wait for completion
    // 8. Verify success message
    // 9. Check SAE card shows upload status
  });

  it('should validate token before upload', async () => {
    // Test invalid token handling
  });

  it('should show progress during upload', async () => {
    // Test progress modal updates
  });

  it('should allow cancelling upload', async () => {
    // Test cancel functionality
  });

  it('should handle upload errors gracefully', async () => {
    // Test error scenarios
  });
});
```

**Acceptance Criteria**:
- [ ] All E2E tests pass
- [ ] Tests cover happy path
- [ ] Tests cover error scenarios
- [ ] Tests run in CI/CD

---

## Phase 4: Documentation & Polish (Week 4)

### Task 4.1: Add User Documentation
**File**: `docs/features/sae-upload.md`

```markdown
# Uploading SAEs to HuggingFace

## Overview
MechInterp Studio allows you to upload your trained SAEs directly to HuggingFace, making them available for the research community or your private use.

## Prerequisites
1. A HuggingFace account
2. A personal access token with write permissions
3. At least one trained SAE

## Getting a HuggingFace Token
1. Go to https://huggingface.co/settings/tokens
2. Click "New token"
3. Give it a name (e.g., "MechInterp Studio")
4. Select "write" permission
5. Click "Generate"
6. Copy the token (starts with `hf_`)

## Uploading SAEs

### Step 1: Navigate to SAE Page
... (detailed steps)

### Step 2: Configure Upload
... (detailed steps)

### Step 3: Monitor Progress
... (detailed steps)

## Repository Structure
Your SAEs will be organized as follows:
...

## Troubleshooting
... (common issues and solutions)
```

**Acceptance Criteria**:
- [ ] Documentation covers all features
- [ ] Includes screenshots
- [ ] Troubleshooting section complete
- [ ] Examples provided

---

### Task 4.2: Add Tutorial/Onboarding
**File**: `frontend/src/components/UploadTutorial.tsx`

```typescript
/**
 * Interactive tutorial for first-time upload.
 */

export function UploadTutorial() {
  // Step-by-step guide with highlights
  // Shows on first visit to upload section
}
```

**Acceptance Criteria**:
- [ ] Tutorial covers all steps
- [ ] Can be skipped
- [ ] Only shows once
- [ ] Highlights relevant UI elements

---

### Task 4.3: Add Analytics
**File**: `backend/services/analytics_service.py`

```python
"""
Track upload metrics for product improvement.
"""

class UploadAnalytics:
    def track_upload_start(self, config: UploadConfig):
        """Track when upload starts."""
        pass
    
    def track_upload_complete(self, job: UploadJob):
        """Track successful upload."""
        pass
    
    def track_upload_error(self, job: UploadJob, error: str):
        """Track upload failure."""
        pass
```

**Acceptance Criteria**:
- [ ] Tracks key metrics
- [ ] Privacy-preserving (no tokens logged)
- [ ] Aggregated analytics available
- [ ] No PII collected

---

## Testing Checklist

### Unit Tests
- [ ] HuggingFaceClient methods
- [ ] Metadata extraction
- [ ] README generation
- [ ] Upload validation
- [ ] Data model serialization

### Integration Tests
- [ ] API endpoints
- [ ] Upload workflow
- [ ] Progress tracking
- [ ] Error handling

### E2E Tests
- [ ] Full upload flow
- [ ] Cancel upload
- [ ] Multi-SAE upload
- [ ] Error scenarios

### Manual Testing
- [ ] Upload to test HF repo
- [ ] Verify structure on HF
- [ ] Download uploaded SAE
- [ ] Verify integrity
- [ ] Test on slow network
- [ ] Test with large SAEs (>1GB)
- [ ] Mobile responsiveness

---

## Deployment Checklist

### Backend
- [ ] Environment variables configured
- [ ] HF credentials secure
- [ ] Rate limiting in place
- [ ] Monitoring setup
- [ ] Error tracking (Sentry)

### Frontend
- [ ] Build optimized
- [ ] API endpoints correct
- [ ] Error boundaries in place
- [ ] Loading states tested

### Documentation
- [ ] User docs published
- [ ] API docs updated
- [ ] Changelog updated
- [ ] Release notes written

---

## Success Metrics

Track these metrics post-launch:
- [ ] Upload success rate (target: >95%)
- [ ] Average upload time
- [ ] Number of uploads per week
- [ ] User feedback (NPS)
- [ ] Error rate by type
- [ ] Token validation failures

---

## Files to Create/Modify Summary

### Backend (Python)
```
backend/
├── services/
│   ├── hf_client.py                  (new)
│   ├── sae_upload_service.py         (new)
│   ├── sae_metadata_extractor.py     (new)
│   ├── readme_generator.py           (new)
│   └── analytics_service.py          (new)
├── models/
│   └── upload_models.py              (new)
├── api/routes/
│   └── sae_upload.py                 (new)
└── tests/
    ├── test_hf_client.py             (new)
    ├── test_upload_service.py        (new)
    └── test_metadata_extractor.py    (new)
```

### Frontend (TypeScript/React)
```
frontend/src/
├── api/
│   └── uploadApi.ts                  (new)
├── hooks/
│   ├── useUploadJob.ts               (new)
│   └── useHFToken.ts                 (new)
├── components/
│   ├── SAEUploadSection.tsx          (new)
│   ├── SAESelector.tsx               (new)
│   ├── UploadProgressModal.tsx       (new)
│   ├── UploadHistory.tsx             (new)
│   ├── UploadTutorial.tsx            (new)
│   └── SAECard.tsx                   (modify)
├── pages/
│   └── SAEs.tsx                      (modify)
└── tests/
    └── e2e/sae_upload.test.ts        (new)
```

### Documentation
```
docs/
├── features/
│   └── sae-upload.md                 (new)
└── api/
    └── upload-endpoints.md           (new)
```

---

## Implementation Notes for Claude Code

### Key Dependencies to Install
```bash
# Backend
pip install huggingface-hub safetensors

# Frontend
npm install @huggingface/hub
```

### Environment Variables Needed
```bash
# .env
HF_TOKEN_ENCRYPTION_KEY=<generate-random-key>
UPLOAD_TEMP_DIR=/tmp/sae_uploads
MAX_UPLOAD_SIZE_MB=5000
```

### Database Schema Updates
```sql
-- Add upload tracking columns to SAE table
ALTER TABLE saes ADD COLUMN uploaded_to TEXT;
ALTER TABLE saes ADD COLUMN upload_date TIMESTAMP;
ALTER TABLE saes ADD COLUMN hf_repo_url TEXT;

-- Create upload history table
CREATE TABLE upload_history (
  id UUID PRIMARY KEY,
  job_id TEXT UNIQUE,
  repo_name TEXT,
  sae_ids JSONB,
  status TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  completed_at TIMESTAMP,
  error TEXT
);
```

### Priority Order
1. Backend services (HF client, metadata, upload service)
2. API endpoints
3. Frontend components
4. Integration
5. Testing
6. Documentation

### Notes for Implementation
- Use existing UI component library throughout
- Follow existing code style and patterns
- Reuse auth/token handling from downloads
- Maintain consistency with download UI
- Test with real HuggingFace repos frequently
- Start with single SAE, then add batch support
- Focus on error handling—many things can go wrong

---

**Document Version**: 1.0
**Created**: 2025-01-15
**Status**: Ready for Implementation
**Estimated Effort**: 4 weeks (1 developer)
