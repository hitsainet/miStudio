--
-- PostgreSQL database dump
--

\restrict yq5xA2Bhc3cA9aN8pzy1pdf0qOEKfEYUGR5Zv7de08ZpHpzktbqb2732fDk376n

-- Dumped from database version 14.20
-- Dumped by pg_dump version 14.20

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: analysis_type_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.analysis_type_enum AS ENUM (
    'logit_lens',
    'correlations',
    'ablation',
    'nlp_analysis'
);


ALTER TYPE public.analysis_type_enum OWNER TO postgres;

--
-- Name: dataset_status_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.dataset_status_enum AS ENUM (
    'DOWNLOADING',
    'PROCESSING',
    'READY',
    'ERROR'
);


ALTER TYPE public.dataset_status_enum OWNER TO postgres;

--
-- Name: export_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.export_status AS ENUM (
    'pending',
    'computing',
    'packaging',
    'completed',
    'failed',
    'cancelled'
);


ALTER TYPE public.export_status OWNER TO postgres;

--
-- Name: extraction_status_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.extraction_status_enum AS ENUM (
    'queued',
    'extracting',
    'completed',
    'failed',
    'cancelled'
);


ALTER TYPE public.extraction_status_enum OWNER TO postgres;

--
-- Name: extractionstatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.extractionstatus AS ENUM (
    'QUEUED',
    'LOADING',
    'EXTRACTING',
    'SAVING',
    'COMPLETED',
    'FAILED',
    'CANCELLED'
);


ALTER TYPE public.extractionstatus OWNER TO postgres;

--
-- Name: label_source_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.label_source_enum AS ENUM (
    'auto',
    'user'
);


ALTER TYPE public.label_source_enum OWNER TO postgres;

--
-- Name: model_status_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.model_status_enum AS ENUM (
    'downloading',
    'loading',
    'ready',
    'error'
);


ALTER TYPE public.model_status_enum OWNER TO postgres;

--
-- Name: modelstatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.modelstatus AS ENUM (
    'DOWNLOADING',
    'LOADING',
    'QUANTIZING',
    'READY',
    'ERROR'
);


ALTER TYPE public.modelstatus OWNER TO postgres;

--
-- Name: quantizationformat; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.quantizationformat AS ENUM (
    'FP32',
    'FP16',
    'Q8',
    'Q4',
    'Q2'
);


ALTER TYPE public.quantizationformat OWNER TO postgres;

--
-- Name: tokenization_status_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tokenization_status_enum AS ENUM (
    'QUEUED',
    'PROCESSING',
    'READY',
    'ERROR'
);


ALTER TYPE public.tokenization_status_enum OWNER TO postgres;

--
-- Name: update_prompt_templates_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_prompt_templates_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
        BEGIN
            NEW.updated_at = NOW();
            RETURN NEW;
        END;
        $$;


ALTER FUNCTION public.update_prompt_templates_updated_at() OWNER TO postgres;

--
-- Name: update_training_templates_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_training_templates_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
        BEGIN
            NEW.updated_at = NOW();
            RETURN NEW;
        END;
        $$;


ALTER FUNCTION public.update_training_templates_updated_at() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activation_extractions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activation_extractions (
    id character varying(255) NOT NULL,
    model_id character varying(255) NOT NULL,
    dataset_id character varying(255) NOT NULL,
    celery_task_id character varying(255),
    layer_indices integer[] NOT NULL,
    hook_types character varying[] NOT NULL,
    max_samples integer NOT NULL,
    batch_size integer NOT NULL,
    status public.extractionstatus NOT NULL,
    progress double precision,
    samples_processed integer,
    error_message text,
    output_path character varying(1000),
    metadata_path character varying(1000),
    statistics jsonb,
    saved_files character varying[],
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    retry_count integer DEFAULT 0 NOT NULL,
    original_extraction_id character varying(255),
    retry_reason text,
    auto_retried boolean DEFAULT false NOT NULL,
    error_type character varying(50),
    micro_batch_size integer
);


ALTER TABLE public.activation_extractions OWNER TO postgres;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: checkpoints; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.checkpoints (
    id character varying(255) NOT NULL,
    training_id character varying(255) NOT NULL,
    step integer NOT NULL,
    loss double precision NOT NULL,
    l0_sparsity double precision,
    storage_path character varying(1000) NOT NULL,
    file_size_bytes bigint,
    is_best boolean NOT NULL,
    extra_metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.checkpoints OWNER TO postgres;

--
-- Name: COLUMN checkpoints.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.checkpoints.id IS 'Checkpoint ID (format: ckpt_{uuid})';


--
-- Name: COLUMN checkpoints.training_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.checkpoints.training_id IS 'Reference to training job';


--
-- Name: COLUMN checkpoints.step; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.checkpoints.step IS 'Training step at checkpoint';


--
-- Name: COLUMN checkpoints.loss; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.checkpoints.loss IS 'Loss at checkpoint';


--
-- Name: COLUMN checkpoints.l0_sparsity; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.checkpoints.l0_sparsity IS 'L0 sparsity at checkpoint';


--
-- Name: COLUMN checkpoints.storage_path; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.checkpoints.storage_path IS 'Path to checkpoint file (.safetensors)';


--
-- Name: COLUMN checkpoints.file_size_bytes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.checkpoints.file_size_bytes IS 'Checkpoint file size in bytes';


--
-- Name: COLUMN checkpoints.is_best; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.checkpoints.is_best IS 'True if this is the best checkpoint';


--
-- Name: COLUMN checkpoints.extra_metadata; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.checkpoints.extra_metadata IS 'Additional checkpoint metadata';


--
-- Name: COLUMN checkpoints.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.checkpoints.created_at IS 'Checkpoint creation timestamp';


--
-- Name: dataset_tokenizations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dataset_tokenizations (
    id character varying(255) NOT NULL,
    dataset_id uuid NOT NULL,
    model_id character varying(255) NOT NULL,
    tokenized_path character varying(512),
    tokenizer_repo_id character varying(255) NOT NULL,
    vocab_size integer,
    num_tokens bigint,
    avg_seq_length double precision,
    status public.tokenization_status_enum DEFAULT 'QUEUED'::public.tokenization_status_enum NOT NULL,
    progress double precision DEFAULT '0'::double precision,
    error_message text,
    celery_task_id character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    remove_all_punctuation boolean DEFAULT false NOT NULL,
    custom_filter_chars character varying(255)
);


ALTER TABLE public.dataset_tokenizations OWNER TO postgres;

--
-- Name: COLUMN dataset_tokenizations.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.dataset_tokenizations.id IS 'Unique tokenization identifier (format: tok_{dataset_id}_{model_id})';


--
-- Name: COLUMN dataset_tokenizations.dataset_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.dataset_tokenizations.dataset_id IS 'Parent dataset ID';


--
-- Name: COLUMN dataset_tokenizations.model_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.dataset_tokenizations.model_id IS 'Model whose tokenizer was used';


--
-- Name: COLUMN dataset_tokenizations.tokenized_path; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.dataset_tokenizations.tokenized_path IS 'Path to tokenized dataset (Arrow format)';


--
-- Name: COLUMN dataset_tokenizations.tokenizer_repo_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.dataset_tokenizations.tokenizer_repo_id IS 'HuggingFace tokenizer repository ID';


--
-- Name: COLUMN dataset_tokenizations.vocab_size; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.dataset_tokenizations.vocab_size IS 'Vocabulary size for this tokenization';


--
-- Name: COLUMN dataset_tokenizations.num_tokens; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.dataset_tokenizations.num_tokens IS 'Total number of tokens in tokenized dataset';


--
-- Name: COLUMN dataset_tokenizations.avg_seq_length; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.dataset_tokenizations.avg_seq_length IS 'Average sequence length in tokens';


--
-- Name: COLUMN dataset_tokenizations.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.dataset_tokenizations.status IS 'Current tokenization status';


--
-- Name: COLUMN dataset_tokenizations.progress; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.dataset_tokenizations.progress IS 'Tokenization progress (0-100)';


--
-- Name: COLUMN dataset_tokenizations.error_message; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.dataset_tokenizations.error_message IS 'Error message if status is ERROR';


--
-- Name: COLUMN dataset_tokenizations.celery_task_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.dataset_tokenizations.celery_task_id IS 'Celery task ID for async tokenization';


--
-- Name: COLUMN dataset_tokenizations.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.dataset_tokenizations.created_at IS 'Record creation timestamp';


--
-- Name: COLUMN dataset_tokenizations.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.dataset_tokenizations.updated_at IS 'Record last update timestamp';


--
-- Name: COLUMN dataset_tokenizations.completed_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.dataset_tokenizations.completed_at IS 'Timestamp when tokenization completed';


--
-- Name: COLUMN dataset_tokenizations.remove_all_punctuation; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.dataset_tokenizations.remove_all_punctuation IS 'If true, removes ALL punctuation characters from tokens';


--
-- Name: COLUMN dataset_tokenizations.custom_filter_chars; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.dataset_tokenizations.custom_filter_chars IS 'Custom characters to filter (e.g., ''~@#$%'')';


--
-- Name: datasets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.datasets (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    source character varying(50) NOT NULL,
    hf_repo_id character varying(255),
    status public.dataset_status_enum NOT NULL,
    progress double precision,
    error_message text,
    raw_path character varying(512),
    num_samples integer,
    size_bytes bigint,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    tokenization_filter_enabled boolean DEFAULT false NOT NULL,
    tokenization_filter_mode character varying(20) DEFAULT 'conservative'::character varying NOT NULL,
    tokenization_junk_ratio_threshold double precision DEFAULT '0.7'::double precision NOT NULL
);


ALTER TABLE public.datasets OWNER TO postgres;

--
-- Name: COLUMN datasets.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.datasets.id IS 'Unique dataset identifier';


--
-- Name: COLUMN datasets.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.datasets.name IS 'Dataset name';


--
-- Name: COLUMN datasets.source; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.datasets.source IS 'Source type: HuggingFace, Local, or Custom';


--
-- Name: COLUMN datasets.hf_repo_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.datasets.hf_repo_id IS 'HuggingFace repository ID';


--
-- Name: COLUMN datasets.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.datasets.status IS 'Current processing status';


--
-- Name: COLUMN datasets.progress; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.datasets.progress IS 'Download/processing progress (0-100)';


--
-- Name: COLUMN datasets.error_message; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.datasets.error_message IS 'Error message if status is ERROR';


--
-- Name: COLUMN datasets.raw_path; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.datasets.raw_path IS 'Path to raw dataset files';


--
-- Name: COLUMN datasets.num_samples; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.datasets.num_samples IS 'Total number of samples';


--
-- Name: COLUMN datasets.size_bytes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.datasets.size_bytes IS 'Total size in bytes';


--
-- Name: COLUMN datasets.metadata; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.datasets.metadata IS 'Additional metadata (splits, features, etc.)';


--
-- Name: COLUMN datasets.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.datasets.created_at IS 'Record creation timestamp';


--
-- Name: COLUMN datasets.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.datasets.updated_at IS 'Record last update timestamp';


--
-- Name: external_saes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.external_saes (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    source character varying(50) NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    hf_repo_id character varying(500),
    hf_filepath character varying(1000),
    hf_revision character varying(255),
    training_id character varying(255),
    model_name character varying(255),
    model_id character varying(255),
    layer integer,
    n_features integer,
    d_model integer,
    architecture character varying(100),
    format character varying(50) DEFAULT 'community_standard'::character varying NOT NULL,
    local_path character varying(1000),
    file_size_bytes bigint,
    progress double precision DEFAULT '0'::double precision NOT NULL,
    error_message text,
    sae_metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    downloaded_at timestamp with time zone
);


ALTER TABLE public.external_saes OWNER TO postgres;

--
-- Name: extraction_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.extraction_jobs (
    id character varying(255) NOT NULL,
    training_id character varying(255),
    celery_task_id character varying(255),
    config jsonb NOT NULL,
    status public.extraction_status_enum DEFAULT 'queued'::public.extraction_status_enum NOT NULL,
    progress double precision DEFAULT '0'::double precision,
    features_extracted integer DEFAULT 0,
    total_features integer,
    error_message text,
    statistics jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    filter_special boolean DEFAULT true NOT NULL,
    filter_single_char boolean DEFAULT true NOT NULL,
    filter_punctuation boolean DEFAULT true NOT NULL,
    filter_numbers boolean DEFAULT true NOT NULL,
    filter_fragments boolean DEFAULT true NOT NULL,
    filter_stop_words boolean DEFAULT false NOT NULL,
    context_prefix_tokens integer DEFAULT 5 NOT NULL,
    context_suffix_tokens integer DEFAULT 3 NOT NULL,
    external_sae_id character varying(255),
    nlp_status character varying(50),
    nlp_progress double precision DEFAULT '0'::double precision,
    nlp_processed_count integer DEFAULT 0,
    nlp_error_message text,
    CONSTRAINT check_extraction_single_source CHECK ((((training_id IS NOT NULL) AND (external_sae_id IS NULL)) OR ((training_id IS NULL) AND (external_sae_id IS NOT NULL))))
);


ALTER TABLE public.extraction_jobs OWNER TO postgres;

--
-- Name: COLUMN extraction_jobs.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.extraction_jobs.id IS 'Extraction job ID (format: ext_{training_id}_{timestamp})';


--
-- Name: COLUMN extraction_jobs.training_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.extraction_jobs.training_id IS 'Reference to completed training';


--
-- Name: COLUMN extraction_jobs.celery_task_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.extraction_jobs.celery_task_id IS 'Celery task ID for tracking';


--
-- Name: COLUMN extraction_jobs.config; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.extraction_jobs.config IS 'Extraction config: {evaluation_samples, top_k_examples}';


--
-- Name: COLUMN extraction_jobs.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.extraction_jobs.status IS 'Extraction status';


--
-- Name: COLUMN extraction_jobs.progress; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.extraction_jobs.progress IS 'Extraction progress (0-100)';


--
-- Name: COLUMN extraction_jobs.features_extracted; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.extraction_jobs.features_extracted IS 'Number of features extracted so far';


--
-- Name: COLUMN extraction_jobs.total_features; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.extraction_jobs.total_features IS 'Total number of features to extract';


--
-- Name: COLUMN extraction_jobs.error_message; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.extraction_jobs.error_message IS 'Error message if status is failed';


--
-- Name: COLUMN extraction_jobs.statistics; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.extraction_jobs.statistics IS 'Extraction statistics: {total_features, avg_interpretability, avg_activation_freq, interpretable_count}';


--
-- Name: extraction_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.extraction_templates (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    layer_indices integer[] NOT NULL,
    hook_types character varying(50)[] NOT NULL,
    max_samples integer NOT NULL,
    batch_size integer NOT NULL,
    top_k_examples integer NOT NULL,
    is_favorite boolean DEFAULT false NOT NULL,
    extra_metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    micro_batch_size integer,
    context_prefix_tokens integer DEFAULT 5 NOT NULL,
    context_suffix_tokens integer DEFAULT 3 NOT NULL
);


ALTER TABLE public.extraction_templates OWNER TO postgres;

--
-- Name: feature_activations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feature_activations (
    id bigint NOT NULL,
    feature_id character varying(255) NOT NULL,
    sample_index integer NOT NULL,
    max_activation double precision NOT NULL,
    tokens jsonb NOT NULL,
    activations jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    prefix_tokens json,
    prime_token character varying,
    suffix_tokens json,
    prime_activation_index integer
)
PARTITION BY RANGE (feature_id);


ALTER TABLE public.feature_activations OWNER TO postgres;

--
-- Name: feature_activations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.feature_activations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.feature_activations_id_seq OWNER TO postgres;

--
-- Name: feature_activations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.feature_activations_id_seq OWNED BY public.feature_activations.id;


--
-- Name: feature_activations_default; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feature_activations_default (
    id bigint DEFAULT nextval('public.feature_activations_id_seq'::regclass) NOT NULL,
    feature_id character varying(255) NOT NULL,
    sample_index integer NOT NULL,
    max_activation double precision NOT NULL,
    tokens jsonb NOT NULL,
    activations jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    prefix_tokens json,
    prime_token character varying,
    suffix_tokens json,
    prime_activation_index integer
);


ALTER TABLE public.feature_activations_default OWNER TO postgres;

--
-- Name: feature_activations_p00; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feature_activations_p00 (
    id bigint DEFAULT nextval('public.feature_activations_id_seq'::regclass) NOT NULL,
    feature_id character varying(255) NOT NULL,
    sample_index integer NOT NULL,
    max_activation double precision NOT NULL,
    tokens jsonb NOT NULL,
    activations jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    prefix_tokens json,
    prime_token character varying,
    suffix_tokens json,
    prime_activation_index integer
);


ALTER TABLE public.feature_activations_p00 OWNER TO postgres;

--
-- Name: feature_activations_p01; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feature_activations_p01 (
    id bigint DEFAULT nextval('public.feature_activations_id_seq'::regclass) NOT NULL,
    feature_id character varying(255) NOT NULL,
    sample_index integer NOT NULL,
    max_activation double precision NOT NULL,
    tokens jsonb NOT NULL,
    activations jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    prefix_tokens json,
    prime_token character varying,
    suffix_tokens json,
    prime_activation_index integer
);


ALTER TABLE public.feature_activations_p01 OWNER TO postgres;

--
-- Name: feature_activations_p02; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feature_activations_p02 (
    id bigint DEFAULT nextval('public.feature_activations_id_seq'::regclass) NOT NULL,
    feature_id character varying(255) NOT NULL,
    sample_index integer NOT NULL,
    max_activation double precision NOT NULL,
    tokens jsonb NOT NULL,
    activations jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    prefix_tokens json,
    prime_token character varying,
    suffix_tokens json,
    prime_activation_index integer
);


ALTER TABLE public.feature_activations_p02 OWNER TO postgres;

--
-- Name: feature_activations_p03; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feature_activations_p03 (
    id bigint DEFAULT nextval('public.feature_activations_id_seq'::regclass) NOT NULL,
    feature_id character varying(255) NOT NULL,
    sample_index integer NOT NULL,
    max_activation double precision NOT NULL,
    tokens jsonb NOT NULL,
    activations jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    prefix_tokens json,
    prime_token character varying,
    suffix_tokens json,
    prime_activation_index integer
);


ALTER TABLE public.feature_activations_p03 OWNER TO postgres;

--
-- Name: feature_activations_p04; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feature_activations_p04 (
    id bigint DEFAULT nextval('public.feature_activations_id_seq'::regclass) NOT NULL,
    feature_id character varying(255) NOT NULL,
    sample_index integer NOT NULL,
    max_activation double precision NOT NULL,
    tokens jsonb NOT NULL,
    activations jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    prefix_tokens json,
    prime_token character varying,
    suffix_tokens json,
    prime_activation_index integer
);


ALTER TABLE public.feature_activations_p04 OWNER TO postgres;

--
-- Name: feature_activations_p05; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feature_activations_p05 (
    id bigint DEFAULT nextval('public.feature_activations_id_seq'::regclass) NOT NULL,
    feature_id character varying(255) NOT NULL,
    sample_index integer NOT NULL,
    max_activation double precision NOT NULL,
    tokens jsonb NOT NULL,
    activations jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    prefix_tokens json,
    prime_token character varying,
    suffix_tokens json,
    prime_activation_index integer
);


ALTER TABLE public.feature_activations_p05 OWNER TO postgres;

--
-- Name: feature_activations_p06; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feature_activations_p06 (
    id bigint DEFAULT nextval('public.feature_activations_id_seq'::regclass) NOT NULL,
    feature_id character varying(255) NOT NULL,
    sample_index integer NOT NULL,
    max_activation double precision NOT NULL,
    tokens jsonb NOT NULL,
    activations jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    prefix_tokens json,
    prime_token character varying,
    suffix_tokens json,
    prime_activation_index integer
);


ALTER TABLE public.feature_activations_p06 OWNER TO postgres;

--
-- Name: feature_activations_p07; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feature_activations_p07 (
    id bigint DEFAULT nextval('public.feature_activations_id_seq'::regclass) NOT NULL,
    feature_id character varying(255) NOT NULL,
    sample_index integer NOT NULL,
    max_activation double precision NOT NULL,
    tokens jsonb NOT NULL,
    activations jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    prefix_tokens json,
    prime_token character varying,
    suffix_tokens json,
    prime_activation_index integer
);


ALTER TABLE public.feature_activations_p07 OWNER TO postgres;

--
-- Name: feature_activations_p08; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feature_activations_p08 (
    id bigint DEFAULT nextval('public.feature_activations_id_seq'::regclass) NOT NULL,
    feature_id character varying(255) NOT NULL,
    sample_index integer NOT NULL,
    max_activation double precision NOT NULL,
    tokens jsonb NOT NULL,
    activations jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    prefix_tokens json,
    prime_token character varying,
    suffix_tokens json,
    prime_activation_index integer
);


ALTER TABLE public.feature_activations_p08 OWNER TO postgres;

--
-- Name: feature_activations_p09; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feature_activations_p09 (
    id bigint DEFAULT nextval('public.feature_activations_id_seq'::regclass) NOT NULL,
    feature_id character varying(255) NOT NULL,
    sample_index integer NOT NULL,
    max_activation double precision NOT NULL,
    tokens jsonb NOT NULL,
    activations jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    prefix_tokens json,
    prime_token character varying,
    suffix_tokens json,
    prime_activation_index integer
);


ALTER TABLE public.feature_activations_p09 OWNER TO postgres;

--
-- Name: feature_activations_p10; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feature_activations_p10 (
    id bigint DEFAULT nextval('public.feature_activations_id_seq'::regclass) NOT NULL,
    feature_id character varying(255) NOT NULL,
    sample_index integer NOT NULL,
    max_activation double precision NOT NULL,
    tokens jsonb NOT NULL,
    activations jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    prefix_tokens json,
    prime_token character varying,
    suffix_tokens json,
    prime_activation_index integer
);


ALTER TABLE public.feature_activations_p10 OWNER TO postgres;

--
-- Name: feature_activations_p11; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feature_activations_p11 (
    id bigint DEFAULT nextval('public.feature_activations_id_seq'::regclass) NOT NULL,
    feature_id character varying(255) NOT NULL,
    sample_index integer NOT NULL,
    max_activation double precision NOT NULL,
    tokens jsonb NOT NULL,
    activations jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    prefix_tokens json,
    prime_token character varying,
    suffix_tokens json,
    prime_activation_index integer
);


ALTER TABLE public.feature_activations_p11 OWNER TO postgres;

--
-- Name: feature_activations_p12; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feature_activations_p12 (
    id bigint DEFAULT nextval('public.feature_activations_id_seq'::regclass) NOT NULL,
    feature_id character varying(255) NOT NULL,
    sample_index integer NOT NULL,
    max_activation double precision NOT NULL,
    tokens jsonb NOT NULL,
    activations jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    prefix_tokens json,
    prime_token character varying,
    suffix_tokens json,
    prime_activation_index integer
);


ALTER TABLE public.feature_activations_p12 OWNER TO postgres;

--
-- Name: feature_activations_p13; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feature_activations_p13 (
    id bigint DEFAULT nextval('public.feature_activations_id_seq'::regclass) NOT NULL,
    feature_id character varying(255) NOT NULL,
    sample_index integer NOT NULL,
    max_activation double precision NOT NULL,
    tokens jsonb NOT NULL,
    activations jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    prefix_tokens json,
    prime_token character varying,
    suffix_tokens json,
    prime_activation_index integer
);


ALTER TABLE public.feature_activations_p13 OWNER TO postgres;

--
-- Name: feature_activations_p14; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feature_activations_p14 (
    id bigint DEFAULT nextval('public.feature_activations_id_seq'::regclass) NOT NULL,
    feature_id character varying(255) NOT NULL,
    sample_index integer NOT NULL,
    max_activation double precision NOT NULL,
    tokens jsonb NOT NULL,
    activations jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    prefix_tokens json,
    prime_token character varying,
    suffix_tokens json,
    prime_activation_index integer
);


ALTER TABLE public.feature_activations_p14 OWNER TO postgres;

--
-- Name: feature_activations_p15; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feature_activations_p15 (
    id bigint DEFAULT nextval('public.feature_activations_id_seq'::regclass) NOT NULL,
    feature_id character varying(255) NOT NULL,
    sample_index integer NOT NULL,
    max_activation double precision NOT NULL,
    tokens jsonb NOT NULL,
    activations jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    prefix_tokens json,
    prime_token character varying,
    suffix_tokens json,
    prime_activation_index integer
);


ALTER TABLE public.feature_activations_p15 OWNER TO postgres;

--
-- Name: feature_analysis_cache; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feature_analysis_cache (
    id bigint NOT NULL,
    feature_id character varying(255) NOT NULL,
    analysis_type public.analysis_type_enum NOT NULL,
    result jsonb NOT NULL,
    computed_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


ALTER TABLE public.feature_analysis_cache OWNER TO postgres;

--
-- Name: COLUMN feature_analysis_cache.feature_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.feature_analysis_cache.feature_id IS 'Reference to feature';


--
-- Name: COLUMN feature_analysis_cache.analysis_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.feature_analysis_cache.analysis_type IS 'Type of analysis';


--
-- Name: COLUMN feature_analysis_cache.result; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.feature_analysis_cache.result IS 'Analysis result (structure depends on analysis_type)';


--
-- Name: COLUMN feature_analysis_cache.expires_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.feature_analysis_cache.expires_at IS 'Cache expiration (7 days from computed_at)';


--
-- Name: feature_analysis_cache_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.feature_analysis_cache_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.feature_analysis_cache_id_seq OWNER TO postgres;

--
-- Name: feature_analysis_cache_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.feature_analysis_cache_id_seq OWNED BY public.feature_analysis_cache.id;


--
-- Name: feature_dashboard_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feature_dashboard_data (
    id bigint NOT NULL,
    feature_id character varying(255) NOT NULL,
    logit_lens_data jsonb,
    histogram_data jsonb,
    top_tokens jsonb,
    computed_at timestamp with time zone DEFAULT now() NOT NULL,
    computation_version character varying(50)
);


ALTER TABLE public.feature_dashboard_data OWNER TO postgres;

--
-- Name: feature_dashboard_data_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.feature_dashboard_data_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.feature_dashboard_data_id_seq OWNER TO postgres;

--
-- Name: feature_dashboard_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.feature_dashboard_data_id_seq OWNED BY public.feature_dashboard_data.id;


--
-- Name: features; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.features (
    id character varying(255) NOT NULL,
    training_id character varying(255),
    extraction_job_id character varying(255) NOT NULL,
    neuron_index integer NOT NULL,
    name character varying(500) NOT NULL,
    description text,
    label_source public.label_source_enum DEFAULT 'auto'::public.label_source_enum NOT NULL,
    activation_frequency double precision NOT NULL,
    interpretability_score double precision NOT NULL,
    max_activation double precision NOT NULL,
    mean_activation double precision,
    is_favorite boolean DEFAULT false NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    labeling_job_id character varying(255),
    labeled_at timestamp with time zone,
    category character varying(255),
    example_tokens_summary jsonb,
    external_sae_id character varying(255),
    nlp_analysis jsonb,
    nlp_processed_at timestamp with time zone,
    CONSTRAINT check_feature_single_source CHECK ((((training_id IS NOT NULL) AND (external_sae_id IS NULL)) OR ((training_id IS NULL) AND (external_sae_id IS NOT NULL))))
);


ALTER TABLE public.features OWNER TO postgres;

--
-- Name: COLUMN features.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.features.id IS 'Feature ID (format: feat_{training_id}_{neuron_index})';


--
-- Name: COLUMN features.training_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.features.training_id IS 'Reference to training';


--
-- Name: COLUMN features.extraction_job_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.features.extraction_job_id IS 'Reference to extraction job';


--
-- Name: COLUMN features.neuron_index; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.features.neuron_index IS 'SAE neuron index (0 to d_sae-1)';


--
-- Name: COLUMN features.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.features.name IS 'Feature name/label (auto-generated or user-edited)';


--
-- Name: COLUMN features.description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.features.description IS 'Feature description';


--
-- Name: COLUMN features.label_source; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.features.label_source IS 'Label source: auto (heuristic) or user (edited)';


--
-- Name: COLUMN features.activation_frequency; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.features.activation_frequency IS 'Fraction of samples where feature activates (>0.01)';


--
-- Name: COLUMN features.interpretability_score; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.features.interpretability_score IS 'Interpretability score (0.0-1.0) based on consistency and sparsity';


--
-- Name: COLUMN features.max_activation; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.features.max_activation IS 'Maximum activation value across all samples';


--
-- Name: COLUMN features.mean_activation; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.features.mean_activation IS 'Mean activation value when active';


--
-- Name: COLUMN features.is_favorite; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.features.is_favorite IS 'User favorited flag';


--
-- Name: COLUMN features.notes; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.features.notes IS 'User notes about feature';


--
-- Name: labeling_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.labeling_jobs (
    id character varying(255) NOT NULL,
    extraction_job_id character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    progress double precision DEFAULT '0'::double precision NOT NULL,
    features_labeled integer DEFAULT 0 NOT NULL,
    total_features integer,
    labeling_method character varying(50) NOT NULL,
    openai_model character varying(100),
    openai_api_key character varying(500),
    local_model character varying(100),
    celery_task_id character varying(255),
    error_message text,
    statistics json,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    openai_compatible_endpoint character varying(500),
    openai_compatible_model character varying(100),
    prompt_template_id character varying(255),
    filter_special boolean DEFAULT true NOT NULL,
    filter_single_char boolean DEFAULT true NOT NULL,
    filter_punctuation boolean DEFAULT true NOT NULL,
    filter_numbers boolean DEFAULT true NOT NULL,
    filter_fragments boolean DEFAULT true NOT NULL,
    filter_stop_words boolean DEFAULT false NOT NULL,
    save_requests_for_testing boolean DEFAULT false NOT NULL,
    export_format character varying(20) DEFAULT 'both'::character varying NOT NULL,
    save_poor_quality_labels boolean DEFAULT false NOT NULL,
    poor_quality_sample_rate double precision DEFAULT '1'::double precision NOT NULL,
    save_requests_sample_rate double precision DEFAULT '1'::double precision NOT NULL
);


ALTER TABLE public.labeling_jobs OWNER TO postgres;

--
-- Name: labeling_prompt_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.labeling_prompt_templates (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    system_message text NOT NULL,
    user_prompt_template text NOT NULL,
    temperature double precision DEFAULT '0.3'::double precision NOT NULL,
    max_tokens integer DEFAULT 50 NOT NULL,
    top_p double precision DEFAULT '0.9'::double precision NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    created_by character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    template_type character varying(50) DEFAULT 'legacy'::character varying NOT NULL,
    max_examples integer DEFAULT 10 NOT NULL,
    include_prefix boolean DEFAULT true NOT NULL,
    include_suffix boolean DEFAULT true NOT NULL,
    prime_token_marker character varying(20) DEFAULT '<<>>'::character varying NOT NULL,
    include_logit_effects boolean DEFAULT false NOT NULL,
    top_promoted_tokens_count integer,
    top_suppressed_tokens_count integer,
    is_detection_template boolean DEFAULT false NOT NULL,
    include_negative_examples boolean DEFAULT true NOT NULL,
    num_negative_examples integer
);


ALTER TABLE public.labeling_prompt_templates OWNER TO postgres;

--
-- Name: models; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.models (
    id character varying(255) NOT NULL,
    name character varying(500) NOT NULL,
    repo_id character varying(255),
    architecture character varying(100) NOT NULL,
    params_count bigint NOT NULL,
    quantization public.quantizationformat NOT NULL,
    status public.modelstatus NOT NULL,
    progress double precision,
    error_message text,
    file_path character varying(1000),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    quantized_path character varying(1000),
    architecture_config jsonb,
    memory_required_bytes bigint,
    disk_size_bytes bigint
);


ALTER TABLE public.models OWNER TO postgres;

--
-- Name: COLUMN models.repo_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.models.repo_id IS 'HuggingFace repository ID';


--
-- Name: neuronpedia_export_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.neuronpedia_export_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sae_id character varying(255) NOT NULL,
    source_type character varying(50) NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    status public.export_status DEFAULT 'pending'::public.export_status NOT NULL,
    progress double precision DEFAULT '0'::double precision NOT NULL,
    current_stage character varying(100),
    output_path text,
    file_size_bytes bigint,
    feature_count integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    error_message text,
    error_details jsonb
);


ALTER TABLE public.neuronpedia_export_jobs OWNER TO postgres;

--
-- Name: prompt_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.prompt_templates (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    prompts jsonb NOT NULL,
    is_favorite boolean DEFAULT false NOT NULL,
    tags jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.prompt_templates OWNER TO postgres;

--
-- Name: COLUMN prompt_templates.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.prompt_templates.id IS 'Unique template identifier';


--
-- Name: COLUMN prompt_templates.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.prompt_templates.name IS 'Template name';


--
-- Name: COLUMN prompt_templates.description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.prompt_templates.description IS 'Template description';


--
-- Name: COLUMN prompt_templates.prompts; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.prompt_templates.prompts IS 'Array of prompt strings';


--
-- Name: COLUMN prompt_templates.is_favorite; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.prompt_templates.is_favorite IS 'Whether this template is marked as favorite';


--
-- Name: COLUMN prompt_templates.tags; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.prompt_templates.tags IS 'Array of tag strings for organization';


--
-- Name: COLUMN prompt_templates.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.prompt_templates.created_at IS 'Record creation timestamp';


--
-- Name: COLUMN prompt_templates.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.prompt_templates.updated_at IS 'Record last update timestamp';


--
-- Name: task_queue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_queue (
    id character varying NOT NULL,
    task_id character varying,
    task_type character varying NOT NULL,
    entity_id character varying NOT NULL,
    entity_type character varying NOT NULL,
    status character varying NOT NULL,
    progress double precision,
    error_message text,
    retry_params json,
    retry_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.task_queue OWNER TO postgres;

--
-- Name: training_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.training_metrics (
    id bigint NOT NULL,
    training_id character varying(255) NOT NULL,
    step integer NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    loss double precision NOT NULL,
    loss_reconstructed double precision,
    loss_zero double precision,
    l0_sparsity double precision,
    l1_sparsity double precision,
    dead_neurons integer,
    learning_rate double precision,
    grad_norm double precision,
    gpu_memory_used_mb double precision,
    samples_per_second double precision,
    layer_idx integer,
    fvu double precision
);


ALTER TABLE public.training_metrics OWNER TO postgres;

--
-- Name: COLUMN training_metrics.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_metrics.id IS 'Metric record ID';


--
-- Name: COLUMN training_metrics.training_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_metrics.training_id IS 'Reference to training job';


--
-- Name: COLUMN training_metrics.step; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_metrics.step IS 'Training step number';


--
-- Name: COLUMN training_metrics."timestamp"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_metrics."timestamp" IS 'Metric collection timestamp';


--
-- Name: COLUMN training_metrics.loss; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_metrics.loss IS 'Total reconstruction loss';


--
-- Name: COLUMN training_metrics.loss_reconstructed; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_metrics.loss_reconstructed IS 'Reconstruction component of loss';


--
-- Name: COLUMN training_metrics.loss_zero; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_metrics.loss_zero IS 'Zero ablation loss';


--
-- Name: COLUMN training_metrics.l0_sparsity; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_metrics.l0_sparsity IS 'L0 sparsity (fraction of active features)';


--
-- Name: COLUMN training_metrics.l1_sparsity; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_metrics.l1_sparsity IS 'L1 sparsity penalty';


--
-- Name: COLUMN training_metrics.dead_neurons; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_metrics.dead_neurons IS 'Count of dead neurons at this step';


--
-- Name: COLUMN training_metrics.learning_rate; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_metrics.learning_rate IS 'Learning rate at this step';


--
-- Name: COLUMN training_metrics.grad_norm; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_metrics.grad_norm IS 'Gradient norm';


--
-- Name: COLUMN training_metrics.gpu_memory_used_mb; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_metrics.gpu_memory_used_mb IS 'GPU memory used in MB';


--
-- Name: COLUMN training_metrics.samples_per_second; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_metrics.samples_per_second IS 'Training throughput';


--
-- Name: COLUMN training_metrics.layer_idx; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_metrics.layer_idx IS 'Layer index (NULL for aggregated metrics)';


--
-- Name: COLUMN training_metrics.fvu; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_metrics.fvu IS 'Fraction of Variance Unexplained (var_residuals / var_original)';


--
-- Name: training_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.training_metrics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.training_metrics_id_seq OWNER TO postgres;

--
-- Name: training_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.training_metrics_id_seq OWNED BY public.training_metrics.id;


--
-- Name: training_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.training_templates (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    model_id character varying(255),
    dataset_id character varying(255),
    encoder_type character varying(20) NOT NULL,
    hyperparameters jsonb NOT NULL,
    is_favorite boolean DEFAULT false NOT NULL,
    extra_metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_training_templates_encoder_type CHECK (((encoder_type)::text = ANY ((ARRAY['standard'::character varying, 'skip'::character varying, 'transcoder'::character varying, 'jumprelu'::character varying])::text[])))
);


ALTER TABLE public.training_templates OWNER TO postgres;

--
-- Name: COLUMN training_templates.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_templates.id IS 'Unique template identifier';


--
-- Name: COLUMN training_templates.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_templates.name IS 'Template name';


--
-- Name: COLUMN training_templates.description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_templates.description IS 'Template description';


--
-- Name: COLUMN training_templates.model_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_templates.model_id IS 'Optional reference to specific model';


--
-- Name: COLUMN training_templates.dataset_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_templates.dataset_id IS 'Optional reference to specific dataset (no FK due to type mismatch)';


--
-- Name: COLUMN training_templates.encoder_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_templates.encoder_type IS 'SAE architecture type (standard/skip/transcoder)';


--
-- Name: COLUMN training_templates.hyperparameters; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_templates.hyperparameters IS 'Complete training hyperparameters';


--
-- Name: COLUMN training_templates.is_favorite; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_templates.is_favorite IS 'Whether this template is marked as favorite';


--
-- Name: COLUMN training_templates.extra_metadata; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_templates.extra_metadata IS 'Additional metadata';


--
-- Name: COLUMN training_templates.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_templates.created_at IS 'Record creation timestamp';


--
-- Name: COLUMN training_templates.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.training_templates.updated_at IS 'Record last update timestamp';


--
-- Name: trainings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trainings (
    id character varying(255) NOT NULL,
    model_id character varying(255) NOT NULL,
    dataset_id character varying(255) NOT NULL,
    extraction_id character varying(255),
    status character varying(50) NOT NULL,
    progress double precision NOT NULL,
    current_step integer NOT NULL,
    total_steps integer NOT NULL,
    hyperparameters jsonb NOT NULL,
    current_loss double precision,
    current_l0_sparsity double precision,
    current_dead_neurons integer,
    current_learning_rate double precision,
    error_message text,
    error_traceback text,
    celery_task_id character varying(255),
    checkpoint_dir character varying(1000),
    logs_path character varying(1000),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone
);


ALTER TABLE public.trainings OWNER TO postgres;

--
-- Name: COLUMN trainings.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.trainings.id IS 'Training job ID (format: train_{uuid})';


--
-- Name: COLUMN trainings.model_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.trainings.model_id IS 'Reference to base model';


--
-- Name: COLUMN trainings.dataset_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.trainings.dataset_id IS 'Reference to training dataset (no FK due to type mismatch)';


--
-- Name: COLUMN trainings.extraction_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.trainings.extraction_id IS 'Reference to activation extraction used for training';


--
-- Name: COLUMN trainings.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.trainings.status IS 'Current training status';


--
-- Name: COLUMN trainings.progress; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.trainings.progress IS 'Training progress (0-100)';


--
-- Name: COLUMN trainings.current_step; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.trainings.current_step IS 'Current training step';


--
-- Name: COLUMN trainings.total_steps; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.trainings.total_steps IS 'Total planned training steps';


--
-- Name: COLUMN trainings.hyperparameters; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.trainings.hyperparameters IS 'Training hyperparameters';


--
-- Name: COLUMN trainings.current_loss; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.trainings.current_loss IS 'Current reconstruction loss';


--
-- Name: COLUMN trainings.current_l0_sparsity; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.trainings.current_l0_sparsity IS 'Current L0 sparsity (active features)';


--
-- Name: COLUMN trainings.current_dead_neurons; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.trainings.current_dead_neurons IS 'Current count of dead neurons';


--
-- Name: COLUMN trainings.current_learning_rate; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.trainings.current_learning_rate IS 'Current learning rate';


--
-- Name: COLUMN trainings.error_message; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.trainings.error_message IS 'Error message if status is failed';


--
-- Name: COLUMN trainings.error_traceback; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.trainings.error_traceback IS 'Full error traceback for debugging';


--
-- Name: COLUMN trainings.celery_task_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.trainings.celery_task_id IS 'Celery task ID for this training job';


--
-- Name: COLUMN trainings.checkpoint_dir; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.trainings.checkpoint_dir IS 'Directory containing checkpoints';


--
-- Name: COLUMN trainings.logs_path; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.trainings.logs_path IS 'Path to training logs file';


--
-- Name: COLUMN trainings.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.trainings.created_at IS 'Job creation timestamp';


--
-- Name: COLUMN trainings.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.trainings.updated_at IS 'Last update timestamp';


--
-- Name: COLUMN trainings.started_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.trainings.started_at IS 'Training start timestamp';


--
-- Name: COLUMN trainings.completed_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.trainings.completed_at IS 'Training completion timestamp';


--
-- Name: feature_activations_default; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations ATTACH PARTITION public.feature_activations_default DEFAULT;


--
-- Name: feature_activations_p00; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations ATTACH PARTITION public.feature_activations_p00 FOR VALUES FROM ('feat_00000') TO ('feat_01000');


--
-- Name: feature_activations_p01; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations ATTACH PARTITION public.feature_activations_p01 FOR VALUES FROM ('feat_01000') TO ('feat_02000');


--
-- Name: feature_activations_p02; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations ATTACH PARTITION public.feature_activations_p02 FOR VALUES FROM ('feat_02000') TO ('feat_03000');


--
-- Name: feature_activations_p03; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations ATTACH PARTITION public.feature_activations_p03 FOR VALUES FROM ('feat_03000') TO ('feat_04000');


--
-- Name: feature_activations_p04; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations ATTACH PARTITION public.feature_activations_p04 FOR VALUES FROM ('feat_04000') TO ('feat_05000');


--
-- Name: feature_activations_p05; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations ATTACH PARTITION public.feature_activations_p05 FOR VALUES FROM ('feat_05000') TO ('feat_06000');


--
-- Name: feature_activations_p06; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations ATTACH PARTITION public.feature_activations_p06 FOR VALUES FROM ('feat_06000') TO ('feat_07000');


--
-- Name: feature_activations_p07; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations ATTACH PARTITION public.feature_activations_p07 FOR VALUES FROM ('feat_07000') TO ('feat_08000');


--
-- Name: feature_activations_p08; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations ATTACH PARTITION public.feature_activations_p08 FOR VALUES FROM ('feat_08000') TO ('feat_09000');


--
-- Name: feature_activations_p09; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations ATTACH PARTITION public.feature_activations_p09 FOR VALUES FROM ('feat_09000') TO ('feat_10000');


--
-- Name: feature_activations_p10; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations ATTACH PARTITION public.feature_activations_p10 FOR VALUES FROM ('feat_10000') TO ('feat_11000');


--
-- Name: feature_activations_p11; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations ATTACH PARTITION public.feature_activations_p11 FOR VALUES FROM ('feat_11000') TO ('feat_12000');


--
-- Name: feature_activations_p12; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations ATTACH PARTITION public.feature_activations_p12 FOR VALUES FROM ('feat_12000') TO ('feat_13000');


--
-- Name: feature_activations_p13; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations ATTACH PARTITION public.feature_activations_p13 FOR VALUES FROM ('feat_13000') TO ('feat_14000');


--
-- Name: feature_activations_p14; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations ATTACH PARTITION public.feature_activations_p14 FOR VALUES FROM ('feat_14000') TO ('feat_15000');


--
-- Name: feature_activations_p15; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations ATTACH PARTITION public.feature_activations_p15 FOR VALUES FROM ('feat_15000') TO ('feat_16000');


--
-- Name: feature_activations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations ALTER COLUMN id SET DEFAULT nextval('public.feature_activations_id_seq'::regclass);


--
-- Name: feature_analysis_cache id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_analysis_cache ALTER COLUMN id SET DEFAULT nextval('public.feature_analysis_cache_id_seq'::regclass);


--
-- Name: feature_dashboard_data id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_dashboard_data ALTER COLUMN id SET DEFAULT nextval('public.feature_dashboard_data_id_seq'::regclass);


--
-- Name: training_metrics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_metrics ALTER COLUMN id SET DEFAULT nextval('public.training_metrics_id_seq'::regclass);


--
-- Data for Name: activation_extractions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activation_extractions (id, model_id, dataset_id, celery_task_id, layer_indices, hook_types, max_samples, batch_size, status, progress, samples_processed, error_message, output_path, metadata_path, statistics, saved_files, created_at, updated_at, completed_at, retry_count, original_extraction_id, retry_reason, auto_retried, error_type, micro_batch_size) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
7d3539aaf247
\.


--
-- Data for Name: checkpoints; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.checkpoints (id, training_id, step, loss, l0_sparsity, storage_path, file_size_bytes, is_best, extra_metadata, created_at) FROM stdin;
\.


--
-- Data for Name: dataset_tokenizations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dataset_tokenizations (id, dataset_id, model_id, tokenized_path, tokenizer_repo_id, vocab_size, num_tokens, avg_seq_length, status, progress, error_message, celery_task_id, created_at, updated_at, completed_at, remove_all_punctuation, custom_filter_chars) FROM stdin;
\.


--
-- Data for Name: datasets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.datasets (id, name, source, hf_repo_id, status, progress, error_message, raw_path, num_samples, size_bytes, metadata, created_at, updated_at, tokenization_filter_enabled, tokenization_filter_mode, tokenization_junk_ratio_threshold) FROM stdin;
ebe8f940-9eee-401b-bd59-9457ea15e190	ola13_small-the_pile	huggingface	ola13/small-the_pile	READY	\N	\N	/home/x-sean/app/miStudio/backend/data/datasets/ola13_small-the_pile	100000	1376516599	{}	2025-12-18 02:43:53.519416+00	2025-12-18 02:43:53.519416+00	f	conservative	0.7
d6ac2b3a-dc6f-40d9-85f7-26691ac7a104	vietgpt_openwebtext_en	huggingface	vietgpt/openwebtext_en	READY	\N	\N	/home/x-sean/app/miStudio/backend/data/datasets/vietgpt_openwebtext_en	8013769	120144562115	{}	2025-12-18 02:43:53.519416+00	2025-12-18 02:43:53.519416+00	f	conservative	0.7
3c4b05be-577b-4fb3-9004-5de01ec50d05	ola13_small-the_pile-dedup	huggingface	ola13/small-the_pile-dedup	READY	\N	\N	/home/x-sean/app/miStudio/backend/data/datasets/ola13_small-the_pile-dedup	100000	710796528	{}	2025-12-18 03:51:17.129886+00	2025-12-18 03:51:17.129886+00	f	conservative	0.7
\.


--
-- Data for Name: external_saes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.external_saes (id, name, description, source, status, hf_repo_id, hf_filepath, hf_revision, training_id, model_name, model_id, layer, n_features, d_model, architecture, format, local_path, file_size_bytes, progress, error_message, sae_metadata, created_at, updated_at, downloaded_at) FROM stdin;
7923525b9fc6	google/gemma-2-2b Layer 20 (18432 features)	\N	local	ready	\N	\N	\N	\N	google/gemma-2-2b	\N	20	18432	2304	jumprelu	community_standard	/home/x-sean/app/miStudio/backend/data/saes/sae_7923525b9fc6	\N	0	\N	{"lr": 0.0001, "d_in": 2304, "d_sae": 18432, "dtype": "torch.float32", "device": "cpu", "hook_point": "blocks.20.hook_resid_post", "model_name": "google/gemma-2-2b", "architecture": "jumprelu", "context_size": 128, "dataset_path": null, "extra_metadata": {"bandwidth": 0.001, "warmup_steps": 5000, "weight_decay": 0.01, "sparsity_coeff": 0.0003, "top_k_sparsity": null, "initial_threshold": 0.0001, "normalize_decoder": true, "ghost_gradient_penalty": null}, "l1_coefficient": 0.000021977, "expansion_factor": 8.0, "hook_point_layer": 20, "train_batch_size": 128, "activation_fn_str": "jumprelu", "apply_b_dec_to_input": false, "mistudio_training_id": "train_0c29645f", "hook_point_head_index": null, "normalize_activations": "constant_norm_rescale", "total_training_tokens": 64000000, "mistudio_checkpoint_step": 500000, "finetuning_scaling_factor": false}	2025-12-18 02:43:53.574683+00	2025-12-18 02:43:53.574683+00	\N
e4c51f8e2c1f	gemma-2-2b Layer 18 (8192 features)	\N	local	ready	\N	\N	\N	\N	gemma-2-2b	\N	18	8192	2048	standard	community_standard	/home/x-sean/app/miStudio/backend/data/saes/sae_e4c51f8e2c1f	\N	0	\N	{}	2025-12-18 02:43:53.574683+00	2025-12-18 02:43:53.574683+00	\N
ca21ffb42ac9	gemma-2-2b Layer 20 (65536 features)	\N	local	ready	\N	\N	\N	\N	gemma-2-2b	\N	20	65536	2304	standard	community_standard	/home/x-sean/app/miStudio/backend/data/saes/sae_ca21ffb42ac9	\N	0	\N	{}	2025-12-18 02:43:53.574683+00	2025-12-18 02:43:53.574683+00	\N
765eed0a8e33	gemma-2-2b Layer 20 (16384 features)	\N	local	ready	\N	\N	\N	\N	gemma-2-2b	\N	20	16384	2304	standard	community_standard	/home/x-sean/app/miStudio/backend/data/saes/sae_765eed0a8e33	\N	0	\N	{}	2025-12-18 02:43:53.574683+00	2025-12-18 02:43:53.574683+00	\N
838eb9f70a46	gemma-2-2b Layer 20 (FAILED)	\N	local	FAILED	\N	\N	\N	\N	unknown	\N	0	0	0	standard	community_standard	/home/x-sean/app/miStudio/backend/data/saes/sae_838eb9f70a46	\N	0	Incomplete download - only metadata files exist	{}	2025-12-18 02:43:53.574683+00	2025-12-18 02:43:53.574683+00	\N
9ff8327683eb	gemma-2-2b Layer 20 (16384 features)	\N	local	ready	\N	\N	\N	\N	gemma-2-2b	\N	20	16384	2304	standard	community_standard	/home/x-sean/app/miStudio/backend/data/saes/sae_9ff8327683eb	\N	0	\N	{}	2025-12-18 02:43:53.574683+00	2025-12-18 02:43:53.574683+00	\N
3a89d5eea5fe	gemma-2-2b Layer 18 (8192 features)	\N	local	ready	\N	\N	\N	\N	gemma-2-2b	\N	18	8192	2048	standard	community_standard	/home/x-sean/app/miStudio/backend/data/saes/sae_3a89d5eea5fe	\N	0	\N	{}	2025-12-18 02:43:53.574683+00	2025-12-18 02:43:53.574683+00	\N
654bf83a73f9	phi-4-mini-instruct Layer 20 (24576 features)	\N	local	ready	\N	\N	\N	train_54572d66	phi-4-mini-instruct	\N	20	24576	3072	jumprelu	community_standard	/home/x-sean/app/miStudio/backend/data/saes/sae_654bf83a73f9	\N	0	\N	{"lr": 0.0001, "d_in": 3072, "d_sae": 24576, "dtype": "torch.float32", "device": "cpu", "hook_name": "blocks.20.hook_resid_post", "hook_point": "blocks.20.hook_resid_post", "model_name": "phi-4-mini-instruct", "prepend_bos": true, "architecture": "jumprelu", "context_size": 128, "dataset_path": null, "extra_metadata": {"bandwidth": 0.001, "warmup_steps": 2000, "weight_decay": 0.0, "hf_model_name": "microsoft/Phi-4-mini-instruct", "sparsity_coeff": 0.03, "top_k_sparsity": null, "initial_threshold": 0.025, "normalize_decoder": true, "ghost_gradient_penalty": null}, "l1_coefficient": 0.05, "expansion_factor": 8.0, "hook_point_layer": 20, "train_batch_size": 4096, "activation_fn_str": "jumprelu", "apply_b_dec_to_input": false, "mistudio_training_id": "train_54572d66", "hook_point_head_index": null, "normalize_activations": "constant_norm_rescale", "total_training_tokens": 409600000, "mistudio_checkpoint_step": 100000, "finetuning_scaling_factor": false}	2025-12-18 02:43:53.574683+00	2025-12-18 02:43:53.574683+00	\N
15b483127b52	phi-4-mini-instruct Layer 20 (24576 features)	\N	local	ready	\N	\N	\N	train_7a940e33	phi-4-mini-instruct	\N	20	24576	3072	jumprelu	community_standard	/home/x-sean/app/miStudio/backend/data/saes/sae_15b483127b52	\N	0	\N	{"lr": 0.0001, "d_in": 3072, "d_sae": 24576, "dtype": "torch.float32", "device": "cpu", "hook_name": "blocks.20.hook_resid_post", "hook_point": "blocks.20.hook_resid_post", "model_name": "phi-4-mini-instruct", "prepend_bos": true, "architecture": "jumprelu", "context_size": 128, "dataset_path": null, "extra_metadata": {"bandwidth": 0.001, "warmup_steps": 5000, "weight_decay": 0.0, "hf_model_name": "microsoft/Phi-4-mini-instruct", "sparsity_coeff": 0.008, "top_k_sparsity": null, "initial_threshold": 0.01, "normalize_decoder": true, "ghost_gradient_penalty": null}, "l1_coefficient": 0.015, "expansion_factor": 8.0, "hook_point_layer": 20, "train_batch_size": 2048, "activation_fn_str": "jumprelu", "apply_b_dec_to_input": false, "mistudio_training_id": "train_7a940e33", "hook_point_head_index": null, "normalize_activations": "constant_norm_rescale", "total_training_tokens": 1024000000, "mistudio_checkpoint_step": 500000, "finetuning_scaling_factor": false}	2025-12-18 02:43:53.574683+00	2025-12-18 02:43:53.574683+00	\N
db2d9c2d0c16	phi-4-mini-instruct Layer 20 (24576 features)	\N	local	ready	\N	\N	\N	train_35e19d0c	phi-4-mini-instruct	\N	20	24576	3072	jumprelu	community_standard	/home/x-sean/app/miStudio/backend/data/saes/sae_db2d9c2d0c16	\N	0	\N	{"lr": 0.0001, "d_in": 3072, "d_sae": 24576, "dtype": "torch.float32", "device": "cpu", "hook_name": "blocks.20.hook_resid_post", "hook_point": "blocks.20.hook_resid_post", "model_name": "phi-4-mini-instruct", "prepend_bos": true, "architecture": "jumprelu", "context_size": 128, "dataset_path": null, "extra_metadata": {"bandwidth": 0.001, "warmup_steps": 2000, "weight_decay": 0.0, "hf_model_name": "microsoft/Phi-4-mini-instruct", "sparsity_coeff": 0.002, "top_k_sparsity": null, "initial_threshold": 0.01, "normalize_decoder": true, "ghost_gradient_penalty": null}, "l1_coefficient": 0.005, "expansion_factor": 8.0, "hook_point_layer": 20, "train_batch_size": 2048, "activation_fn_str": "jumprelu", "apply_b_dec_to_input": false, "mistudio_training_id": "train_35e19d0c", "hook_point_head_index": null, "normalize_activations": "constant_norm_rescale", "total_training_tokens": 204800000, "mistudio_checkpoint_step": 100000, "finetuning_scaling_factor": false}	2025-12-18 02:43:53.574683+00	2025-12-18 02:43:53.574683+00	\N
\.


--
-- Data for Name: extraction_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.extraction_jobs (id, training_id, celery_task_id, config, status, progress, features_extracted, total_features, error_message, statistics, created_at, updated_at, completed_at, filter_special, filter_single_char, filter_punctuation, filter_numbers, filter_fragments, filter_stop_words, context_prefix_tokens, context_suffix_tokens, external_sae_id, nlp_status, nlp_progress, nlp_processed_count, nlp_error_message) FROM stdin;
\.


--
-- Data for Name: extraction_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.extraction_templates (id, name, description, layer_indices, hook_types, max_samples, batch_size, top_k_examples, is_favorite, extra_metadata, created_at, updated_at, micro_batch_size, context_prefix_tokens, context_suffix_tokens) FROM stdin;
\.


--
-- Data for Name: feature_activations_default; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feature_activations_default (id, feature_id, sample_index, max_activation, tokens, activations, created_at, prefix_tokens, prime_token, suffix_tokens, prime_activation_index) FROM stdin;
\.


--
-- Data for Name: feature_activations_p00; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feature_activations_p00 (id, feature_id, sample_index, max_activation, tokens, activations, created_at, prefix_tokens, prime_token, suffix_tokens, prime_activation_index) FROM stdin;
\.


--
-- Data for Name: feature_activations_p01; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feature_activations_p01 (id, feature_id, sample_index, max_activation, tokens, activations, created_at, prefix_tokens, prime_token, suffix_tokens, prime_activation_index) FROM stdin;
\.


--
-- Data for Name: feature_activations_p02; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feature_activations_p02 (id, feature_id, sample_index, max_activation, tokens, activations, created_at, prefix_tokens, prime_token, suffix_tokens, prime_activation_index) FROM stdin;
\.


--
-- Data for Name: feature_activations_p03; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feature_activations_p03 (id, feature_id, sample_index, max_activation, tokens, activations, created_at, prefix_tokens, prime_token, suffix_tokens, prime_activation_index) FROM stdin;
\.


--
-- Data for Name: feature_activations_p04; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feature_activations_p04 (id, feature_id, sample_index, max_activation, tokens, activations, created_at, prefix_tokens, prime_token, suffix_tokens, prime_activation_index) FROM stdin;
\.


--
-- Data for Name: feature_activations_p05; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feature_activations_p05 (id, feature_id, sample_index, max_activation, tokens, activations, created_at, prefix_tokens, prime_token, suffix_tokens, prime_activation_index) FROM stdin;
\.


--
-- Data for Name: feature_activations_p06; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feature_activations_p06 (id, feature_id, sample_index, max_activation, tokens, activations, created_at, prefix_tokens, prime_token, suffix_tokens, prime_activation_index) FROM stdin;
\.


--
-- Data for Name: feature_activations_p07; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feature_activations_p07 (id, feature_id, sample_index, max_activation, tokens, activations, created_at, prefix_tokens, prime_token, suffix_tokens, prime_activation_index) FROM stdin;
\.


--
-- Data for Name: feature_activations_p08; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feature_activations_p08 (id, feature_id, sample_index, max_activation, tokens, activations, created_at, prefix_tokens, prime_token, suffix_tokens, prime_activation_index) FROM stdin;
\.


--
-- Data for Name: feature_activations_p09; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feature_activations_p09 (id, feature_id, sample_index, max_activation, tokens, activations, created_at, prefix_tokens, prime_token, suffix_tokens, prime_activation_index) FROM stdin;
\.


--
-- Data for Name: feature_activations_p10; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feature_activations_p10 (id, feature_id, sample_index, max_activation, tokens, activations, created_at, prefix_tokens, prime_token, suffix_tokens, prime_activation_index) FROM stdin;
\.


--
-- Data for Name: feature_activations_p11; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feature_activations_p11 (id, feature_id, sample_index, max_activation, tokens, activations, created_at, prefix_tokens, prime_token, suffix_tokens, prime_activation_index) FROM stdin;
\.


--
-- Data for Name: feature_activations_p12; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feature_activations_p12 (id, feature_id, sample_index, max_activation, tokens, activations, created_at, prefix_tokens, prime_token, suffix_tokens, prime_activation_index) FROM stdin;
\.


--
-- Data for Name: feature_activations_p13; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feature_activations_p13 (id, feature_id, sample_index, max_activation, tokens, activations, created_at, prefix_tokens, prime_token, suffix_tokens, prime_activation_index) FROM stdin;
\.


--
-- Data for Name: feature_activations_p14; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feature_activations_p14 (id, feature_id, sample_index, max_activation, tokens, activations, created_at, prefix_tokens, prime_token, suffix_tokens, prime_activation_index) FROM stdin;
\.


--
-- Data for Name: feature_activations_p15; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feature_activations_p15 (id, feature_id, sample_index, max_activation, tokens, activations, created_at, prefix_tokens, prime_token, suffix_tokens, prime_activation_index) FROM stdin;
\.


--
-- Data for Name: feature_analysis_cache; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feature_analysis_cache (id, feature_id, analysis_type, result, computed_at, expires_at) FROM stdin;
\.


--
-- Data for Name: feature_dashboard_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feature_dashboard_data (id, feature_id, logit_lens_data, histogram_data, top_tokens, computed_at, computation_version) FROM stdin;
\.


--
-- Data for Name: features; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.features (id, training_id, extraction_job_id, neuron_index, name, description, label_source, activation_frequency, interpretability_score, max_activation, mean_activation, is_favorite, notes, created_at, updated_at, labeling_job_id, labeled_at, category, example_tokens_summary, external_sae_id, nlp_analysis, nlp_processed_at) FROM stdin;
\.


--
-- Data for Name: labeling_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.labeling_jobs (id, extraction_job_id, status, progress, features_labeled, total_features, labeling_method, openai_model, openai_api_key, local_model, celery_task_id, error_message, statistics, created_at, updated_at, completed_at, openai_compatible_endpoint, openai_compatible_model, prompt_template_id, filter_special, filter_single_char, filter_punctuation, filter_numbers, filter_fragments, filter_stop_words, save_requests_for_testing, export_format, save_poor_quality_labels, poor_quality_sample_rate, save_requests_sample_rate) FROM stdin;
\.


--
-- Data for Name: labeling_prompt_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.labeling_prompt_templates (id, name, description, system_message, user_prompt_template, temperature, max_tokens, top_p, is_default, is_system, created_by, created_at, updated_at, template_type, max_examples, include_prefix, include_suffix, prime_token_marker, include_logit_effects, top_promoted_tokens_count, top_suppressed_tokens_count, is_detection_template, include_negative_examples, num_negative_examples) FROM stdin;
lpt_mistudio_internal	miStudio Internal - Full Context	Default labeling template using full-context activation examples with << >> markers around prime tokens. Generates concise semantic labels based on context windows. K=10 examples, ~520 tokens.	You analyze sparse autoencoder (SAE) features using full-context activation examples. Your ONLY job is to infer the single underlying conceptual meaning shared by the most strongly-activating tokens, taking into account both the highlighted token(s) and their surrounding context.\n\nYou are given short text spans. In each span, the token(s) where the feature activates most strongly are wrapped in double angle brackets, like <<this>>. Use all of the examples and their context to infer a single latent direction: a 1–2 word human concept that would be useful for steering model behavior.\n\nYou must NOT:\n- describe grammar, syntax, token types, or surface patterns\n- list the example tokens back\n- say "this feature detects words like..."\n- label the feature with only a grammatical category\n- describe frequency, morphology, or implementation details\n\nIf ANY coherent conceptual theme exists, use category 'semantic'.\nIf no coherent theme exists, use category 'system' and concept 'noise_feature'.\n\nYou must return ONLY a valid JSON object in this structure:\n{\n  "specific": "one_or_two_word_concept",\n  "category": "semantic_or_other",\n  "description": "One sentence describing the real conceptual meaning represented by this feature."\n}\n\nRules:\n- JSON only\n- No markdown\n- No notes\n- No code fences\n- No text before or after the JSON\n- Double quotes only	Analyze sparse autoencoder feature {feature_id}.\nYou are given some of the highest-activating examples for this feature. In each example, the main activating token(s) are wrapped in << >>. Use ALL of the examples, including their surrounding context, to infer the smallest semantic concept that explains why these tokens activate the same feature.\n\nEach example is formatted as:\n  Example N (activation: A_N): [prefix tokens] <<prime tokens>> [suffix tokens]\n\nExamples:\n\n{examples_block}\n\nInstructions:\n- Focus on what the highlighted tokens have in common when interpreted IN CONTEXT.\n- Ignore purely syntactic or tokenization details.\n- Prefer semantic, conceptual, or functional interpretations (e.g., 'legal_procedure', 'feminist_politics', 'scientific_uncertainty').\n- If you cannot find a coherent concept, treat this as a noise feature.\n\nReturn ONLY this exact JSON object:\n{\n  "specific": "concept",\n  "category": "semantic_or_other",\n  "description": "One sentence describing the conceptual meaning."\n}	0.2	256	0.9	t	t	\N	2025-12-18 02:36:30.764048+00	2025-12-18 02:36:30.764048+00	mistudio_context	10	t	t	<<>>	f	\N	\N	f	t	\N
lpt_eleutherai_detection	EleutherAI Detection - Explanation Scoring	Scoring template for evaluating feature explanations. Given an explanation, scores whether it is present (1) or absent (0) in test examples. Used for automated explanation quality assessment.	You evaluate whether text examples contain a specific sparse autoencoder feature.\nYou are given a feature explanation and a list of text examples.\n\nFor each example, you must decide whether the feature is present (1) or absent (0) based ONLY on the explanation.\n\nReturn ONLY a JSON array of 0s and 1s, one per example, in order.\nExample output: [0, 1, 1, 0, 0]	Feature explanation:\n{feature_explanation}\n\nDecide for each example whether it contains this feature.\n\nExamples:\n{examples_block}\n\nReturn ONLY a JSON array of 0s and 1s in this form:\n[0, 1, 1, 0, ...]	0	64	1	f	t	\N	2025-12-18 02:36:30.764048+00	2025-12-18 02:36:30.764048+00	eleutherai_detection	20	f	f		f	\N	\N	t	t	\N
lpt_anthropic_style	Anthropic Style - Evidence-Based Labeling	Enhanced labeling template using evidence-based reasoning with full-context examples, negative examples, and logit effects. Generates specific, high-quality labels grounded in quoted tokens. Default 25 examples (configurable 10-50).	You are a precise analyzer of sparse autoencoder (SAE) features. Your task is to identify the specific conceptual pattern that causes this feature to activate.\n\nYou will be given activation examples where the feature fires most strongly. In each example, tokens are marked with << >> to show where peak activation occurs. You may also be given negative examples (low-activation examples) to help you understand what the feature does NOT respond to. Additionally, you will see which tokens this feature promotes or suppresses in the model's predictions.\n\nYour analysis MUST follow this 5-step reasoning process:\n\n1. QUOTE SPECIFIC TOKENS: Identify the exact tokens (in quotes) that appear across multiple examples where the feature activates.\n\n2. IDENTIFY THE PATTERN: What specific semantic, syntactic, or structural property do these quoted tokens share? Be precise and concrete.\n\n3. TEST AGAINST CONTEXT: Do the surrounding tokens (prefix/suffix) support this interpretation? Quote any contradictory evidence.\n\n4. USE NEGATIVE EXAMPLES: If negative examples are provided, compare them to positive examples. What key differences distinguish high-activation from low-activation examples? Use this to narrow your hypothesis and avoid overgeneralization.\n\n5. VERIFY WITH LOGIT EFFECTS: Do the promoted/suppressed tokens align with your interpretation? If not, refine your hypothesis.\n\nCRITICAL RULES:\n- Base your label ONLY on evidence you can quote from the examples\n- NEVER use speculative language: "likely", "probably", "may", "seems", "appears", "suggests"\n- If examples show no clear pattern, use the label "mixed_activation_pattern"\n- Prefer specific concepts over vague ones (e.g., "past_tense_verbs" not "grammar")\n- Use negative examples to refine your label and make it more specific\n\nCategory definitions (choose EXACTLY ONE):\n- semantic: Word meaning or conceptual content (e.g., "emotions", "legal_terms")\n- syntactic: Grammatical structure or word class (e.g., "past_tense", "subordinate_clauses")\n- structural: Text formatting or document structure (e.g., "list_items", "quoted_text")\n- positional: Location in text (e.g., "sentence_start", "paragraph_end")\n- morphological: Word formation patterns (e.g., "prefix_un", "suffix_tion")\n- mixed: Clear pattern but spans multiple categories above\n\nReturn ONLY a JSON object in this format:\n{\n  "specific": "descriptive_label_up_to_60_chars",\n  "category": "one_of_six_categories_above",\n  "description": "One factual sentence describing what tokens this feature detects, quoting 2-3 example tokens."\n}\n\nOutput format requirements:\n- Pure JSON only (no markdown, no code fences, no commentary)\n- Double quotes only (no single quotes)\n- Must choose exactly one category from: semantic, syntactic, structural, positional, morphological, mixed	Analyze sparse autoencoder feature {feature_id}.\n\nYou are given the highest-activating examples for this feature. Each example shows:\n  Example N (activation: A_N): [prefix tokens] <<prime tokens>> [suffix tokens]\n\nThe << >> markers indicate where the feature activates most strongly.\n\n=== ACTIVATION EXAMPLES ===\n\n{examples_block}\n\n=== LOGIT EFFECTS ===\n\nWhen this feature activates, the model's output distribution shifts:\n- Promoted tokens (more likely): {top_promoted_tokens}\n- Suppressed tokens (less likely): {top_suppressed_tokens}\n\n=== YOUR TASK ===\n\nFollow the 5-step reasoning process from the system message:\n\n1. QUOTE: List the specific tokens (in quotes) where this feature activates across examples\n2. PATTERN: What precise property do these tokens share?\n3. CONTEXT: Does the surrounding text support this interpretation? Quote any contradictions.\n4. NEGATIVE EXAMPLES: If provided, what distinguishes high-activation from low-activation examples? Use this to narrow your label.\n5. LOGIT EFFECTS: Do promoted/suppressed tokens align with your hypothesis?\n\nRules:\n- Quote actual tokens from the examples above\n- No speculation (avoid: "likely", "probably", "may", "seems", "appears")\n- Use negative examples to avoid overgeneralization\n- If no clear pattern: use specific="mixed_activation_pattern" and category="mixed"\n- Choose EXACTLY ONE category: semantic, syntactic, structural, positional, morphological, mixed\n\nReturn ONLY this JSON object:\n{\n  "specific": "descriptive_label",\n  "category": "exact_category_name",\n  "description": "One sentence with 2-3 quoted example tokens showing what this feature detects."\n}	0.1	2000	0.9	f	t	\N	2025-12-18 02:36:30.764048+00	2025-12-18 02:36:30.107963+00	anthropic_logit	25	t	t	<<>>	t	10	10	f	t	\N
\.


--
-- Data for Name: models; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.models (id, name, repo_id, architecture, params_count, quantization, status, progress, error_message, file_path, created_at, updated_at, quantized_path, architecture_config, memory_required_bytes, disk_size_bytes) FROM stdin;
models--microsoft--Phi-4-mini-instruct	microsoft/Phi-4-mini-instruct	microsoft/Phi-4-mini-instruct	phi3	0	FP16	READY	\N	\N	/home/x-sean/app/miStudio/backend/data/models/raw/models--microsoft--Phi-4-mini-instruct	2025-12-18 02:43:53.54784+00	2025-12-18 02:43:53.54784+00	\N	\N	\N	\N
models--TinyLlama--TinyLlama_v1.1	TinyLlama/TinyLlama_v1.1	TinyLlama/TinyLlama_v1.1	llama	0	FP16	READY	\N	\N	/home/x-sean/app/miStudio/backend/data/models/raw/models--TinyLlama--TinyLlama_v1.1	2025-12-18 02:43:53.54784+00	2025-12-18 02:43:53.54784+00	\N	\N	\N	\N
\.


--
-- Data for Name: neuronpedia_export_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.neuronpedia_export_jobs (id, sae_id, source_type, config, status, progress, current_stage, output_path, file_size_bytes, feature_count, created_at, started_at, completed_at, error_message, error_details) FROM stdin;
\.


--
-- Data for Name: prompt_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.prompt_templates (id, name, description, prompts, is_favorite, tags, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_queue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_queue (id, task_id, task_type, entity_id, entity_type, status, progress, error_message, retry_params, retry_count, created_at, started_at, completed_at, updated_at) FROM stdin;
tq_60e21a43ca11	02813b7b-d909-4ddd-87c4-b218f5c7736c	download	7dacdcb5-9732-4b76-96b5-dfa94295050e	dataset	failed	0	Download failed: [Errno 13] Permission denied: '/home/x-sean/app/miStudio/backend/data/datasets/_home_x-sean_app_miStudio_backend_data_datasets_ola13___small-the_pile-dedup_default_0.0.0_e96a09621a478c7b108625347bf8cb71f7bd07f0.lock'	{"repo_id": "ola13/small-the_pile-dedup", "access_token": null, "split": null, "config": null}	0	2025-12-18 03:48:56.140085+00	\N	\N	2025-12-18 03:48:56.140085+00
tq_b82f658a92f0	fc2e42b8-82bf-4521-8a29-8672834fd5b3	download	m_92524c86	model	failed	0	Failed to load model google/gemma-2-2b: You are trying to access a gated repo.\nMake sure to have access to it at https://huggingface.co/google/gemma-2-2b.\n401 Client Error. (Request ID: Root=1-69437baa-1649eadb39187c6979d31405;b60b575d-aa75-4699-ba9c-b052df8b34f6)\n\nCannot access gated repo for url https://huggingface.co/google/gemma-2-2b/resolve/main/config.json.\nAccess to model google/gemma-2-2b is restricted. You must have access to it and be authenticated to access it. Please log in.	{"repo_id": "google/gemma-2-2b", "quantization": "FP16", "access_token": null, "trust_remote_code": false}	0	2025-12-18 03:57:30.147834+00	\N	\N	2025-12-18 03:57:30.147834+00
\.


--
-- Data for Name: training_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.training_metrics (id, training_id, step, "timestamp", loss, loss_reconstructed, loss_zero, l0_sparsity, l1_sparsity, dead_neurons, learning_rate, grad_norm, gpu_memory_used_mb, samples_per_second, layer_idx, fvu) FROM stdin;
\.


--
-- Data for Name: training_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.training_templates (id, name, description, model_id, dataset_id, encoder_type, hyperparameters, is_favorite, extra_metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: trainings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trainings (id, model_id, dataset_id, extraction_id, status, progress, current_step, total_steps, hyperparameters, current_loss, current_l0_sparsity, current_dead_neurons, current_learning_rate, error_message, error_traceback, celery_task_id, checkpoint_dir, logs_path, created_at, updated_at, started_at, completed_at) FROM stdin;
train_35e19d0c	models--microsoft--Phi-4-mini-instruct	ebe8f940-9eee-401b-bd59-9457ea15e190	\N	COMPLETED	100	100000	100000	{"d_sae": 24576, "layer": 20, "architecture": "jumprelu"}	\N	\N	\N	\N	\N	\N	\N	/home/x-sean/app/miStudio/backend/data/trainings/train_35e19d0c/checkpoints	\N	2025-12-09 00:00:00+00	2025-12-18 03:52:06.787488+00	\N	2025-12-09 10:26:50+00
train_54572d66	models--microsoft--Phi-4-mini-instruct	ebe8f940-9eee-401b-bd59-9457ea15e190	\N	COMPLETED	100	100000	100000	{"d_sae": 24576, "layer": 20, "architecture": "jumprelu"}	\N	\N	\N	\N	\N	\N	\N	/home/x-sean/app/miStudio/backend/data/trainings/train_54572d66/checkpoints	\N	2025-12-13 00:00:00+00	2025-12-18 03:53:07.258251+00	\N	2025-12-13 19:30:01+00
train_7a940e33	models--microsoft--Phi-4-mini-instruct	ebe8f940-9eee-401b-bd59-9457ea15e190	\N	COMPLETED	100	500000	500000	{"d_sae": 24576, "layer": 20, "architecture": "jumprelu"}	\N	\N	\N	\N	\N	\N	\N	/home/x-sean/app/miStudio/backend/data/trainings/train_7a940e33/checkpoints	\N	2025-12-12 00:00:00+00	2025-12-18 03:53:07.316594+00	\N	2025-12-12 12:18:28+00
\.


--
-- Name: feature_activations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.feature_activations_id_seq', 1, false);


--
-- Name: feature_analysis_cache_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.feature_analysis_cache_id_seq', 1, false);


--
-- Name: feature_dashboard_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.feature_dashboard_data_id_seq', 1, false);


--
-- Name: training_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.training_metrics_id_seq', 1, false);


--
-- Name: activation_extractions activation_extractions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activation_extractions
    ADD CONSTRAINT activation_extractions_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: checkpoints checkpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkpoints
    ADD CONSTRAINT checkpoints_pkey PRIMARY KEY (id);


--
-- Name: dataset_tokenizations dataset_tokenizations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dataset_tokenizations
    ADD CONSTRAINT dataset_tokenizations_pkey PRIMARY KEY (id);


--
-- Name: datasets datasets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.datasets
    ADD CONSTRAINT datasets_pkey PRIMARY KEY (id);


--
-- Name: external_saes external_saes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.external_saes
    ADD CONSTRAINT external_saes_pkey PRIMARY KEY (id);


--
-- Name: extraction_jobs extraction_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.extraction_jobs
    ADD CONSTRAINT extraction_jobs_pkey PRIMARY KEY (id);


--
-- Name: extraction_templates extraction_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.extraction_templates
    ADD CONSTRAINT extraction_templates_pkey PRIMARY KEY (id);


--
-- Name: feature_activations feature_activations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations
    ADD CONSTRAINT feature_activations_pkey PRIMARY KEY (id, feature_id);


--
-- Name: feature_activations_default feature_activations_default_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations_default
    ADD CONSTRAINT feature_activations_default_pkey PRIMARY KEY (id, feature_id);


--
-- Name: feature_activations_p00 feature_activations_p00_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations_p00
    ADD CONSTRAINT feature_activations_p00_pkey PRIMARY KEY (id, feature_id);


--
-- Name: feature_activations_p01 feature_activations_p01_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations_p01
    ADD CONSTRAINT feature_activations_p01_pkey PRIMARY KEY (id, feature_id);


--
-- Name: feature_activations_p02 feature_activations_p02_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations_p02
    ADD CONSTRAINT feature_activations_p02_pkey PRIMARY KEY (id, feature_id);


--
-- Name: feature_activations_p03 feature_activations_p03_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations_p03
    ADD CONSTRAINT feature_activations_p03_pkey PRIMARY KEY (id, feature_id);


--
-- Name: feature_activations_p04 feature_activations_p04_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations_p04
    ADD CONSTRAINT feature_activations_p04_pkey PRIMARY KEY (id, feature_id);


--
-- Name: feature_activations_p05 feature_activations_p05_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations_p05
    ADD CONSTRAINT feature_activations_p05_pkey PRIMARY KEY (id, feature_id);


--
-- Name: feature_activations_p06 feature_activations_p06_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations_p06
    ADD CONSTRAINT feature_activations_p06_pkey PRIMARY KEY (id, feature_id);


--
-- Name: feature_activations_p07 feature_activations_p07_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations_p07
    ADD CONSTRAINT feature_activations_p07_pkey PRIMARY KEY (id, feature_id);


--
-- Name: feature_activations_p08 feature_activations_p08_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations_p08
    ADD CONSTRAINT feature_activations_p08_pkey PRIMARY KEY (id, feature_id);


--
-- Name: feature_activations_p09 feature_activations_p09_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations_p09
    ADD CONSTRAINT feature_activations_p09_pkey PRIMARY KEY (id, feature_id);


--
-- Name: feature_activations_p10 feature_activations_p10_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations_p10
    ADD CONSTRAINT feature_activations_p10_pkey PRIMARY KEY (id, feature_id);


--
-- Name: feature_activations_p11 feature_activations_p11_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations_p11
    ADD CONSTRAINT feature_activations_p11_pkey PRIMARY KEY (id, feature_id);


--
-- Name: feature_activations_p12 feature_activations_p12_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations_p12
    ADD CONSTRAINT feature_activations_p12_pkey PRIMARY KEY (id, feature_id);


--
-- Name: feature_activations_p13 feature_activations_p13_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations_p13
    ADD CONSTRAINT feature_activations_p13_pkey PRIMARY KEY (id, feature_id);


--
-- Name: feature_activations_p14 feature_activations_p14_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations_p14
    ADD CONSTRAINT feature_activations_p14_pkey PRIMARY KEY (id, feature_id);


--
-- Name: feature_activations_p15 feature_activations_p15_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_activations_p15
    ADD CONSTRAINT feature_activations_p15_pkey PRIMARY KEY (id, feature_id);


--
-- Name: feature_analysis_cache feature_analysis_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_analysis_cache
    ADD CONSTRAINT feature_analysis_cache_pkey PRIMARY KEY (id);


--
-- Name: feature_dashboard_data feature_dashboard_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_dashboard_data
    ADD CONSTRAINT feature_dashboard_data_pkey PRIMARY KEY (id);


--
-- Name: features features_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.features
    ADD CONSTRAINT features_pkey PRIMARY KEY (id);


--
-- Name: labeling_jobs labeling_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.labeling_jobs
    ADD CONSTRAINT labeling_jobs_pkey PRIMARY KEY (id);


--
-- Name: labeling_prompt_templates labeling_prompt_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.labeling_prompt_templates
    ADD CONSTRAINT labeling_prompt_templates_pkey PRIMARY KEY (id);


--
-- Name: models models_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.models
    ADD CONSTRAINT models_pkey PRIMARY KEY (id);


--
-- Name: neuronpedia_export_jobs neuronpedia_export_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.neuronpedia_export_jobs
    ADD CONSTRAINT neuronpedia_export_jobs_pkey PRIMARY KEY (id);


--
-- Name: prompt_templates prompt_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prompt_templates
    ADD CONSTRAINT prompt_templates_pkey PRIMARY KEY (id);


--
-- Name: task_queue task_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_queue
    ADD CONSTRAINT task_queue_pkey PRIMARY KEY (id);


--
-- Name: training_metrics training_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_metrics
    ADD CONSTRAINT training_metrics_pkey PRIMARY KEY (id);


--
-- Name: training_templates training_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_templates
    ADD CONSTRAINT training_templates_pkey PRIMARY KEY (id);


--
-- Name: trainings trainings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trainings
    ADD CONSTRAINT trainings_pkey PRIMARY KEY (id);


--
-- Name: feature_analysis_cache uq_feature_analysis_cache_feature_type; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_analysis_cache
    ADD CONSTRAINT uq_feature_analysis_cache_feature_type UNIQUE (feature_id, analysis_type);


--
-- Name: feature_dashboard_data uq_feature_dashboard_feature_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_dashboard_data
    ADD CONSTRAINT uq_feature_dashboard_feature_id UNIQUE (feature_id);


--
-- Name: features uq_features_extraction_neuron; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.features
    ADD CONSTRAINT uq_features_extraction_neuron UNIQUE (training_id, extraction_job_id, neuron_index);


--
-- Name: idx_activation_extractions_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_activation_extractions_created_at ON public.activation_extractions USING btree (created_at);


--
-- Name: idx_activation_extractions_model_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_activation_extractions_model_id ON public.activation_extractions USING btree (model_id);


--
-- Name: idx_activation_extractions_model_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_activation_extractions_model_status ON public.activation_extractions USING btree (model_id, status);


--
-- Name: idx_activation_extractions_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_activation_extractions_status ON public.activation_extractions USING btree (status);


--
-- Name: idx_checkpoints_is_best; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_checkpoints_is_best ON public.checkpoints USING btree (training_id, is_best);


--
-- Name: idx_checkpoints_training_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_checkpoints_training_id ON public.checkpoints USING btree (training_id);


--
-- Name: idx_checkpoints_training_step; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_checkpoints_training_step ON public.checkpoints USING btree (training_id, step);


--
-- Name: idx_datasets_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_datasets_created_at ON public.datasets USING btree (created_at);


--
-- Name: idx_datasets_source; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_datasets_source ON public.datasets USING btree (source);


--
-- Name: idx_datasets_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_datasets_status ON public.datasets USING btree (status);


--
-- Name: idx_export_jobs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_export_jobs_created_at ON public.neuronpedia_export_jobs USING btree (created_at);


--
-- Name: idx_export_jobs_sae_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_export_jobs_sae_id ON public.neuronpedia_export_jobs USING btree (sae_id);


--
-- Name: idx_export_jobs_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_export_jobs_status ON public.neuronpedia_export_jobs USING btree (status);


--
-- Name: idx_external_saes_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_external_saes_created_at ON public.external_saes USING btree (created_at);


--
-- Name: idx_external_saes_hf_repo_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_external_saes_hf_repo_id ON public.external_saes USING btree (hf_repo_id);


--
-- Name: idx_external_saes_model_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_external_saes_model_name ON public.external_saes USING btree (model_name);


--
-- Name: idx_external_saes_source; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_external_saes_source ON public.external_saes USING btree (source);


--
-- Name: idx_external_saes_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_external_saes_status ON public.external_saes USING btree (status);


--
-- Name: idx_external_saes_training_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_external_saes_training_id ON public.external_saes USING btree (training_id);


--
-- Name: idx_extraction_active_training_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_extraction_active_training_unique ON public.extraction_jobs USING btree (training_id) WHERE (status = ANY (ARRAY['queued'::public.extraction_status_enum, 'extracting'::public.extraction_status_enum]));


--
-- Name: idx_extraction_jobs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_extraction_jobs_created_at ON public.extraction_jobs USING btree (created_at);


--
-- Name: idx_extraction_jobs_nlp_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_extraction_jobs_nlp_status ON public.extraction_jobs USING btree (nlp_status);


--
-- Name: idx_extraction_jobs_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_extraction_jobs_status ON public.extraction_jobs USING btree (status);


--
-- Name: idx_extraction_jobs_training_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_extraction_jobs_training_id ON public.extraction_jobs USING btree (training_id);


--
-- Name: idx_feature_activations_p00_feature_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p00_feature_id ON public.feature_activations_p00 USING btree (feature_id);


--
-- Name: idx_feature_activations_p00_max_activation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p00_max_activation ON public.feature_activations_p00 USING btree (max_activation DESC);


--
-- Name: idx_feature_activations_p01_feature_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p01_feature_id ON public.feature_activations_p01 USING btree (feature_id);


--
-- Name: idx_feature_activations_p01_max_activation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p01_max_activation ON public.feature_activations_p01 USING btree (max_activation DESC);


--
-- Name: idx_feature_activations_p02_feature_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p02_feature_id ON public.feature_activations_p02 USING btree (feature_id);


--
-- Name: idx_feature_activations_p02_max_activation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p02_max_activation ON public.feature_activations_p02 USING btree (max_activation DESC);


--
-- Name: idx_feature_activations_p03_feature_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p03_feature_id ON public.feature_activations_p03 USING btree (feature_id);


--
-- Name: idx_feature_activations_p03_max_activation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p03_max_activation ON public.feature_activations_p03 USING btree (max_activation DESC);


--
-- Name: idx_feature_activations_p04_feature_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p04_feature_id ON public.feature_activations_p04 USING btree (feature_id);


--
-- Name: idx_feature_activations_p04_max_activation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p04_max_activation ON public.feature_activations_p04 USING btree (max_activation DESC);


--
-- Name: idx_feature_activations_p05_feature_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p05_feature_id ON public.feature_activations_p05 USING btree (feature_id);


--
-- Name: idx_feature_activations_p05_max_activation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p05_max_activation ON public.feature_activations_p05 USING btree (max_activation DESC);


--
-- Name: idx_feature_activations_p06_feature_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p06_feature_id ON public.feature_activations_p06 USING btree (feature_id);


--
-- Name: idx_feature_activations_p06_max_activation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p06_max_activation ON public.feature_activations_p06 USING btree (max_activation DESC);


--
-- Name: idx_feature_activations_p07_feature_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p07_feature_id ON public.feature_activations_p07 USING btree (feature_id);


--
-- Name: idx_feature_activations_p07_max_activation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p07_max_activation ON public.feature_activations_p07 USING btree (max_activation DESC);


--
-- Name: idx_feature_activations_p08_feature_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p08_feature_id ON public.feature_activations_p08 USING btree (feature_id);


--
-- Name: idx_feature_activations_p08_max_activation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p08_max_activation ON public.feature_activations_p08 USING btree (max_activation DESC);


--
-- Name: idx_feature_activations_p09_feature_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p09_feature_id ON public.feature_activations_p09 USING btree (feature_id);


--
-- Name: idx_feature_activations_p09_max_activation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p09_max_activation ON public.feature_activations_p09 USING btree (max_activation DESC);


--
-- Name: idx_feature_activations_p10_feature_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p10_feature_id ON public.feature_activations_p10 USING btree (feature_id);


--
-- Name: idx_feature_activations_p10_max_activation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p10_max_activation ON public.feature_activations_p10 USING btree (max_activation DESC);


--
-- Name: idx_feature_activations_p11_feature_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p11_feature_id ON public.feature_activations_p11 USING btree (feature_id);


--
-- Name: idx_feature_activations_p11_max_activation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p11_max_activation ON public.feature_activations_p11 USING btree (max_activation DESC);


--
-- Name: idx_feature_activations_p12_feature_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p12_feature_id ON public.feature_activations_p12 USING btree (feature_id);


--
-- Name: idx_feature_activations_p12_max_activation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p12_max_activation ON public.feature_activations_p12 USING btree (max_activation DESC);


--
-- Name: idx_feature_activations_p13_feature_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p13_feature_id ON public.feature_activations_p13 USING btree (feature_id);


--
-- Name: idx_feature_activations_p13_max_activation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p13_max_activation ON public.feature_activations_p13 USING btree (max_activation DESC);


--
-- Name: idx_feature_activations_p14_feature_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p14_feature_id ON public.feature_activations_p14 USING btree (feature_id);


--
-- Name: idx_feature_activations_p14_max_activation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p14_max_activation ON public.feature_activations_p14 USING btree (max_activation DESC);


--
-- Name: idx_feature_activations_p15_feature_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p15_feature_id ON public.feature_activations_p15 USING btree (feature_id);


--
-- Name: idx_feature_activations_p15_max_activation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_activations_p15_max_activation ON public.feature_activations_p15 USING btree (max_activation DESC);


--
-- Name: idx_feature_analysis_cache_analysis_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_analysis_cache_analysis_type ON public.feature_analysis_cache USING btree (analysis_type);


--
-- Name: idx_feature_analysis_cache_expires_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_analysis_cache_expires_at ON public.feature_analysis_cache USING btree (expires_at);


--
-- Name: idx_feature_analysis_cache_feature_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_analysis_cache_feature_id ON public.feature_analysis_cache USING btree (feature_id);


--
-- Name: idx_feature_dashboard_feature_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_feature_dashboard_feature_id ON public.feature_dashboard_data USING btree (feature_id);


--
-- Name: idx_features_activation_freq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_features_activation_freq ON public.features USING btree (activation_frequency);


--
-- Name: idx_features_extraction_job_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_features_extraction_job_id ON public.features USING btree (extraction_job_id);


--
-- Name: idx_features_favorite; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_features_favorite ON public.features USING btree (is_favorite);


--
-- Name: idx_features_fulltext_search; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_features_fulltext_search ON public.features USING gin (to_tsvector('english'::regconfig, (((COALESCE(name, ''::character varying))::text || ' '::text) || COALESCE(description, ''::text))));


--
-- Name: idx_features_interpretability; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_features_interpretability ON public.features USING btree (interpretability_score);


--
-- Name: idx_features_labeling_job_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_features_labeling_job_id ON public.features USING btree (labeling_job_id);


--
-- Name: idx_features_neuron_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_features_neuron_index ON public.features USING btree (neuron_index);


--
-- Name: idx_features_nlp_processed; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_features_nlp_processed ON public.features USING btree (nlp_processed_at) WHERE (nlp_processed_at IS NOT NULL);


--
-- Name: idx_features_training_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_features_training_id ON public.features USING btree (training_id);


--
-- Name: idx_labeling_jobs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_labeling_jobs_created_at ON public.labeling_jobs USING btree (created_at);


--
-- Name: idx_labeling_jobs_extraction_job_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_labeling_jobs_extraction_job_id ON public.labeling_jobs USING btree (extraction_job_id);


--
-- Name: idx_labeling_jobs_prompt_template_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_labeling_jobs_prompt_template_id ON public.labeling_jobs USING btree (prompt_template_id);


--
-- Name: idx_labeling_jobs_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_labeling_jobs_status ON public.labeling_jobs USING btree (status);


--
-- Name: idx_labeling_prompt_templates_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_labeling_prompt_templates_created_at ON public.labeling_prompt_templates USING btree (created_at);


--
-- Name: idx_labeling_prompt_templates_is_default; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_labeling_prompt_templates_is_default ON public.labeling_prompt_templates USING btree (is_default);


--
-- Name: idx_labeling_prompt_templates_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_labeling_prompt_templates_name ON public.labeling_prompt_templates USING btree (name);


--
-- Name: idx_prompt_templates_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_prompt_templates_created_at ON public.prompt_templates USING btree (created_at);


--
-- Name: idx_prompt_templates_is_favorite; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_prompt_templates_is_favorite ON public.prompt_templates USING btree (is_favorite);


--
-- Name: idx_prompt_templates_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_prompt_templates_name ON public.prompt_templates USING btree (name);


--
-- Name: idx_prompt_templates_prompts_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_prompt_templates_prompts_gin ON public.prompt_templates USING gin (prompts);


--
-- Name: idx_prompt_templates_tags_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_prompt_templates_tags_gin ON public.prompt_templates USING gin (tags);


--
-- Name: idx_task_queue_entity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_task_queue_entity ON public.task_queue USING btree (entity_type, entity_id);


--
-- Name: idx_task_queue_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_task_queue_status ON public.task_queue USING btree (status);


--
-- Name: idx_task_queue_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_task_queue_task_id ON public.task_queue USING btree (task_id);


--
-- Name: idx_tokenizations_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tokenizations_created_at ON public.dataset_tokenizations USING btree (created_at);


--
-- Name: idx_tokenizations_dataset_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tokenizations_dataset_id ON public.dataset_tokenizations USING btree (dataset_id);


--
-- Name: idx_tokenizations_model_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tokenizations_model_id ON public.dataset_tokenizations USING btree (model_id);


--
-- Name: idx_tokenizations_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tokenizations_status ON public.dataset_tokenizations USING btree (status);


--
-- Name: idx_training_metrics_layer_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_training_metrics_layer_idx ON public.training_metrics USING btree (training_id, layer_idx, step);


--
-- Name: idx_training_metrics_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_training_metrics_timestamp ON public.training_metrics USING btree ("timestamp");


--
-- Name: idx_training_metrics_training_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_training_metrics_training_id ON public.training_metrics USING btree (training_id);


--
-- Name: idx_training_metrics_training_step; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_training_metrics_training_step ON public.training_metrics USING btree (training_id, step);


--
-- Name: idx_training_templates_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_training_templates_created_at ON public.training_templates USING btree (created_at);


--
-- Name: idx_training_templates_encoder_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_training_templates_encoder_type ON public.training_templates USING btree (encoder_type);


--
-- Name: idx_training_templates_extra_metadata_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_training_templates_extra_metadata_gin ON public.training_templates USING gin (extra_metadata);


--
-- Name: idx_training_templates_hyperparameters_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_training_templates_hyperparameters_gin ON public.training_templates USING gin (hyperparameters);


--
-- Name: idx_training_templates_is_favorite; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_training_templates_is_favorite ON public.training_templates USING btree (is_favorite);


--
-- Name: idx_training_templates_model_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_training_templates_model_id ON public.training_templates USING btree (model_id);


--
-- Name: idx_training_templates_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_training_templates_name ON public.training_templates USING btree (name);


--
-- Name: idx_trainings_celery_task; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trainings_celery_task ON public.trainings USING btree (celery_task_id);


--
-- Name: idx_trainings_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trainings_created_at ON public.trainings USING btree (created_at);


--
-- Name: idx_trainings_dataset_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trainings_dataset_id ON public.trainings USING btree (dataset_id);


--
-- Name: idx_trainings_extraction_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trainings_extraction_id ON public.trainings USING btree (extraction_id);


--
-- Name: idx_trainings_model_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trainings_model_id ON public.trainings USING btree (model_id);


--
-- Name: idx_trainings_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trainings_status ON public.trainings USING btree (status);


--
-- Name: ix_activation_extractions_original_extraction_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_activation_extractions_original_extraction_id ON public.activation_extractions USING btree (original_extraction_id);


--
-- Name: ix_extraction_jobs_external_sae_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_extraction_jobs_external_sae_id ON public.extraction_jobs USING btree (external_sae_id);


--
-- Name: ix_extraction_templates_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_extraction_templates_created_at ON public.extraction_templates USING btree (created_at);


--
-- Name: ix_extraction_templates_is_favorite; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_extraction_templates_is_favorite ON public.extraction_templates USING btree (is_favorite);


--
-- Name: ix_extraction_templates_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_extraction_templates_name ON public.extraction_templates USING btree (name);


--
-- Name: ix_features_external_sae_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_features_external_sae_id ON public.features USING btree (external_sae_id);


--
-- Name: uq_extraction_jobs_active_training; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_extraction_jobs_active_training ON public.extraction_jobs USING btree (training_id) WHERE (status = ANY (ARRAY['queued'::public.extraction_status_enum, 'extracting'::public.extraction_status_enum]));


--
-- Name: feature_activations_default_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.feature_activations_pkey ATTACH PARTITION public.feature_activations_default_pkey;


--
-- Name: feature_activations_p00_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.feature_activations_pkey ATTACH PARTITION public.feature_activations_p00_pkey;


--
-- Name: feature_activations_p01_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.feature_activations_pkey ATTACH PARTITION public.feature_activations_p01_pkey;


--
-- Name: feature_activations_p02_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.feature_activations_pkey ATTACH PARTITION public.feature_activations_p02_pkey;


--
-- Name: feature_activations_p03_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.feature_activations_pkey ATTACH PARTITION public.feature_activations_p03_pkey;


--
-- Name: feature_activations_p04_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.feature_activations_pkey ATTACH PARTITION public.feature_activations_p04_pkey;


--
-- Name: feature_activations_p05_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.feature_activations_pkey ATTACH PARTITION public.feature_activations_p05_pkey;


--
-- Name: feature_activations_p06_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.feature_activations_pkey ATTACH PARTITION public.feature_activations_p06_pkey;


--
-- Name: feature_activations_p07_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.feature_activations_pkey ATTACH PARTITION public.feature_activations_p07_pkey;


--
-- Name: feature_activations_p08_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.feature_activations_pkey ATTACH PARTITION public.feature_activations_p08_pkey;


--
-- Name: feature_activations_p09_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.feature_activations_pkey ATTACH PARTITION public.feature_activations_p09_pkey;


--
-- Name: feature_activations_p10_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.feature_activations_pkey ATTACH PARTITION public.feature_activations_p10_pkey;


--
-- Name: feature_activations_p11_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.feature_activations_pkey ATTACH PARTITION public.feature_activations_p11_pkey;


--
-- Name: feature_activations_p12_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.feature_activations_pkey ATTACH PARTITION public.feature_activations_p12_pkey;


--
-- Name: feature_activations_p13_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.feature_activations_pkey ATTACH PARTITION public.feature_activations_p13_pkey;


--
-- Name: feature_activations_p14_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.feature_activations_pkey ATTACH PARTITION public.feature_activations_p14_pkey;


--
-- Name: feature_activations_p15_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.feature_activations_pkey ATTACH PARTITION public.feature_activations_p15_pkey;


--
-- Name: prompt_templates trigger_update_prompt_templates_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_prompt_templates_updated_at BEFORE UPDATE ON public.prompt_templates FOR EACH ROW EXECUTE FUNCTION public.update_prompt_templates_updated_at();


--
-- Name: training_templates trigger_update_training_templates_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_training_templates_updated_at BEFORE UPDATE ON public.training_templates FOR EACH ROW EXECUTE FUNCTION public.update_training_templates_updated_at();


--
-- Name: activation_extractions activation_extractions_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activation_extractions
    ADD CONSTRAINT activation_extractions_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.models(id);


--
-- Name: checkpoints checkpoints_training_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checkpoints
    ADD CONSTRAINT checkpoints_training_id_fkey FOREIGN KEY (training_id) REFERENCES public.trainings(id) ON DELETE CASCADE;


--
-- Name: dataset_tokenizations dataset_tokenizations_dataset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dataset_tokenizations
    ADD CONSTRAINT dataset_tokenizations_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES public.datasets(id) ON DELETE CASCADE;


--
-- Name: dataset_tokenizations dataset_tokenizations_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dataset_tokenizations
    ADD CONSTRAINT dataset_tokenizations_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.models(id) ON DELETE CASCADE;


--
-- Name: extraction_jobs extraction_jobs_training_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.extraction_jobs
    ADD CONSTRAINT extraction_jobs_training_id_fkey FOREIGN KEY (training_id) REFERENCES public.trainings(id) ON DELETE CASCADE;


--
-- Name: feature_analysis_cache feature_analysis_cache_feature_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_analysis_cache
    ADD CONSTRAINT feature_analysis_cache_feature_id_fkey FOREIGN KEY (feature_id) REFERENCES public.features(id) ON DELETE CASCADE;


--
-- Name: feature_dashboard_data feature_dashboard_data_feature_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feature_dashboard_data
    ADD CONSTRAINT feature_dashboard_data_feature_id_fkey FOREIGN KEY (feature_id) REFERENCES public.features(id) ON DELETE CASCADE;


--
-- Name: features features_extraction_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.features
    ADD CONSTRAINT features_extraction_job_id_fkey FOREIGN KEY (extraction_job_id) REFERENCES public.extraction_jobs(id) ON DELETE CASCADE;


--
-- Name: features features_training_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.features
    ADD CONSTRAINT features_training_id_fkey FOREIGN KEY (training_id) REFERENCES public.trainings(id) ON DELETE CASCADE;


--
-- Name: external_saes fk_external_saes_model_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.external_saes
    ADD CONSTRAINT fk_external_saes_model_id FOREIGN KEY (model_id) REFERENCES public.models(id) ON DELETE SET NULL;


--
-- Name: external_saes fk_external_saes_training_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.external_saes
    ADD CONSTRAINT fk_external_saes_training_id FOREIGN KEY (training_id) REFERENCES public.trainings(id) ON DELETE SET NULL;


--
-- Name: extraction_jobs fk_extraction_jobs_external_sae_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.extraction_jobs
    ADD CONSTRAINT fk_extraction_jobs_external_sae_id FOREIGN KEY (external_sae_id) REFERENCES public.external_saes(id) ON DELETE CASCADE;


--
-- Name: feature_activations fk_feature_activations_feature_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public.feature_activations
    ADD CONSTRAINT fk_feature_activations_feature_id FOREIGN KEY (feature_id) REFERENCES public.features(id) ON DELETE CASCADE;


--
-- Name: features fk_features_external_sae_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.features
    ADD CONSTRAINT fk_features_external_sae_id FOREIGN KEY (external_sae_id) REFERENCES public.external_saes(id) ON DELETE CASCADE;


--
-- Name: labeling_jobs fk_labeling_jobs_prompt_template_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.labeling_jobs
    ADD CONSTRAINT fk_labeling_jobs_prompt_template_id FOREIGN KEY (prompt_template_id) REFERENCES public.labeling_prompt_templates(id) ON DELETE RESTRICT;


--
-- Name: labeling_jobs labeling_jobs_extraction_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.labeling_jobs
    ADD CONSTRAINT labeling_jobs_extraction_job_id_fkey FOREIGN KEY (extraction_job_id) REFERENCES public.extraction_jobs(id) ON DELETE CASCADE;


--
-- Name: training_metrics training_metrics_training_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_metrics
    ADD CONSTRAINT training_metrics_training_id_fkey FOREIGN KEY (training_id) REFERENCES public.trainings(id) ON DELETE CASCADE;


--
-- Name: training_templates training_templates_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_templates
    ADD CONSTRAINT training_templates_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.models(id) ON DELETE SET NULL;


--
-- Name: trainings trainings_extraction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trainings
    ADD CONSTRAINT trainings_extraction_id_fkey FOREIGN KEY (extraction_id) REFERENCES public.activation_extractions(id) ON DELETE RESTRICT;


--
-- Name: trainings trainings_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trainings
    ADD CONSTRAINT trainings_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.models(id) ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict yq5xA2Bhc3cA9aN8pzy1pdf0qOEKfEYUGR5Zv7de08ZpHpzktbqb2732fDk376n

